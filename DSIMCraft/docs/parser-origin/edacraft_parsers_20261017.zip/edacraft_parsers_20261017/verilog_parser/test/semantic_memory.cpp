#include "src_mgr.hpp"
#include "veri_parser.hpp"
#include "veri_mod_container.hpp"
#include "veri_module.hpp"
#include "veri_node_pool.hpp"
#include "veri_num.hpp"
#include "veri_var.hpp"
#include "veri_exp.hpp"
#include "veri_inst.hpp"
#include "veri_tfmg.hpp"

#include <cassert>
#include <iostream>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

namespace {
struct TestPool : rtl::VeriNodePool {
  using rtl::VeriNodePool::clear_tosses;
};

void test_pool_reset(bool retain_storage) {
  TestPool pool;
  pool.init(16,15);
  const auto id=pool.next_id();
  pool.insert(new rtl::VeriNum(id,1,1,nullptr));
  pool.toss_node(id);
  pool.clear_tosses();
  if(retain_storage) pool.clean_up();
  else { pool.clear(); pool.init(16,15); }
  const auto first=pool.next_id(),second=pool.next_id();
  assert(first!=second);
}

// Exercise the public parse entry, including automatic semantic analysis for
// a selected top. A syntax-only success must not hide invalid declarations.
rtl::VeriMod* analyze(const std::string& source, int expected=rtl::OK, const std::string& top="top") {
  auto* parser=rtl::VeriParser::get_instance();
  rtl::Src_mgr::get_instance()->set_src(source+std::string(1,'\0'));
  rtl::Src_mgr::get_instance()->set_fname("semantic_memory.v");
  assert(parser->init()==rtl::OK);
  parser->set_top_module(top);
  const int result=parser->parse();
  if(result!=expected) std::cerr<<"parse result "<<result<<"\n"<<parser->get_err_info();
  assert(result==expected);
  assert(parser->has_err()==(expected==rtl::OK ? rtl::IS_FALSE : rtl::IS_TRUE));
  auto* mod=parser->module(top);
  assert(mod || expected==rtl::vMOD_TOP_MODULE_MISSING);
  return mod;
}

void test_scope_cleanup() {
  rtl::VeriNum number(1,1,1,nullptr);
  rtl::VeriSymbolTable symbols;
  symbols.init(16,"scope");
  symbols.insert("x",&number);
  symbols.clean_up();
  assert(symbols.value_same_level("x")==nullptr);
  symbols.insert("x",&number);
  symbols.clean_up();
  symbols.clean_up();
  rtl::VeriMod mod(2);
  mod.init(16);
  mod.scope()->insert("x",&number);
  mod.clean_up();
  mod.clean_up();
  assert(mod.scope()==nullptr);
}

void test_ports() {
  auto* mod=analyze(
    "module top(input [7:0] a,output [7:0] z); child u(.z(z),.a(a)); endmodule\n"
    "module child(input [7:0] a,output [7:0] z); assign z=a; endmodule\n");
  auto* symbol=mod->scope()->value_same_level("u");
  assert(symbol && symbol->tok_type()==vtMOD_INST);
  auto* inst=static_cast<rtl::VeriModInstance*>(static_cast<rtl::VeriModInst*>(symbol)->instance());
  auto* hive=static_cast<rtl::VeriMod*>(inst->hive());
  assert(hive && hive->port()->father()==hive && hive->item()->father()==hive);
  for(auto* node : static_cast<rtl::VeriMultiExp*>(inst->arg())->exp()) {
    auto* named=static_cast<rtl::VeriNamedParamExp*>(node);
    assert(named->port_ref()==hive->scope()->value_same_level(named->ref()));
    assert(named->port_ref()!=nullptr);
  }
  analyze("module top; child u(); endmodule module child; wire x; endmodule\n");
  analyze("module top(a,z); input [7:0] a; output [7:0] z; wire [7:0] z; assign z=a; endmodule\n");
  analyze("module top(input a); child u(a,a); endmodule module child(input a); endmodule\n",rtl::vSEC_MOD_PORT_MISMATCH);
  analyze("module top(input a); child u(.a(a),.a(a)); endmodule module child(input a); endmodule\n",rtl::vSEC_MOD_PORT_MISMATCH);
  analyze("module top(input a); child u(.missing(a)); endmodule module child(input a); endmodule\n",rtl::vSEC_MOD_PORT_MISMATCH);
  analyze("module top; child u(.z()); endmodule module child(output z); assign z=1'b0; endmodule\n");
  analyze("module top; child u(); endmodule module child(W); parameter W=1; endmodule\n",rtl::vSEC_MOD_PORT_MISMATCH);
  analyze("module top; child u(); child u(); endmodule module child; endmodule\n",rtl::vMOD_INST_REDEFINE);
}

void test_parameters() {
  auto* mod=analyze(
    "module top #(parameter N=32)(input [N:0] a,output [N:0] z);\n"
    "child #(.W(N),.V(N+1)) u(.z(z),.a(a));\n"
    "child #(16,17) v(); child #(.W(64)) w(); child q(); endmodule\n"
    "module child #(parameter W=8,V=W+1)(input [V-1:0] a,output [V-1:0] z);\n"
    "localparam X=V+2; wire [X-1:0] t; assign z=a; endmodule\n");
  for(const auto& name : {"u","v","w","q"}) {
    auto* symbol=static_cast<rtl::VeriModInst*>(mod->scope()->value_same_level(name));
    assert(symbol);
    auto* hive=static_cast<rtl::VeriMod*>(static_cast<rtl::VeriModInstance*>(symbol->instance())->hive());
    const int expected=std::string(name)=="u" ? 33 : std::string(name)=="v" ? 17 : std::string(name)=="w" ? 65 : 9;
    auto* port=static_cast<rtl::VeriVar*>(hive->scope()->value_same_level("a"));
    auto* wire=static_cast<rtl::VeriVar*>(hive->scope()->value_same_level("t"));
    assert(port && port->dlen()==expected);
    assert(wire && wire->dlen()==expected+2);
    auto* param=static_cast<rtl::VeriParam*>(hive->scope()->value_same_level("W"));
    assert(param && param->get_val()->get_first_int()==expected-1);
  }
  for(const auto& args : {".missing(3)",".W(3),.W(4)","1,2,3",".X(3)"}) {
    analyze(std::string("module top; child #(")+args+") u(); endmodule\n"
      "module child #(parameter W=8,V=W+1)(); localparam X=1; endmodule\n",rtl::vSEC_MOD_PARAM_MISMATCH);
  }
}

void test_public_entry() {
  analyze("module top(input a,output z); assign z=missing; endmodule\n",rtl::vSEC_SYMBOL_NOT_FOUND);
  analyze("module top; endmodule\n",rtl::vMOD_TOP_MODULE_MISSING,"absent");
  auto* parser=rtl::VeriParser::get_instance();
  rtl::Src_mgr::get_instance()->set_src("module first; endmodule module second; endmodule\n"+std::string(1,'\0'));
  assert(parser->init()==rtl::OK);
  assert(parser->parse()==rtl::OK);
  assert(parser->has_err()==rtl::IS_FALSE);
  assert(parser->module("first") && parser->module("second"));
  parser->clean_up();
  parser->clean_up();
  parser->clear();
  parser->clear();
}

void test_declarations() {
  // Repeated parsing also checks that recycled node IDs cannot collide
  // with newly allocated AST and constant-result nodes.
  for(int round=0;round<3;++round) {
    auto* mod=analyze(
      "module top #(parameter W=64)(input [W-1:0] a, output [W-1:0] z);\n"
      "wire [W-1:0] named_wire = 17; integer named_integer = 19;\n"
      "assign z=a; endmodule\n");
    for(const auto& name : {"a","z","named_wire"}) {
      auto* node=mod->scope()->value_same_level(name);
      assert(node && node->tok_type()==vtVAR);
      auto* var=static_cast<rtl::VeriVar*>(node);
      assert(var->name()==name);
      assert(var->dstart()==63 && var->dend()==0 && var->dlen()==64);
      if(std::string(name)=="named_wire") {
        auto* value=var->get_one_num({},rtl::IS_TRUE,0,0);
        assert(value && value->get_first_int()==17 && value->bits()==64);
      }
    }
    auto* node=mod->scope()->value_same_level("named_integer");
    assert(node && node->tok_type()==vtINT);
    auto* integer=static_cast<rtl::VeriInt*>(node);
    assert(integer->name()=="named_integer");
    auto* value=integer->get_one_num({},rtl::IS_TRUE,0,0);
    assert(value && value->get_first_int()==19);
  }
}

void test_systemverilog_sized_casts() {
  // Numeric and parameterized sized casts must survive both syntax parsing
  // and the second semantic traversal without turning the apostrophe into a
  // stray token or corrupting the range/port symbol table.
  analyze(
    "module top #(parameter W=32)(input [W-1:0] a, output [W-1:0] z);\n"
    "assign z = 32'(a + 1'b0);\n"
    "endmodule\n");
  analyze(
    "module top #(parameter W=32)(input [W-1:0] a, output [W-1:0] z);\n"
    "assign z = W'(a);\n"
    "endmodule\n");
  analyze(
    "module top #(parameter W=32)(input [W-1:0] a, output [W-1:0] z);\n"
    "assign z = logic'(a);\n"
    "endmodule\n");
  analyze(
    "module top #(parameter W=32)(input [W-1:0] a, output [W-1:0] z);\n"
    "assign z = signed'(a);\n"
    "endmodule\n");
}

void test_word_boundaries() {
  for(int width : {1,31,32,33,63,64,65,256}) {
    rtl::VeriNum number(1,1,1,nullptr);
    number.init_val(rtl::IS_FALSE,width);
    assert(number.unary_operation(vtUNEG)==rtl::OK);
    assert(number.bits()==width);
    for(int k=0;k<width;++k) assert(number.get_certain_bit(k)==1);
    assert(number.unary_operation(vtUNEG)==rtl::OK);
    for(int k=0;k<width;++k) assert(number.get_certain_bit(k)==0);
    assert(number.get_certain_bit(-1)==0);
    assert(number.get_certain_bit(width)==0);
    for(bool negative : {false,true}) {
      number.init_val(rtl::IS_TRUE,width);
      if(negative) number.unary_operation(vtUNEG);
      number.truncate_assign(width+37);
      for(int k=0;k<width+37;++k) assert(number.get_certain_bit(k)==(negative?1:0));
    }
  }
}
}

int main(int argc, char** argv) {
  if(argc==3) {
    std::ifstream input(argv[1]);
    assert(input.good());
    const std::string source((std::istreambuf_iterator<char>(input)),{});
    for(int round=0;round<3;++round) analyze(source,rtl::OK,argv[2]);
    std::cout<<"PASS corpus second pass and repeated cleanup: "<<argv[2]<<"\n";
    return 0;
  }
  test_pool_reset(false);
  test_pool_reset(true);
  test_word_boundaries();
  test_scope_cleanup();
  test_declarations();
  test_ports();
  test_parameters();
  test_public_entry();
  test_systemverilog_sized_casts();
  std::cout<<"PASS semantic memory, values, widths, ports and repeated cleanup\n";
}
