/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1


/* Substitute the variable and function names.  */
#define yyparse         verilogparse
#define yylex           veriloglex
#define yyerror         verilogerror
#define yydebug         verilogdebug
#define yynerrs         verilognerrs
#define yylval          veriloglval
#define yychar          verilogchar

/* First part of user prologue.  */
#line 1 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"

/*
 * Copyright (c) 2012 Fudan University ICCAD Lab
 * All rights reserved.
 *
 * Filename : verilog.y
 * Summary  : verilog syntax analyzer
 *
 * Version  : 1 ( Creation )
 * Author   : Pavio Yang ( 11212020059@fudan.edu.cn )
 * Date     : 2012.10.28
 */
#include <cstdlib>
#include <cstring>
#include <iostream>

#include "general_err.hpp"
#include "verilog_token.hpp"
#include "veri_node.hpp"
#include "veri_parser.hpp"

using rtl::OK;
using rtl::IS_TRUE;
using rtl::IS_FALSE;
using rtl::VeriAstNode;
using rtl::VeriNode;
using rtl::VeriParser;

#define YYINITDEPTH 1000
#define YYMAXDEPTH 50000

extern char *verilogtext;

int yylex();
extern int veriloglex_destroy( void );
extern int veri_col;
extern int veri_lno;

 /* RESPONCE in an error */
void yyerror(const char *str )
{
  using pavio_singleton::Singleton;
  using rtl::VeriParser;
  const char* trace_syntax = std::getenv("FSYN_TRACE_VERILOG_SYNTAX");
  if( trace_syntax && *trace_syntax != '\0' )
    std::cerr << "[fsyn] verilog syntax error at line " << veri_lno
              << " col " << veri_col << " token '"
              << (verilogtext ? verilogtext : "")
              << "': " << (str ? str : "") << std::endl;
  veriloglex_destroy( );
}


#line 132 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "verilog_yacc.hpp"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_MY_EOF = 3,                     /* MY_EOF  */
  YYSYMBOL_vPORT_DELIM = 4,                /* vPORT_DELIM  */
  YYSYMBOL_vPARAM_DELIM = 5,               /* vPARAM_DELIM  */
  YYSYMBOL_vEVENT_ALL = 6,                 /* vEVENT_ALL  */
  YYSYMBOL_vDUMMY_PORT = 7,                /* vDUMMY_PORT  */
  YYSYMBOL_vSIGN_FUNC = 8,                 /* vSIGN_FUNC  */
  YYSYMBOL_vUNSIGN_FUNC = 9,               /* vUNSIGN_FUNC  */
  YYSYMBOL_vNOT_SUPPORTED = 10,            /* vNOT_SUPPORTED  */
  YYSYMBOL_vALWAYS = 11,                   /* vALWAYS  */
  YYSYMBOL_vALWAYS_COMB = 12,              /* vALWAYS_COMB  */
  YYSYMBOL_vALWAYS_FF = 13,                /* vALWAYS_FF  */
  YYSYMBOL_vALWAYS_LATCH = 14,             /* vALWAYS_LATCH  */
  YYSYMBOL_vAND_ASCII = 15,                /* vAND_ASCII  */
  YYSYMBOL_vASSIGN = 16,                   /* vASSIGN  */
  YYSYMBOL_vAUTO = 17,                     /* vAUTO  */
  YYSYMBOL_vBEGIN = 18,                    /* vBEGIN  */
  YYSYMBOL_vBIT = 19,                      /* vBIT  */
  YYSYMBOL_vBUF_ASCII = 20,                /* vBUF_ASCII  */
  YYSYMBOL_vBUFIF_A = 21,                  /* vBUFIF_A  */
  YYSYMBOL_vBYTE = 22,                     /* vBYTE  */
  YYSYMBOL_vBUFIF_B = 23,                  /* vBUFIF_B  */
  YYSYMBOL_vCASE = 24,                     /* vCASE  */
  YYSYMBOL_vCASEX = 25,                    /* vCASEX  */
  YYSYMBOL_vCASEZ = 26,                    /* vCASEZ  */
  YYSYMBOL_vCELL = 27,                     /* vCELL  */
  YYSYMBOL_vCONFIG = 28,                   /* vCONFIG  */
  YYSYMBOL_vDEFAULT = 29,                  /* vDEFAULT  */
  YYSYMBOL_vDESIGN = 30,                   /* vDESIGN  */
  YYSYMBOL_vDISABLE = 31,                  /* vDISABLE  */
  YYSYMBOL_vDO = 32,                       /* vDO  */
  YYSYMBOL_vELSE = 33,                     /* vELSE  */
  YYSYMBOL_vEND = 34,                      /* vEND  */
  YYSYMBOL_vENDCASE = 35,                  /* vENDCASE  */
  YYSYMBOL_vENDCONFIG = 36,                /* vENDCONFIG  */
  YYSYMBOL_vENDFUNC = 37,                  /* vENDFUNC  */
  YYSYMBOL_vENDGEN = 38,                   /* vENDGEN  */
  YYSYMBOL_vENDMODULE = 39,                /* vENDMODULE  */
  YYSYMBOL_vENDSPEC = 40,                  /* vENDSPEC  */
  YYSYMBOL_vENDTASK = 41,                  /* vENDTASK  */
  YYSYMBOL_vFOR = 42,                      /* vFOR  */
  YYSYMBOL_vFUNC = 43,                     /* vFUNC  */
  YYSYMBOL_vGEN = 44,                      /* vGEN  */
  YYSYMBOL_vGENVAR = 45,                   /* vGENVAR  */
  YYSYMBOL_vHIGHZ_A = 46,                  /* vHIGHZ_A  */
  YYSYMBOL_vHIGHZ_B = 47,                  /* vHIGHZ_B  */
  YYSYMBOL_vIF = 48,                       /* vIF  */
  YYSYMBOL_vINC_DIR = 49,                  /* vINC_DIR  */
  YYSYMBOL_vINIT = 50,                     /* vINIT  */
  YYSYMBOL_vINOUT = 51,                    /* vINOUT  */
  YYSYMBOL_vINPUT = 52,                    /* vINPUT  */
  YYSYMBOL_vINSTANCE = 53,                 /* vINSTANCE  */
  YYSYMBOL_vINT = 54,                      /* vINT  */
  YYSYMBOL_vLIBLIST = 55,                  /* vLIBLIST  */
  YYSYMBOL_vLIB = 56,                      /* vLIB  */
  YYSYMBOL_vLOCAL_PARAM = 57,              /* vLOCAL_PARAM  */
  YYSYMBOL_vMODULE = 58,                   /* vMODULE  */
  YYSYMBOL_vNAND_ASCII = 59,               /* vNAND_ASCII  */
  YYSYMBOL_vNEGEDGE = 60,                  /* vNEGEDGE  */
  YYSYMBOL_vNOR_ASCII = 61,                /* vNOR_ASCII  */
  YYSYMBOL_vNOT_ASCII = 62,                /* vNOT_ASCII  */
  YYSYMBOL_vNOTIF_A = 63,                  /* vNOTIF_A  */
  YYSYMBOL_vNOTIF_B = 64,                  /* vNOTIF_B  */
  YYSYMBOL_vOR_ASCII = 65,                 /* vOR_ASCII  */
  YYSYMBOL_vOUTPUT = 66,                   /* vOUTPUT  */
  YYSYMBOL_vPARAMETER = 67,                /* vPARAMETER  */
  YYSYMBOL_vPOSEDGE = 68,                  /* vPOSEDGE  */
  YYSYMBOL_vPULL_A = 69,                   /* vPULL_A  */
  YYSYMBOL_vPULL_B = 70,                   /* vPULL_B  */
  YYSYMBOL_vREG = 71,                      /* vREG  */
  YYSYMBOL_vSHORTINT = 72,                 /* vSHORTINT  */
  YYSYMBOL_vTRIAND = 73,                   /* vTRIAND  */
  YYSYMBOL_vTRIOR = 74,                    /* vTRIOR  */
  YYSYMBOL_vSCALARED = 75,                 /* vSCALARED  */
  YYSYMBOL_vSIGNED = 76,                   /* vSIGNED  */
  YYSYMBOL_vSPECIFY = 77,                  /* vSPECIFY  */
  YYSYMBOL_vSPEC_PARAM = 78,               /* vSPEC_PARAM  */
  YYSYMBOL_vSTRONG_A = 79,                 /* vSTRONG_A  */
  YYSYMBOL_vSTRONG_B = 80,                 /* vSTRONG_B  */
  YYSYMBOL_vSUPPLY_A = 81,                 /* vSUPPLY_A  */
  YYSYMBOL_vSUPPLY_B = 82,                 /* vSUPPLY_B  */
  YYSYMBOL_vTASK = 83,                     /* vTASK  */
  YYSYMBOL_vTIME = 84,                     /* vTIME  */
  YYSYMBOL_vTRI = 85,                      /* vTRI  */
  YYSYMBOL_vUSE = 86,                      /* vUSE  */
  YYSYMBOL_vUNSIGNED = 87,                 /* vUNSIGNED  */
  YYSYMBOL_vVECTORED = 88,                 /* vVECTORED  */
  YYSYMBOL_vWAND = 89,                     /* vWAND  */
  YYSYMBOL_vWEAK_A = 90,                   /* vWEAK_A  */
  YYSYMBOL_vWEAK_B = 91,                   /* vWEAK_B  */
  YYSYMBOL_vWHILE = 92,                    /* vWHILE  */
  YYSYMBOL_vWIRE = 93,                     /* vWIRE  */
  YYSYMBOL_vWOR = 94,                      /* vWOR  */
  YYSYMBOL_vLONGINT = 95,                  /* vLONGINT  */
  YYSYMBOL_vXNOR_ASCII = 96,               /* vXNOR_ASCII  */
  YYSYMBOL_vXOR_ASCII = 97,                /* vXOR_ASCII  */
  YYSYMBOL_vIDENT = 98,                    /* vIDENT  */
  YYSYMBOL_vLOGIC = 99,                    /* vLOGIC  */
  YYSYMBOL_vNUMBER = 100,                  /* vNUMBER  */
  YYSYMBOL_vSYS_IDENT = 101,               /* vSYS_IDENT  */
  YYSYMBOL_vCONCAT_IDENT = 102,            /* vCONCAT_IDENT  */
  YYSYMBOL_vUNSIGNED_NUM = 103,            /* vUNSIGNED_NUM  */
  YYSYMBOL_vARITH_LS = 104,                /* vARITH_LS  */
  YYSYMBOL_vARITH_RS = 105,                /* vARITH_RS  */
  YYSYMBOL_vANDAND = 106,                  /* vANDAND  */
  YYSYMBOL_vXNOR = 107,                    /* vXNOR  */
  YYSYMBOL_vNAND = 108,                    /* vNAND  */
  YYSYMBOL_vNOR = 109,                     /* vNOR  */
  YYSYMBOL_vPOW = 110,                     /* vPOW  */
  YYSYMBOL_vOROR = 111,                    /* vOROR  */
  YYSYMBOL_vLE = 112,                      /* vLE  */
  YYSYMBOL_vGE = 113,                      /* vGE  */
  YYSYMBOL_vLOGIC_LS = 114,                /* vLOGIC_LS  */
  YYSYMBOL_vLOGIC_RS = 115,                /* vLOGIC_RS  */
  YYSYMBOL_vLOGIC_EQ = 116,                /* vLOGIC_EQ  */
  YYSYMBOL_vLOGIC_INEQ = 117,              /* vLOGIC_INEQ  */
  YYSYMBOL_vCASE_EQ = 118,                 /* vCASE_EQ  */
  YYSYMBOL_vCASE_INEQ = 119,               /* vCASE_INEQ  */
  YYSYMBOL_120_ = 120,                     /* '+'  */
  YYSYMBOL_121_ = 121,                     /* '='  */
  YYSYMBOL_122_ = 122,                     /* '-'  */
  YYSYMBOL_123_ = 123,                     /* '*'  */
  YYSYMBOL_124_ = 124,                     /* '/'  */
  YYSYMBOL_125_ = 125,                     /* '%'  */
  YYSYMBOL_126_ = 126,                     /* '>'  */
  YYSYMBOL_127_ = 127,                     /* '<'  */
  YYSYMBOL_128_ = 128,                     /* '!'  */
  YYSYMBOL_129_ = 129,                     /* '~'  */
  YYSYMBOL_130_ = 130,                     /* '&'  */
  YYSYMBOL_131_ = 131,                     /* '|'  */
  YYSYMBOL_132_ = 132,                     /* '^'  */
  YYSYMBOL_133_ = 133,                     /* '?'  */
  YYSYMBOL_134_ = 134,                     /* '#'  */
  YYSYMBOL_135_ = 135,                     /* '@'  */
  YYSYMBOL_136_ = 136,                     /* '['  */
  YYSYMBOL_137_ = 137,                     /* ']'  */
  YYSYMBOL_138_ = 138,                     /* '{'  */
  YYSYMBOL_139_ = 139,                     /* '}'  */
  YYSYMBOL_140_ = 140,                     /* ';'  */
  YYSYMBOL_141_ = 141,                     /* ','  */
  YYSYMBOL_142_ = 142,                     /* '.'  */
  YYSYMBOL_143_ = 143,                     /* '('  */
  YYSYMBOL_144_ = 144,                     /* ')'  */
  YYSYMBOL_145_ = 145,                     /* ':'  */
  YYSYMBOL_vATTR_L = 146,                  /* vATTR_L  */
  YYSYMBOL_vATTR_R = 147,                  /* vATTR_R  */
  YYSYMBOL_vPRIMITIVE = 148,               /* vPRIMITIVE  */
  YYSYMBOL_vENDPRI = 149,                  /* vENDPRI  */
  YYSYMBOL_vSTR = 150,                     /* vSTR  */
  YYSYMBOL_vFILE = 151,                    /* vFILE  */
  YYSYMBOL_vRANGE_ADD = 152,               /* vRANGE_ADD  */
  YYSYMBOL_vRANGE_SUB = 153,               /* vRANGE_SUB  */
  YYSYMBOL_vPATHPULSE = 154,               /* vPATHPULSE  */
  YYSYMBOL_LOWER_THAN_ELSE = 155,          /* LOWER_THAN_ELSE  */
  YYSYMBOL_LOWER_THAN_A = 156,             /* LOWER_THAN_A  */
  YYSYMBOL_LOWER_THAN_B = 157,             /* LOWER_THAN_B  */
  YYSYMBOL_LOWER_THAN_C = 158,             /* LOWER_THAN_C  */
  YYSYMBOL_UOR = 159,                      /* UOR  */
  YYSYMBOL_UAND = 160,                     /* UAND  */
  YYSYMBOL_UNEG = 161,                     /* UNEG  */
  YYSYMBOL_UNAND = 162,                    /* UNAND  */
  YYSYMBOL_UNOR = 163,                     /* UNOR  */
  YYSYMBOL_UXNOR = 164,                    /* UXNOR  */
  YYSYMBOL_UXOR = 165,                     /* UXOR  */
  YYSYMBOL_ULNOT = 166,                    /* ULNOT  */
  YYSYMBOL_UADD = 167,                     /* UADD  */
  YYSYMBOL_UMINUS = 168,                   /* UMINUS  */
  YYSYMBOL_YYACCEPT = 169,                 /* $accept  */
  YYSYMBOL_verilog_synthesis_unit = 170,   /* verilog_synthesis_unit  */
  YYSYMBOL_source_text = 171,              /* source_text  */
  YYSYMBOL_module_declaration = 172,       /* module_declaration  */
  YYSYMBOL_module_port_part = 173,         /* module_port_part  */
  YYSYMBOL_module_item_list = 174,         /* module_item_list  */
  YYSYMBOL_param_decl_list = 175,          /* param_decl_list  */
  YYSYMBOL_port_decl_list = 176,           /* port_decl_list  */
  YYSYMBOL_port_declaration = 177,         /* port_declaration  */
  YYSYMBOL_port_term = 178,                /* port_term  */
  YYSYMBOL_in_or_out = 179,                /* in_or_out  */
  YYSYMBOL_port_type = 180,                /* port_type  */
  YYSYMBOL_module_item = 181,              /* module_item  */
  YYSYMBOL_module_or_gen_item = 182,       /* module_or_gen_item  */
  YYSYMBOL_module_or_gen_item_declaration = 183, /* module_or_gen_item_declaration  */
  YYSYMBOL_param_declarator = 184,         /* param_declarator  */
  YYSYMBOL_param_decl_item = 185,          /* param_decl_item  */
  YYSYMBOL_param_declaration = 186,        /* param_declaration  */
  YYSYMBOL_specparam_declaration = 187,    /* specparam_declaration  */
  YYSYMBOL_genvar_declaration = 188,       /* genvar_declaration  */
  YYSYMBOL_int_declaration = 189,          /* int_declaration  */
  YYSYMBOL_net_declaration = 190,          /* net_declaration  */
  YYSYMBOL_net_decl_a = 191,               /* net_decl_a  */
  YYSYMBOL_net_decl_b = 192,               /* net_decl_b  */
  YYSYMBOL_vector_or_scalar = 193,         /* vector_or_scalar  */
  YYSYMBOL_variable_type = 194,            /* variable_type  */
  YYSYMBOL_reg_declaration = 195,          /* reg_declaration  */
  YYSYMBOL_net_type = 196,                 /* net_type  */
  YYSYMBOL_drive_strength = 197,           /* drive_strength  */
  YYSYMBOL_strength0 = 198,                /* strength0  */
  YYSYMBOL_strength1 = 199,                /* strength1  */
  YYSYMBOL_delay3 = 200,                   /* delay3  */
  YYSYMBOL_specparam_assignment_list = 201, /* specparam_assignment_list  */
  YYSYMBOL_specparam_assignment = 202,     /* specparam_assignment  */
  YYSYMBOL_func_declaration = 203,         /* func_declaration  */
  YYSYMBOL_func_declarator = 204,          /* func_declarator  */
  YYSYMBOL_func_item_decl_list = 205,      /* func_item_decl_list  */
  YYSYMBOL_block_item_decl_list = 206,     /* block_item_decl_list  */
  YYSYMBOL_func_item_declaration = 207,    /* func_item_declaration  */
  YYSYMBOL_func_port_list = 208,           /* func_port_list  */
  YYSYMBOL_task_declaration = 209,         /* task_declaration  */
  YYSYMBOL_task_item_decl_list = 210,      /* task_item_decl_list  */
  YYSYMBOL_task_item_declaration = 211,    /* task_item_declaration  */
  YYSYMBOL_task_port_list = 212,           /* task_port_list  */
  YYSYMBOL_tf_port_declarator = 213,       /* tf_port_declarator  */
  YYSYMBOL_tf_declaration = 214,           /* tf_declaration  */
  YYSYMBOL_block_item_declaration = 215,   /* block_item_declaration  */
  YYSYMBOL_gate_instantiation = 216,       /* gate_instantiation  */
  YYSYMBOL_gatetype = 217,                 /* gatetype  */
  YYSYMBOL_module_instantiation = 218,     /* module_instantiation  */
  YYSYMBOL_generated_instantiation = 219,  /* generated_instantiation  */
  YYSYMBOL_gen_item_list = 220,            /* gen_item_list  */
  YYSYMBOL_gen_item_or_null = 221,         /* gen_item_or_null  */
  YYSYMBOL_gen_item = 222,                 /* gen_item  */
  YYSYMBOL_gen_cond_statement = 223,       /* gen_cond_statement  */
  YYSYMBOL_gen_case_statement = 224,       /* gen_case_statement  */
  YYSYMBOL_genvar_case_item_list = 225,    /* genvar_case_item_list  */
  YYSYMBOL_genvar_case_item = 226,         /* genvar_case_item  */
  YYSYMBOL_gen_loop_statement = 227,       /* gen_loop_statement  */
  YYSYMBOL_gen_block = 228,                /* gen_block  */
  YYSYMBOL_udp_declaration = 229,          /* udp_declaration  */
  YYSYMBOL_continuous_assign = 230,        /* continuous_assign  */
  YYSYMBOL_blocking_assignment = 231,      /* blocking_assignment  */
  YYSYMBOL_nonblocking_assignment = 232,   /* nonblocking_assignment  */
  YYSYMBOL_func_stmt_or_null = 233,        /* func_stmt_or_null  */
  YYSYMBOL_func_seq_block = 234,           /* func_seq_block  */
  YYSYMBOL_func_stmt_list = 235,           /* func_stmt_list  */
  YYSYMBOL_stmt_list = 236,                /* stmt_list  */
  YYSYMBOL_seq_block = 237,                /* seq_block  */
  YYSYMBOL_statement = 238,                /* statement  */
  YYSYMBOL_stmt_or_null = 239,             /* stmt_or_null  */
  YYSYMBOL_func_statement = 240,           /* func_statement  */
  YYSYMBOL_event_control = 241,            /* event_control  */
  YYSYMBOL_disable_statement = 242,        /* disable_statement  */
  YYSYMBOL_procedural_timing_control_statement = 243, /* procedural_timing_control_statement  */
  YYSYMBOL_cond_statement = 244,           /* cond_statement  */
  YYSYMBOL_func_cond_statement = 245,      /* func_cond_statement  */
  YYSYMBOL_case_statement = 246,           /* case_statement  */
  YYSYMBOL_case_item_list = 247,           /* case_item_list  */
  YYSYMBOL_case_item = 248,                /* case_item  */
  YYSYMBOL_func_case_statement = 249,      /* func_case_statement  */
  YYSYMBOL_func_case_item_list = 250,      /* func_case_item_list  */
  YYSYMBOL_func_case_item = 251,           /* func_case_item  */
  YYSYMBOL_func_loop_statement = 252,      /* func_loop_statement  */
  YYSYMBOL_loop_statement = 253,           /* loop_statement  */
  YYSYMBOL_concat = 254,                   /* concat  */
  YYSYMBOL_multi_concat = 255,             /* multi_concat  */
  YYSYMBOL_sys_caller = 256,               /* sys_caller  */
  YYSYMBOL_expression = 257,               /* expression  */
  YYSYMBOL_postfix_expression = 258,       /* postfix_expression  */
  YYSYMBOL_range = 259,                    /* range  */
  YYSYMBOL_unary_expression = 260,         /* unary_expression  */
  YYSYMBOL_pow_expression = 261,           /* pow_expression  */
  YYSYMBOL_multiplicative_expression = 262, /* multiplicative_expression  */
  YYSYMBOL_additive_expression = 263,      /* additive_expression  */
  YYSYMBOL_shift_expression = 264,         /* shift_expression  */
  YYSYMBOL_relational_expression = 265,    /* relational_expression  */
  YYSYMBOL_equality_expression = 266,      /* equality_expression  */
  YYSYMBOL_and_expression = 267,           /* and_expression  */
  YYSYMBOL_xor_expression = 268,           /* xor_expression  */
  YYSYMBOL_bit_or_expression = 269,        /* bit_or_expression  */
  YYSYMBOL_logical_and_expression = 270,   /* logical_and_expression  */
  YYSYMBOL_logical_or_expression = 271,    /* logical_or_expression  */
  YYSYMBOL_conditional_expression = 272,   /* conditional_expression  */
  YYSYMBOL_assignment_expression = 273,    /* assignment_expression  */
  YYSYMBOL_mintypmax_expression = 274,     /* mintypmax_expression  */
  YYSYMBOL_primary = 275,                  /* primary  */
  YYSYMBOL_attr_inst_list = 276,           /* attr_inst_list  */
  YYSYMBOL_attr_instance = 277             /* attr_instance  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  53
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   8319

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  169
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  109
/* YYNRULES -- Number of rules.  */
#define YYNRULES  454
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  925

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   397


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   128,     2,   134,     2,   125,   130,     2,
     143,   144,   123,   120,   141,   122,   142,   124,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   145,   140,
     127,   121,   126,   133,   135,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   136,     2,   137,   132,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   138,   131,   139,   129,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   146,   147,   148,   149,   150,
     151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
     161,   162,   163,   164,   165,   166,   167,   168
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   328,   328,   340,   343,   346,   349,   356,   361,   367,
     372,   379,   384,   390,   395,   405,   412,   420,   428,   435,
     442,   450,   461,   465,   473,   477,   481,   489,   493,   501,
     507,   514,   520,   527,   533,   540,   546,   556,   557,   561,
     567,   573,   582,   589,   596,   603,   610,   617,   624,   631,
     642,   649,   656,   663,   670,   677,   684,   691,   698,   705,
     712,   719,   726,   733,   740,   752,   756,   760,   764,   768,
     772,   776,   780,   784,   788,   795,   799,   803,   807,   811,
     815,   819,   823,   827,   834,   838,   842,   846,   850,   854,
     866,   874,   882,   890,   898,   906,   917,   924,   934,   941,
     946,   950,   955,   964,   972,   980,   988,   997,  1009,  1018,
    1027,  1036,  1045,  1054,  1063,  1072,  1081,  1090,  1102,  1112,
    1125,  1131,  1140,  1142,  1144,  1146,  1148,  1150,  1155,  1161,
    1167,  1173,  1179,  1185,  1197,  1203,  1209,  1215,  1221,  1227,
    1233,  1239,  1249,  1254,  1259,  1264,  1269,  1274,  1282,  1288,
    1294,  1300,  1309,  1315,  1321,  1327,  1337,  1341,  1349,  1352,
    1359,  1367,  1376,  1385,  1394,  1403,  1412,  1421,  1430,  1439,
    1448,  1457,  1466,  1478,  1486,  1494,  1502,  1510,  1518,  1526,
    1537,  1541,  1548,  1552,  1559,  1563,  1570,  1574,  1582,  1588,
    1594,  1600,  1606,  1612,  1619,  1626,  1636,  1640,  1647,  1651,
    1658,  1662,  1669,  1676,  1683,  1690,  1700,  1706,  1713,  1719,
    1726,  1732,  1739,  1746,  1757,  1761,  1765,  1769,  1774,  1778,
    1794,  1799,  1804,  1809,  1821,  1827,  1833,  1839,  1845,  1851,
    1857,  1863,  1869,  1875,  1881,  1887,  1900,  1906,  1918,  1922,
    1929,  1933,  1940,  1944,  1951,  1955,  1960,  1965,  1969,  1973,
    1977,  1984,  1991,  2001,  2011,  2015,  2022,  2027,  2032,  2040,
    2049,  2058,  2064,  2070,  2081,  2091,  2100,  2112,  2117,  2122,
    2128,  2139,  2142,  2155,  2160,  2165,  2170,  2179,  2184,  2192,
    2197,  2205,  2209,  2217,  2222,  2227,  2233,  2239,  2245,  2254,
    2258,  2265,  2269,  2276,  2281,  2286,  2292,  2298,  2304,  2314,
    2319,  2323,  2327,  2331,  2335,  2339,  2343,  2347,  2351,  2355,
    2359,  2363,  2367,  2371,  2375,  2379,  2383,  2387,  2394,  2398,
    2402,  2409,  2415,  2419,  2423,  2427,  2431,  2435,  2440,  2446,
    2450,  2454,  2458,  2462,  2466,  2475,  2482,  2488,  2492,  2499,
    2510,  2518,  2524,  2533,  2539,  2549,  2555,  2561,  2570,  2574,
    2581,  2585,  2589,  2596,  2602,  2608,  2617,  2621,  2628,  2632,
    2636,  2644,  2651,  2657,  2665,  2672,  2678,  2703,  2711,  2723,
    2727,  2736,  2740,  2744,  2748,  2756,  2760,  2764,  2769,  2777,
    2781,  2785,  2789,  2796,  2800,  2804,  2808,  2812,  2816,  2820,
    2824,  2828,  2832,  2836,  2840,  2845,  2850,  2854,  2861,  2865,
    2870,  2875,  2880,  2888,  2892,  2897,  2902,  2910,  2914,  2919,
    2927,  2931,  2936,  2941,  2946,  2954,  2958,  2963,  2968,  2973,
    2981,  2985,  2990,  2995,  3000,  3008,  3012,  3020,  3024,  3032,
    3036,  3044,  3048,  3056,  3060,  3067,  3071,  3078,  3082,  3091,
    3101,  3107,  3113,  3119,  3125,  3132,  3137,  3144,  3151,  3156,
    3161,  3165,  3180,  3183,  3189
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "MY_EOF",
  "vPORT_DELIM", "vPARAM_DELIM", "vEVENT_ALL", "vDUMMY_PORT", "vSIGN_FUNC",
  "vUNSIGN_FUNC", "vNOT_SUPPORTED", "vALWAYS", "vALWAYS_COMB",
  "vALWAYS_FF", "vALWAYS_LATCH", "vAND_ASCII", "vASSIGN", "vAUTO",
  "vBEGIN", "vBIT", "vBUF_ASCII", "vBUFIF_A", "vBYTE", "vBUFIF_B", "vCASE",
  "vCASEX", "vCASEZ", "vCELL", "vCONFIG", "vDEFAULT", "vDESIGN",
  "vDISABLE", "vDO", "vELSE", "vEND", "vENDCASE", "vENDCONFIG", "vENDFUNC",
  "vENDGEN", "vENDMODULE", "vENDSPEC", "vENDTASK", "vFOR", "vFUNC", "vGEN",
  "vGENVAR", "vHIGHZ_A", "vHIGHZ_B", "vIF", "vINC_DIR", "vINIT", "vINOUT",
  "vINPUT", "vINSTANCE", "vINT", "vLIBLIST", "vLIB", "vLOCAL_PARAM",
  "vMODULE", "vNAND_ASCII", "vNEGEDGE", "vNOR_ASCII", "vNOT_ASCII",
  "vNOTIF_A", "vNOTIF_B", "vOR_ASCII", "vOUTPUT", "vPARAMETER", "vPOSEDGE",
  "vPULL_A", "vPULL_B", "vREG", "vSHORTINT", "vTRIAND", "vTRIOR",
  "vSCALARED", "vSIGNED", "vSPECIFY", "vSPEC_PARAM", "vSTRONG_A",
  "vSTRONG_B", "vSUPPLY_A", "vSUPPLY_B", "vTASK", "vTIME", "vTRI", "vUSE",
  "vUNSIGNED", "vVECTORED", "vWAND", "vWEAK_A", "vWEAK_B", "vWHILE",
  "vWIRE", "vWOR", "vLONGINT", "vXNOR_ASCII", "vXOR_ASCII", "vIDENT",
  "vLOGIC", "vNUMBER", "vSYS_IDENT", "vCONCAT_IDENT", "vUNSIGNED_NUM",
  "vARITH_LS", "vARITH_RS", "vANDAND", "vXNOR", "vNAND", "vNOR", "vPOW",
  "vOROR", "vLE", "vGE", "vLOGIC_LS", "vLOGIC_RS", "vLOGIC_EQ",
  "vLOGIC_INEQ", "vCASE_EQ", "vCASE_INEQ", "'+'", "'='", "'-'", "'*'",
  "'/'", "'%'", "'>'", "'<'", "'!'", "'~'", "'&'", "'|'", "'^'", "'?'",
  "'#'", "'@'", "'['", "']'", "'{'", "'}'", "';'", "','", "'.'", "'('",
  "')'", "':'", "vATTR_L", "vATTR_R", "vPRIMITIVE", "vENDPRI", "vSTR",
  "vFILE", "vRANGE_ADD", "vRANGE_SUB", "vPATHPULSE", "LOWER_THAN_ELSE",
  "LOWER_THAN_A", "LOWER_THAN_B", "LOWER_THAN_C", "UOR", "UAND", "UNEG",
  "UNAND", "UNOR", "UXNOR", "UXOR", "ULNOT", "UADD", "UMINUS", "$accept",
  "verilog_synthesis_unit", "source_text", "module_declaration",
  "module_port_part", "module_item_list", "param_decl_list",
  "port_decl_list", "port_declaration", "port_term", "in_or_out",
  "port_type", "module_item", "module_or_gen_item",
  "module_or_gen_item_declaration", "param_declarator", "param_decl_item",
  "param_declaration", "specparam_declaration", "genvar_declaration",
  "int_declaration", "net_declaration", "net_decl_a", "net_decl_b",
  "vector_or_scalar", "variable_type", "reg_declaration", "net_type",
  "drive_strength", "strength0", "strength1", "delay3",
  "specparam_assignment_list", "specparam_assignment", "func_declaration",
  "func_declarator", "func_item_decl_list", "block_item_decl_list",
  "func_item_declaration", "func_port_list", "task_declaration",
  "task_item_decl_list", "task_item_declaration", "task_port_list",
  "tf_port_declarator", "tf_declaration", "block_item_declaration",
  "gate_instantiation", "gatetype", "module_instantiation",
  "generated_instantiation", "gen_item_list", "gen_item_or_null",
  "gen_item", "gen_cond_statement", "gen_case_statement",
  "genvar_case_item_list", "genvar_case_item", "gen_loop_statement",
  "gen_block", "udp_declaration", "continuous_assign",
  "blocking_assignment", "nonblocking_assignment", "func_stmt_or_null",
  "func_seq_block", "func_stmt_list", "stmt_list", "seq_block",
  "statement", "stmt_or_null", "func_statement", "event_control",
  "disable_statement", "procedural_timing_control_statement",
  "cond_statement", "func_cond_statement", "case_statement",
  "case_item_list", "case_item", "func_case_statement",
  "func_case_item_list", "func_case_item", "func_loop_statement",
  "loop_statement", "concat", "multi_concat", "sys_caller", "expression",
  "postfix_expression", "range", "unary_expression", "pow_expression",
  "multiplicative_expression", "additive_expression", "shift_expression",
  "relational_expression", "equality_expression", "and_expression",
  "xor_expression", "bit_or_expression", "logical_and_expression",
  "logical_or_expression", "conditional_expression",
  "assignment_expression", "mintypmax_expression", "primary",
  "attr_inst_list", "attr_instance", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-746)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      57,   -13,  6561,   -35,   106,    39,  -746,  -746,    83,  -746,
     241,  -746,   -14,   -10,  6663,  6663,  -746,  -746,     3,  6663,
    6663,  6663,  6663,  6663,  6663,  6663,  6663,  6663,  6663,  6561,
     104,  6561,  -746,  -746,  -746,   -46,   -26,   134,   156,   496,
     114,   137,   111,   551,   141,   153,   197,   270,   -52,  -746,
    -746,  -746,  -746,  -746,  -746,  -746,  -746,   200,   198,  -746,
     239,  1928,  5278,   254,  6561,  6561,  -746,  -746,  6561,  -746,
    -746,  -746,  -746,  -746,  -746,  -746,  -746,  -746,  -746,   336,
     257,   145,   276,  6561,  6561,  -746,  6561,  1487,  -746,  6663,
    6663,  6663,  6663,  6663,  6663,  6663,  6663,  6663,  6663,  6663,
    6663,  6663,  6663,  6663,  6663,  6663,  6663,  6663,  6663,  6663,
    6663,  6663,  6663,  6663,  6663,  6663,  6561,   291,  -746,   176,
     286,  4689,  4689,  4689,  4689,  -746,  6008,  -746,  -746,  -746,
    -746,  -746,  -746,    26,  7330,  6561,  4689,  -746,  -746,  6561,
      20,  -746,  -746,  -746,  -746,  -746,  -746,  -746,    22,  -746,
    -746,  -746,  -746,  1767,  -746,  -746,    28,  -746,  -746,  -746,
    -746,  -746,  -746,  -746,  6063,  -746,  2019,  -746,  3577,  -746,
    -746,  -746,  6118,   303,  -746,  -746,  -746,  -746,  -746,  5575,
    -746,  5343,  -746,  -746,  -746,  6008,  -746,  -746,  -746,  6796,
    -746,    29,  -746,   133,    68,  2109,   174,   185,   204,  6561,
    -746,   299,  6173,  -746,  6561,  -746,  -746,  -746,   147,  -746,
     205,  -746,  -746,  -746,  -746,  -746,  -746,   156,   156,   156,
     496,   496,   114,   114,   114,   114,   137,   137,   137,   137,
     111,   111,   111,   111,   551,   141,   153,   197,   270,    85,
    2199,   310,    77,  -746,  -746,  3769,   328,   365,   369,   367,
    4689,   375,   408,   422,   116,    14,   343,   355,  -746,  -746,
    3964,  -746,  -746,  -746,  -746,  -746,  -746,   442,  4689,  -746,
    -746,  -746,  6637,  5132,  6228,  6561,    67,    23,  -746,   473,
     240,   -43,   479,  6885,   429,  -746,   446,   447,  -746,  7419,
    -746,  -746,  -746,  -746,  -746,   364,  -746,   381,  -746,  -746,
    -746,  -746,   445,   -72,  -746,   384,  1784,   502,   351,   462,
     389,  -746,  -746,   -20,   517,   526,    -4,   545,  -746,  -746,
    -746,   548,    16,  6118,   159,   396,  6561,     8,  6561,  -746,
    6118,  6118,   403,  6561,  -746,   406,  -746,  6561,  6561,   406,
     790,  -746,   433,  -746,  6228,  6561,   451,  3577,  -746,  -746,
    -746,  -746,    68,  -746,  -746,  -746,  2289,  -746,  -746,  -746,
     155,  -746,  -746,   214,   167,  -746,  6561,  6561,  6561,  -746,
    6663,  -746,  2379,  2469,   176,   176,   486,  -746,   533,  4104,
    -746,  6561,  6561,  6561,   503,   554,  6561,  6561,  6561,  -746,
    6561,  -746,  -746,  -746,  6561,  -746,  -746,  -746,  -746,  -746,
    4159,  6283,  6283,  -746,   505,   514,  -746,  -746,  -746,  -746,
    -746,  -746,  -746,   407,  6561,     8,   520,   522,  -746,  -746,
    -746,  -746,  -746,  -746,  -746,  -746,   536,   540,  6561,   461,
     474,  -746,  -746,   604,  -746,   527,    68,   359,   593,   366,
    -746,   597,  7508,  6561,  6356,  6561,  -746,  -746,  -746,  -746,
    -746,  -746,   549,  -746,    87,   515,   417,  2642,    68,  6561,
    -746,  -746,  -746,  -746,  -746,  -746,  -746,  -746,  -746,  -746,
    -746,   396,  6561,  -746,  -746,  -746,  -746,   396,     8,   531,
    6561,   538,  6561,  -746,   542,  -746,   556,   544,   547,  -746,
     556,  -746,  -746,  6561,   553,   559,  -746,  6118,   396,  6561,
    -746,  -746,  -746,  6561,   304,   394,   497,  -746,  -746,  -746,
    2559,  -746,  -746,  5431,  2922,  -746,  -746,   216,   218,   244,
    -746,   563,   574,   245,   251,   252,   262,  -746,  6561,     8,
    6561,     8,  -746,  -746,   160,   506,   737,   789,   840,   577,
    -746,  -746,  -746,  5496,  -746,  -746,  -746,  2782,  -746,   558,
    -746,   527,    30,  -746,    68,   527,    68,   421,   527,    68,
    7597,  -746,   274,   615,   583,   275,  -746,  -746,  -746,  2642,
      68,  2642,  -746,  -746,  -746,   668,  2642,    36,  -746,   289,
    -746,   396,  -746,  -746,   592,  -746,   611,  -746,  -746,  -746,
    -746,  -746,   621,  -746,  -746,   396,  6561,  -746,   396,     8,
    -746,  -746,  -746,  -746,  -746,    42,   296,  -746,  3062,  -746,
    4299,  3202,  6421,  6421,  6421,  6561,  6561,  3964,  4689,   579,
    -746,     8,     8,  6561,   578,   581,   584,   585,   587,   590,
    -746,  -746,   660,  -746,  6118,     8,  6561,  4354,   599,   602,
     605,  5211,   606,   607,   612,  -746,  -746,   717,  -746,  -746,
    -746,  -746,  -746,   624,  2782,  -746,  5496,  -746,  -746,  -746,
      68,   618,  2782,    50,   527,    68,  2782,    56,  -746,  7686,
    6488,   642,  6561,  7241,  2642,   728,    60,  -746,   730,  -746,
      68,   640,  6561,  -746,  -746,  -746,  -746,  -746,   396,  -746,
    -746,  -746,  -746,  -746,  4494,  -746,  3909,  5601,  -746,   179,
    5656,  5733,   298,   627,   748,  -746,  -746,   639,  -746,  -746,
    -746,  -746,  -746,  -746,  -746,     8,  6561,     8,  -746,   692,
    4744,  -746,  5211,  6561,  6561,  6561,   701,  6561,  6561,  6561,
    -746,  -746,  -746,  -746,  -746,  -746,  -746,  -746,   632,  6118,
       8,  6561,  -746,  3714,   757,   658,  2782,    62,   764,   665,
    -746,  6974,  5788,  -746,   192,  6561,   645,  -746,   776,  -746,
    -746,   770,  -746,   679,  -746,  -746,  3202,   647,  -746,  -746,
    3964,  -746,  -746,  -746,  3964,  -746,  -746,   681,  6561,  3964,
    -746,     8,  3342,  -746,  -746,   312,   322,   326,   670,   651,
     332,   340,  -746,     8,  6561,     8,  3714,   793,  3714,  -746,
    3714,   796,   694,  -746,  3714,  7241,  -746,  -746,  -746,  7241,
     662,  6561,  7241,  -746,  3202,  3202,   797,  -746,  -746,  -746,
    -746,   344,  -746,  -746,  3482,  4871,  6505,  6505,  6505,  6561,
    6561,  4926,  5211,     8,   805,  -746,  3714,   806,  -746,  3714,
    3714,   807,  -746,  -746,  6561,   345,  -746,  3202,   815,   816,
    -746,  4689,  -746,  5053,  -746,  4549,  5843,  -746,   193,  5898,
    5953,   346,   682,  -746,   828,  -746,  -746,  -746,   825,  -746,
    3714,   826,   830,  -746,   688,   855,   835,  -746,  -746,  -746,
    -746,  4926,  -746,  -746,  -746,  4926,  -746,  -746,   739,  6561,
    4926,  -746,   845,  -746,  -746,  6561,  7063,  -746,  -746,  -746,
    -746,   352,  -746,  -746,   356,  -746,   785,  7775,  5211,   866,
    7864,  -746,  -746,  7152,  -746,  7953,  -746,   788,  8042,  -746,
    8131,  -746,  -746,  8220,  -746
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int16 yydefact[] =
{
       0,     0,     0,     0,     0,     0,     3,     4,     0,   452,
       0,   372,     0,     0,     0,     0,   442,   440,   443,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   441,   448,   449,     0,   383,   398,   403,   407,
     410,   415,   420,   425,   427,   429,   431,   433,   435,   437,
     371,   375,   271,     1,     2,     5,     6,     0,     0,   453,
       0,     0,     0,     0,     0,     0,   395,   394,     0,   391,
     389,   390,   384,   385,   392,   386,   387,   388,   393,     0,
     445,     0,     0,     0,     0,   454,     0,     0,   378,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   272,     0,
       0,     0,     0,     0,     0,   228,     0,   124,   234,   224,
     125,   225,     7,     0,     0,     0,     0,    41,    39,     0,
      90,   229,   231,   235,   226,   227,   230,    40,    91,   122,
     126,   137,   138,     0,   134,   135,     0,   136,   140,   139,
     141,   127,   233,   232,     0,   123,     0,    65,     0,    22,
      66,    75,     0,     0,    68,    69,    87,    86,    84,     0,
      85,     0,    89,    88,    77,     0,    78,    67,    76,     0,
      15,     0,    27,     0,     0,     0,     0,     0,     0,     0,
     367,     0,     0,   450,     0,   451,   374,   373,     0,   376,
       0,   438,   402,   400,   401,   399,   398,   405,   406,   404,
     408,   409,   414,   413,   412,   411,   418,   419,   417,   416,
     421,   422,   423,   424,   426,   428,   430,   432,   434,     0,
       0,     0,     0,    24,    74,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   443,     0,     0,     0,   307,    80,
       0,   303,   306,   302,   301,   304,   308,     0,     0,    81,
      82,    83,     0,     0,     0,     0,     0,   176,   173,   174,
       0,     0,     0,     0,     0,   238,     0,     0,   250,     0,
     240,   244,   247,   248,   249,     0,    79,     0,    93,    92,
      95,    94,     0,     0,   158,     0,     0,     0,     0,     0,
       0,     9,    23,    56,    59,    47,    45,    61,    42,    48,
      49,    63,    53,     0,    43,    38,     0,    96,     0,    98,
       0,     0,     0,     0,   121,   109,   120,     0,     0,   110,
     118,   111,     0,   108,     0,     0,     0,     0,    70,    72,
      73,    71,     0,    17,    16,     8,     0,   396,   397,   444,
       0,   368,   447,     0,     0,   379,     0,     0,     0,   377,
       0,    11,     0,     0,     0,     0,    18,   293,     0,     0,
     291,     0,     0,     0,     0,     0,     0,     0,     0,   369,
       0,   338,   335,   337,     0,   300,   305,   319,   318,   340,
       0,     0,     0,   299,     0,     0,   316,   312,   315,   311,
     310,   313,   317,     0,     0,   156,     0,     0,   150,   154,
     149,   153,   148,   152,   151,   155,     0,     0,     0,     0,
       0,   273,   177,   178,   175,     0,     0,     0,     0,     0,
     267,     0,     0,     0,     0,     0,   239,   241,   103,   104,
     160,   100,     0,    99,     0,     0,     0,     0,     0,     0,
     236,    57,    58,    60,    52,    46,    51,    62,    64,    54,
      55,    38,     0,    44,    50,    37,    29,    38,    97,     0,
       0,     0,     0,   128,     0,   114,   112,     0,     0,   115,
     113,   119,   105,     0,     0,     0,   220,     0,    38,     0,
      28,    10,   446,     0,     0,     0,     0,   436,    13,    12,
       0,    26,    25,     0,     0,   294,   292,     0,     0,     0,
     339,     0,     0,     0,     0,     0,     0,   320,     0,   280,
       0,   278,   309,   314,     0,     0,     0,     0,     0,     0,
     274,   275,   179,     0,   216,   215,   214,     0,   180,     0,
     184,     0,     0,   186,     0,     0,     0,     0,     0,     0,
       0,   268,     0,     0,     0,     0,   159,   102,   101,     0,
       0,     0,   196,   199,   198,     0,     0,     0,   200,     0,
      30,    38,    33,   129,     0,   132,     0,   130,   116,   106,
     107,   117,     0,   221,   222,    38,     0,    31,    38,   439,
     380,   381,   382,    14,    19,     0,     0,   295,     0,   182,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   444,
     336,   279,   277,     0,     0,     0,     0,     0,     0,     0,
     276,   205,   203,   202,     0,   206,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   181,   325,     0,   326,   323,
     322,   324,   327,     0,     0,   185,     0,   218,   219,   217,
       0,     0,     0,     0,     0,     0,     0,     0,   269,     0,
       0,     0,     0,     0,     0,     0,     0,   197,     0,   188,
       0,     0,     0,    34,   131,   133,   223,    32,    38,    35,
      21,    20,   297,   183,     0,   296,     0,     0,   348,     0,
       0,     0,     0,     0,   341,   365,   370,   373,   146,   147,
     144,   142,   145,   143,   204,   207,     0,   210,   283,     0,
       0,   289,     0,     0,     0,     0,     0,     0,     0,     0,
     161,   321,   332,   333,   330,   329,   331,   334,     0,     0,
     208,     0,   187,     0,     0,     0,     0,     0,     0,     0,
     270,     0,     0,   254,     0,     0,     0,   243,   251,   242,
      76,     0,   190,     0,   189,   201,     0,     0,    36,   298,
       0,   351,   345,   349,     0,   347,   346,     0,     0,     0,
     157,   211,     0,   284,   290,     0,     0,     0,     0,     0,
       0,     0,   328,   209,     0,   212,     0,     0,     0,   167,
       0,     0,     0,   164,     0,     0,   257,   253,   255,     0,
       0,     0,     0,   191,     0,     0,     0,   237,   352,   350,
     366,     0,   342,   285,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   213,     0,   162,     0,     0,   170,     0,
       0,     0,   258,   256,     0,     0,   252,     0,     0,     0,
     192,     0,   287,     0,   286,     0,     0,   356,     0,     0,
       0,     0,     0,   282,   343,   281,   362,   163,     0,   168,
       0,     0,     0,   165,     0,     0,     0,   194,   193,   364,
     288,     0,   359,   353,   357,     0,   355,   354,     0,     0,
       0,   169,     0,   171,   166,     0,     0,   195,   360,   358,
     363,     0,   344,   172,     0,   261,     0,     0,     0,     0,
       0,   262,   361,     0,   259,     0,   265,     0,     0,   260,
       0,   266,   263,     0,   264
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -746,  -746,  -746,   890,   780,  -182,  -746,   385,   -61,  -420,
     -31,   565,  -157,   -50,  -746,  -746,  -113,   -59,   710,  -746,
     360,  -746,   561,  -746,  -746,  -746,   903,  -158,   -95,    89,
      31,  -122,   596,   453,  -746,  -746,  -517,  -691,  -535,  -512,
    -746,   337,  -546,   350,   258,  -387,  -392,  -746,  -746,  -746,
     721,  -280,  -701,  -271,  -746,  -746,  -746,   161,  -746,  -746,
     911,   249,  -246,  -245,  -636,  -633,  -745,  -466,  -244,  -107,
    -578,    64,  -154,   552,  -241,  -240,  -628,  -233,  -338,  -613,
    -622,  -414,  -432,  -601,  -232,   844,  -746,   802,   673,  -746,
     -28,  1709,   555,   435,   676,   745,   784,   814,   820,   822,
     813,   818,  -746,   567,   839,  -746,  -746,     0,    -1
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     4,     5,     6,    63,   166,   242,   191,   167,   476,
     543,   323,   169,   288,   171,   172,   173,   544,   175,   176,
     177,   178,   337,   338,   339,   179,   180,   181,   274,   426,
     427,   341,   303,   304,   182,   281,   547,   608,   548,   552,
     183,   571,   572,   577,   634,   549,   550,   184,   185,   186,
     187,   289,   758,   290,   291,   292,   752,   753,   293,   294,
       7,   188,   256,   257,   864,   646,   720,   379,   258,   398,
     399,   865,   260,   261,   262,   263,   649,   264,   697,   698,
     650,   856,   857,   651,   265,    33,    34,   266,   267,    36,
     343,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    82,    51,   268,     9
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
       8,   192,   174,   442,   275,     8,   243,    59,    88,   312,
     324,   170,   645,   356,   259,   269,   270,   271,   447,    83,
     391,   732,   404,   405,   406,   677,   734,   408,   409,   296,
     168,   168,   735,   352,   660,   410,   411,   825,   662,   704,
     680,   666,    54,   277,   663,   307,   352,   667,   610,   553,
     806,   580,   796,   736,   660,   437,   461,   582,   372,   115,
     660,   189,   194,   345,   680,   574,   660,   462,   451,   452,
     573,   578,   465,    83,   298,   815,   300,   432,   597,   853,
     278,   116,   374,   466,   773,    10,   340,   773,   773,   732,
     344,   824,   469,    86,   734,    84,   299,     1,   301,   433,
     735,    85,   279,   470,   842,   282,    53,   174,   843,   836,
      86,   846,   392,   840,    52,     1,   170,    87,   771,   137,
     138,   736,   609,   847,   280,   306,   308,   645,   677,    64,
     349,   645,    83,    65,   147,   168,   174,   393,   380,   348,
     326,    57,   694,   385,   328,   170,    68,   746,   870,    84,
      83,   333,   428,   747,   404,   405,   406,   394,   347,   408,
     409,   683,    86,   347,   168,   732,   189,   410,   411,   553,
     734,   447,   553,   353,   661,   687,   735,   574,   689,   574,
     681,   174,   573,   578,   573,     2,   690,     3,    59,   324,
     170,   510,   818,    59,   745,   189,   819,   736,    83,   312,
     749,   822,    80,     2,   763,     3,   802,   431,    84,   168,
      83,   645,    83,   485,     2,   312,   693,   489,   375,   882,
      83,   376,   493,   103,   104,    83,    84,   567,   452,     2,
     370,    58,    83,   140,    97,   473,    98,   105,   106,    83,
     189,    99,   100,   148,    83,   898,   474,   528,   530,   899,
      83,   101,   102,   438,   902,    89,   389,    83,    83,   390,
     400,   511,   512,    90,    91,    92,    93,    59,   768,    83,
      83,   111,   516,   742,    84,   700,   701,   354,   553,    83,
     669,    83,   574,    83,   365,   112,    84,   573,    84,   203,
     204,   500,   366,   765,   200,   472,    84,   174,   117,   367,
     368,   623,   480,   482,   203,   204,   170,   486,    84,    83,
      83,   490,   503,   174,   174,    84,    83,    83,   357,   499,
      84,   168,   170,   170,   774,   168,    84,    83,   113,   358,
     404,   405,   406,    84,    84,   408,   409,   809,   885,    83,
      83,   168,   168,   410,   411,    84,    84,   118,   359,   369,
     575,   609,   194,   312,    83,    84,   189,    84,   502,    84,
     612,    83,   613,    83,   588,   404,   405,   406,   591,    83,
     408,   409,   189,   189,   609,    60,   114,    83,   410,   411,
     435,    61,   119,   436,    62,    84,    84,    83,   614,   617,
     609,    83,    84,    84,   195,   618,   619,    83,   447,    59,
     202,    83,   759,    84,   693,    83,   620,   380,   609,    83,
      83,    83,   609,   859,   860,    84,    84,    83,   670,   673,
     205,    83,   609,   693,   884,    60,   244,   884,   884,    83,
      84,   240,   693,   682,    62,   551,   554,    84,   361,    84,
     691,   600,   777,   329,   693,    84,    83,   609,   693,    83,
     373,   174,   192,    84,    83,   693,   826,   576,   554,    83,
     170,    83,   675,    84,   678,   384,   827,    84,    83,   596,
     828,   381,    83,    84,   199,   200,   831,    84,   693,   168,
     759,    84,   168,   395,   832,    84,    84,    84,   851,   875,
     888,   457,   657,    84,   458,   396,   908,    84,    83,   555,
     909,   380,   556,   516,   448,    84,   558,    83,   382,   559,
     189,   705,   383,   194,   611,   636,    83,   657,   386,   401,
     656,   449,    84,   656,   453,    84,    83,   434,   402,   460,
      84,   601,   220,   221,   759,    84,   475,    84,   759,    83,
     272,   759,    86,   483,    84,   656,   127,   654,    84,   130,
      59,   387,   657,    59,   401,   551,   554,   569,   551,   554,
     570,   664,    83,   402,   665,   388,   624,   761,   627,   576,
     554,   576,   443,   492,    84,    59,   419,   439,   137,   138,
      83,   139,   403,    84,   140,   450,   421,   516,   423,   444,
     445,   496,    84,   147,   148,   657,    83,   425,   149,   150,
     456,   540,    84,    83,   463,   459,   716,    83,   611,    83,
      59,   647,    83,   464,   541,    84,   907,   400,    83,    94,
      95,    96,   161,   656,    83,   625,   165,   629,   741,   513,
     915,   514,   467,   918,   602,   468,   447,   722,    84,    83,
     923,   722,    83,   520,   447,   532,   521,   447,    83,   217,
     218,   219,   447,    59,   533,   568,    84,    83,   542,   816,
     554,   535,   654,   536,   551,   554,   654,   107,   108,   109,
     110,   583,    84,     2,   576,    35,    83,   537,   585,    84,
     554,   538,   587,    84,   589,    84,    83,   590,    84,    83,
     272,   557,    83,   593,    84,   560,   400,    83,   655,   594,
      84,   721,    79,   302,    81,   726,   615,   848,   849,   679,
      83,   794,    83,   671,   616,    84,    83,   630,    84,   706,
     722,    59,   708,   672,    84,   709,   744,    83,   710,   711,
     748,   712,   684,    84,   713,   193,   714,   196,   197,   657,
     876,   198,   723,   798,   879,   724,   654,    83,   725,   727,
     728,   685,    84,    83,   730,   729,   206,   207,   743,   208,
     210,   686,    84,   755,   731,    84,   611,   778,    84,   762,
     400,   764,   792,    84,   400,   222,   223,   224,   225,   400,
     766,   779,   798,   780,   784,   811,    84,   817,    84,   239,
     782,   830,    84,   788,   799,   545,   798,    59,   800,   276,
     798,   803,   844,    84,   798,   804,   418,   797,   295,   812,
     801,   813,   297,   829,   611,   611,   420,   545,   422,   814,
     407,   820,   889,    84,   798,   722,   305,   424,   895,    84,
     835,   722,   722,   838,   839,   626,   798,   310,   850,   798,
     798,   325,   867,   869,   873,   327,   721,   611,   226,   227,
     228,   229,   332,   722,   342,   722,   877,   878,   346,   419,
     834,   890,   891,   893,   837,   334,   335,   894,   841,   421,
     798,   423,   360,   896,   545,   363,   897,   364,   336,   900,
     425,   722,   903,   910,   913,   722,   920,   628,   721,   784,
     722,   230,   231,   232,   233,    55,   866,   241,   605,   350,
     868,   491,   454,   871,   872,   566,   674,   545,   722,   418,
     351,   658,   497,   808,   739,   545,    56,   784,   545,   420,
     676,   422,   760,   201,   272,   234,    86,   237,   211,   545,
     424,   545,   235,   238,   892,   236,   658,   507,     0,     0,
       0,   413,     0,     0,     0,   415,    81,   429,   430,     0,
       0,     0,   407,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   545,     0,
       0,   658,   912,     0,     0,     0,     0,     0,     0,   455,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   471,     0,     0,   477,
       0,   478,     0,   479,   481,     0,   484,     0,     0,     0,
     487,   488,     0,     0,   658,     0,     0,   494,   495,     0,
     498,     0,   545,     0,   545,     0,   545,     0,     0,     0,
       0,     0,     0,     0,   545,     0,     0,     0,     0,   504,
     505,   506,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   517,   518,   519,     0,     0,   522,
     523,   524,     0,   525,     0,     0,     0,   526,     0,     0,
     412,     0,     0,   413,   529,   531,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   534,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   648,
       0,   539,     0,   545,     0,     0,   545,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   562,   564,   565,     0,
       0,     0,     0,     0,     0,     0,   545,     0,   407,     0,
       0,     0,   579,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   545,     0,     0,   581,     0,     0,     0,     0,
       0,     0,     0,   584,     0,   586,   545,     0,   658,     0,
     545,     0,     0,   407,   545,     0,   592,     0,     0,     0,
     595,     0,   598,     0,   545,   545,   599,     0,     0,     0,
       0,     0,     0,     0,   545,     0,   606,     0,     0,   648,
       0,     0,     0,   648,     0,     0,   545,     0,     0,   545,
     545,   621,   412,   622,     0,     0,   733,   545,     0,     0,
       0,     0,     0,     0,   648,     0,   635,     0,   648,     0,
     653,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     545,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   413,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   688,
       0,     0,   648,     0,   733,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   413,   699,   699,   699,   702,   703,
       0,     0,     0,     0,     0,   648,   707,     0,   648,     0,
       0,     0,     0,     0,     0,     0,     0,   715,     0,   717,
     653,     0,     0,     0,   653,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   738,     0,   740,
       0,     0,     0,     0,   648,   653,     0,     0,   546,   653,
       0,     0,     0,   754,     0,   756,     0,     0,   648,   652,
     733,     0,   648,     0,     0,   767,   648,     0,     0,     0,
     546,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     699,     0,     0,   699,   699,     0,   648,   648,   412,     0,
       0,     0,     0,   648,   648,     0,     0,     0,   648,   781,
       0,   648,   648,   653,     0,   738,   785,   786,   787,     0,
     789,   790,   791,     0,     0,   648,     0,   648,     0,     0,
       0,     0,   793,   412,   795,     0,   653,   546,     0,   653,
       0,     0,   648,     0,     0,   754,     0,     0,   810,     0,
       0,     0,     0,   648,     0,     0,     0,   648,     0,   652,
       0,     0,   648,   652,     0,     0,     0,     0,     0,     0,
     546,   821,     0,     0,   659,   653,   737,     0,   546,     0,
     648,   546,     0,     0,   652,     0,     0,   833,   652,   653,
       0,   738,   546,   653,   546,     0,     0,   653,     0,   659,
       0,     0,     0,     0,   845,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    11,    12,    13,   653,   653,   858,
     858,   858,   861,   862,   653,   653,     0,     0,     0,   653,
       0,   546,   653,   653,   659,     0,     0,   874,     0,     0,
       0,     0,   652,     0,   737,     0,   653,     0,   653,   858,
       0,     0,   858,   858,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   653,     0,   652,     0,    14,   652,     0,
       0,     0,     0,     0,   653,    15,     0,   659,   653,     0,
       0,     0,   901,   653,     0,   546,     0,   546,   904,   546,
       0,     0,     0,     0,     0,     0,     0,   546,     0,     0,
       0,   653,     0,     0,   652,    16,     0,    17,    18,     0,
       0,     0,     0,     0,    19,    20,    21,     0,   652,     0,
     737,     0,   652,     0,     0,     0,   652,    22,     0,    23,
       0,     0,     0,     0,     0,    24,    25,    26,    27,    28,
       0,     0,     0,     0,     0,    29,   652,   652,     0,    30,
      31,   209,     0,   652,   652,     0,     0,    32,   652,     0,
       0,   652,   652,     0,     0,     0,   546,     0,     0,   546,
       0,     0,     0,     0,     0,   652,     0,   652,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   546,
       0,     0,   652,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   652,     0,   546,     0,   652,     0,     0,
       0,     0,   652,     0,     0,     0,     0,     0,     0,   546,
       0,   659,     0,   546,     0,     0,     0,   546,     0,     0,
     652,     0,     0,     0,     0,     0,     0,   546,   546,     0,
       0,     0,     0,    66,    67,     0,     0,   546,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,     0,   546,
       0,     0,   546,   546,     0,     0,     0,     0,     0,     0,
     546,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   546,    11,    12,    13,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    11,    12,    13,     0,     0,     0,     0,     0,   212,
     213,   214,   215,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   216,     0,     0,    14,     0,     0,
       0,     0,     0,     0,     0,    15,     0,     0,     0,     0,
       0,     0,     0,     0,    14,     0,     0,     0,     0,     0,
       0,     0,    15,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    16,     0,    17,    18,     0,
       0,     0,     0,     0,    19,    20,    21,     0,     0,     0,
       0,     0,    16,     0,    17,    18,     0,    22,     0,    23,
       0,    19,    20,    21,     0,    24,    25,    26,    27,    28,
       0,     0,     0,    86,    22,    29,    23,     0,     0,    30,
      31,     0,    24,    25,    26,    27,    28,    32,     0,     0,
       0,   302,    29,     0,     0,     0,    30,    31,     0,   120,
       0,     0,     0,     0,    32,     0,     0,     0,   302,   121,
     122,   123,   124,   125,   126,     0,     0,   127,   128,   129,
     130,   131,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   132,     0,     0,
       0,   133,   134,   135,     0,     0,     0,     0,   136,   137,
     138,     0,   139,     0,     0,   140,     0,   141,     0,   142,
     143,   144,   145,   146,   147,   148,     0,     0,     0,   149,
     150,   151,   152,     0,     0,     0,   153,     0,     0,   154,
     155,   156,     0,   157,     0,     0,     0,   158,     0,     0,
     120,   159,   160,   161,   162,   163,   164,   165,     0,     0,
     121,   122,   123,   124,   125,   126,     0,     0,   127,   128,
     129,   130,   131,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   311,     0,
       0,     0,   133,   134,   135,     0,     0,     0,     0,   136,
     137,   138,     0,   139,     2,     0,   140,     0,   141,   216,
     142,   143,   144,   145,   146,   147,   148,     0,     0,     0,
     149,   150,   151,   152,     0,     0,     0,   153,     0,     0,
     154,   155,   156,     0,   157,     0,     0,     0,   158,     0,
     120,     0,   159,   160,   161,   162,   163,   164,   165,     0,
     121,   122,   123,   124,   125,   126,     0,     0,   127,   128,
     129,   130,   131,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   355,     0,
       0,     0,   133,   134,   135,     0,     0,     0,     0,   136,
     137,   138,     0,   139,     0,     2,   140,     0,   141,     0,
     142,   143,   144,   145,   146,   147,   148,     0,     0,     0,
     149,   150,   151,   152,     0,     0,     0,   153,     0,     0,
     154,   155,   156,     0,   157,     0,     0,     0,   158,     0,
     120,     0,   159,   160,   161,   162,   163,   164,   165,     0,
     121,   122,   123,   124,   125,   126,     0,     0,   127,   128,
     129,   130,   131,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   371,     0,
       0,     0,   133,   134,   135,     0,     0,     0,     0,   136,
     137,   138,     0,   139,     0,     2,   140,     0,   141,     0,
     142,   143,   144,   145,   146,   147,   148,     0,     0,     0,
     149,   150,   151,   152,     0,     0,     0,   153,     0,     0,
     154,   155,   156,     0,   157,     0,     0,     0,   158,     0,
     120,     0,   159,   160,   161,   162,   163,   164,   165,     0,
     121,   122,   123,   124,   125,   126,     0,     0,   127,   128,
     129,   130,   131,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   501,     0,
       0,     0,   133,   134,   135,     0,     0,     0,     0,   136,
     137,   138,     0,   139,     0,     2,   140,     0,   141,     0,
     142,   143,   144,   145,   146,   147,   148,     0,     0,     0,
     149,   150,   151,   152,     0,     0,     0,   153,     0,     0,
     154,   155,   156,     0,   157,     0,     0,     0,   158,     0,
     120,     0,   159,   160,   161,   162,   163,   164,   165,     0,
     121,   122,   123,   124,   125,   126,     0,     0,   127,   128,
     129,   130,   131,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   508,     0,
       0,     0,   133,   134,   135,     0,     0,     0,     0,   136,
     137,   138,     0,   139,     0,     2,   140,     0,   141,     0,
     142,   143,   144,   145,   146,   147,   148,     0,     0,     0,
     149,   150,   151,   152,     0,     0,     0,   153,     0,     0,
     154,   155,   156,     0,   157,     0,     0,     0,   158,     0,
     120,     0,   159,   160,   161,   162,   163,   164,   165,     0,
     121,   122,   123,   124,   125,   126,     0,     0,   127,   128,
     129,   130,   131,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   509,     0,
       0,     0,   133,   134,   135,     0,     0,     0,     0,   136,
     137,   138,     0,   139,     0,     2,   140,     0,   141,     0,
     142,   143,   144,   145,   146,   147,   148,     0,     0,     0,
     149,   150,   151,   152,     0,     0,     0,   153,     0,     0,
     154,   155,   156,     0,   157,     0,     0,     0,   158,     0,
     120,     0,   159,   160,   161,   162,   163,   164,   165,     0,
     121,   122,   123,   124,   125,   126,     0,     0,   127,   128,
     129,   130,   131,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   603,     0,
       0,     0,   133,   134,   135,     0,     0,     0,     0,   136,
     137,   138,     0,   139,     0,     2,   140,     0,   141,     0,
     142,   143,   144,   145,   146,   147,   148,     0,     0,     0,
     149,   150,   151,   152,     0,     0,     0,   153,     0,     0,
     154,   155,   156,     0,   157,     0,     0,     0,   158,    11,
      12,    13,   159,   160,   161,   162,   163,   164,   165,     0,
     245,   127,     0,     0,   130,     0,   246,   247,   248,     0,
       0,     0,     0,   249,   250,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   251,     0,     0,     0,     0,     0,
     252,     0,     0,   137,   138,     0,   139,     0,     0,   140,
       0,     0,    14,     0,     0,     2,     0,     0,   147,   148,
      15,     0,     0,   149,   150,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   253,     0,     0,   161,     0,     0,
      16,   165,    17,   254,     0,     0,     0,     0,     0,    19,
      20,    21,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    22,     0,    23,     0,     0,     0,     0,     0,
      24,    25,    26,    27,    28,     0,     0,   255,     0,     0,
      29,     0,     0,     0,    30,    31,     0,     0,     2,    11,
      12,    13,    32,     0,     0,     0,     0,     0,     0,     0,
     637,   127,     0,     0,   130,     0,   638,   639,   640,     0,
       0,     0,     0,   249,   641,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   642,     0,     0,     0,     0,     0,
     643,     0,     0,   137,   138,     0,   139,     0,     0,   140,
       0,     0,    14,     0,     0,     0,     0,     0,   147,   148,
      15,     0,     0,   149,   150,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   644,     0,     0,   161,     0,     0,
      16,   165,    17,   254,     0,     0,     0,     0,     0,    19,
      20,    21,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    22,     0,    23,     0,     0,     0,     0,     0,
      24,    25,    26,    27,    28,     0,     0,     0,     0,     0,
      29,     0,     0,     0,    30,    31,     0,     0,     2,    11,
      12,    13,    32,     0,     0,     0,     0,     0,     0,     0,
     245,   127,     0,     0,   130,     0,   246,   247,   248,     0,
       0,     0,     0,   249,   250,     0,   607,     0,     0,     0,
       0,     0,     0,     0,   251,     0,     0,     0,     0,     0,
     252,     0,     0,     0,     0,     0,   139,     0,     0,   140,
       0,     0,    14,     0,     0,     0,     0,     0,     0,   148,
      15,     0,     0,   149,   150,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   253,     0,     0,   161,     0,     0,
      16,   165,    17,   254,     0,     0,     0,     0,     0,    19,
      20,    21,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    22,     0,    23,     0,     0,     0,     0,     0,
      24,    25,    26,    27,    28,     0,     0,   255,     0,     0,
      29,     0,     0,     0,    30,    31,     0,     0,     2,    11,
      12,    13,    32,     0,     0,     0,     0,     0,     0,     0,
     245,   127,     0,     0,   130,     0,   246,   247,   248,     0,
       0,     0,     0,   249,   250,     0,   692,     0,     0,     0,
       0,     0,     0,     0,   251,     0,     0,     0,     0,     0,
     252,     0,     0,     0,     0,     0,   139,     0,     0,   140,
       0,     0,    14,     0,     0,     0,     0,     0,     0,   148,
      15,     0,     0,   149,   150,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   253,     0,     0,   161,     0,     0,
      16,   165,    17,   254,     0,     0,     0,     0,     0,    19,
      20,    21,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    22,     0,    23,     0,     0,     0,     0,     0,
      24,    25,    26,    27,    28,     0,     0,   255,     0,     0,
      29,     0,     0,     0,    30,    31,     0,     0,     2,    11,
      12,    13,    32,     0,     0,     0,     0,     0,     0,     0,
     245,   127,     0,     0,   130,     0,   246,   247,   248,     0,
       0,     0,     0,   249,   250,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   251,     0,     0,     0,     0,     0,
     252,     0,     0,     0,     0,     0,   139,     0,     0,   140,
       0,     0,    14,     0,     0,     0,     0,     0,     0,   148,
      15,     0,     0,   149,   150,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   253,     0,     0,   161,     0,     0,
      16,   165,    17,   254,     0,     0,     0,     0,     0,    19,
      20,    21,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    22,     0,    23,     0,     0,     0,     0,     0,
      24,    25,    26,    27,    28,     0,     0,   255,     0,     0,
      29,     0,     0,     0,    30,    31,     0,     0,     2,    11,
      12,    13,    32,     0,     0,     0,     0,     0,     0,     0,
     637,   127,     0,     0,   130,     0,   638,   639,   640,     0,
       0,     0,     0,   249,   641,     0,   823,     0,     0,     0,
       0,     0,     0,     0,   642,     0,     0,     0,     0,     0,
     643,     0,     0,     0,     0,     0,   139,     0,     0,   140,
       0,     0,    14,     0,     0,     0,     0,     0,     0,   148,
      15,     0,     0,   149,   150,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   644,     0,     0,   161,     0,     0,
      16,   165,    17,   254,     0,     0,     0,     0,     0,    19,
      20,    21,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    22,     0,    23,     0,     0,     0,     0,     0,
      24,    25,    26,    27,    28,     0,     0,     0,     0,     0,
      29,     0,     0,     0,    30,    31,     0,     0,     2,    11,
      12,    13,    32,     0,     0,     0,     0,     0,     0,     0,
     637,   127,     0,     0,   130,     0,   638,   639,   640,     0,
       0,     0,     0,   249,   641,     0,   852,     0,     0,     0,
       0,     0,     0,     0,   642,     0,     0,     0,     0,     0,
     643,     0,     0,     0,     0,     0,   139,     0,     0,   140,
       0,     0,    14,     0,     0,     0,     0,     0,     0,   148,
      15,     0,     0,   149,   150,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   644,     0,     0,   161,     0,     0,
      16,   165,    17,   254,    11,    12,    13,     0,     0,    19,
      20,    21,     0,     0,     0,     0,   313,     0,     0,   314,
       0,     0,    22,     0,    23,     0,     0,     0,     0,     0,
      24,    25,    26,    27,    28,     0,     0,     0,     0,     0,
      29,     0,     0,     0,    30,    31,     0,     0,     2,     0,
       0,   315,    32,     0,     0,     0,     0,    14,     0,     0,
       0,     0,     0,     0,     0,    15,     0,     0,   316,   317,
     151,   152,     0,   318,     0,     0,     0,     0,   154,   155,
       0,   319,   157,     0,   320,     0,   158,     0,     0,     0,
     159,   160,   321,     0,     0,    16,   322,    17,    18,     0,
       0,     0,     0,     0,    19,    20,    21,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    22,     0,    23,
       0,     0,     0,     0,     0,    24,    25,    26,    27,    28,
       0,     0,     0,    86,     0,    29,     0,     0,     0,    30,
      31,    11,    12,    13,     0,     0,     0,    32,     0,     0,
       0,     0,   637,   127,     0,     0,   130,     0,   638,   639,
     640,     0,     0,     0,     0,   249,   641,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   642,     0,     0,     0,
       0,     0,   643,     0,     0,     0,     0,     0,   139,     0,
       0,   140,     0,     0,    14,     0,    11,    12,    13,     0,
       0,   148,    15,     0,     0,   149,   150,   245,     0,     0,
       0,     0,     0,   246,   247,   248,     0,     0,     0,     0,
     249,   250,     0,   377,     0,     0,   644,     0,     0,   161,
       0,   251,    16,   165,    17,   254,     0,   252,     0,     0,
       0,    19,    20,    21,     0,     0,     0,     0,     0,    14,
       0,     0,     0,     0,    22,     0,    23,    15,     0,     0,
       0,     0,    24,    25,    26,    27,    28,     0,     0,     0,
       0,     0,    29,     0,     0,     0,    30,    31,     0,     0,
       2,   253,     0,     0,    32,     0,     0,    16,     0,    17,
     254,     0,     0,     0,     0,     0,    19,    20,    21,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    22,
       0,    23,     0,     0,     0,     0,     0,    24,    25,    26,
      27,    28,     0,     0,   255,     0,     0,    29,     0,     0,
       0,    30,    31,     0,   378,     2,    11,    12,    13,    32,
       0,     0,     0,     0,     0,     0,     0,   245,     0,     0,
       0,     0,     0,   246,   247,   248,     0,     0,     0,     0,
     249,   250,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   251,     0,     0,     0,     0,     0,   252,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    14,
       0,    11,    12,    13,     0,     0,     0,    15,     0,     0,
       0,     0,   245,     0,     0,     0,     0,     0,   246,   247,
     248,     0,     0,     0,     0,   249,   250,     0,     0,     0,
       0,   253,     0,     0,     0,     0,   251,    16,     0,    17,
     254,     0,   252,     0,     0,     0,    19,    20,    21,     0,
       0,     0,     0,     0,    14,     0,     0,     0,     0,    22,
       0,    23,    15,     0,     0,     0,     0,    24,    25,    26,
      27,    28,     0,     0,   255,     0,     0,    29,     0,   397,
       0,    30,    31,     0,   770,     2,   253,     0,     0,    32,
       0,     0,    16,     0,    17,   254,     0,     0,     0,     0,
       0,    19,    20,    21,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    22,     0,    23,     0,     0,     0,
       0,     0,    24,    25,    26,    27,    28,     0,     0,   255,
       0,     0,    29,     0,   397,     0,    30,    31,     0,     0,
       2,    11,    12,    13,    32,     0,     0,     0,     0,     0,
       0,     0,   245,     0,     0,     0,     0,     0,   246,   247,
     248,     0,     0,     0,     0,   249,   250,     0,   515,     0,
       0,     0,     0,     0,     0,     0,   251,     0,     0,     0,
       0,     0,   252,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    14,     0,    11,    12,    13,     0,
       0,     0,    15,     0,     0,     0,     0,   245,     0,     0,
       0,     0,     0,   246,   247,   248,     0,     0,     0,     0,
     249,   250,     0,     0,     0,     0,   253,     0,     0,     0,
       0,   251,    16,     0,    17,   254,     0,   252,     0,     0,
       0,    19,    20,    21,     0,     0,     0,     0,     0,    14,
       0,     0,     0,     0,    22,     0,    23,    15,     0,     0,
       0,     0,    24,    25,    26,    27,    28,     0,     0,   255,
       0,     0,    29,     0,     0,     0,    30,    31,     0,     0,
       2,   253,     0,     0,    32,     0,     0,    16,     0,    17,
     254,     0,     0,     0,     0,     0,    19,    20,    21,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    22,
       0,    23,     0,     0,     0,     0,     0,    24,    25,    26,
      27,    28,     0,     0,   255,     0,     0,    29,     0,   527,
       0,    30,    31,     0,     0,     2,    11,    12,    13,    32,
       0,     0,     0,     0,     0,     0,     0,   245,     0,     0,
       0,     0,     0,   246,   247,   248,     0,     0,     0,     0,
     249,   250,     0,   695,     0,     0,     0,     0,     0,     0,
       0,   251,     0,     0,     0,     0,     0,   252,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    14,
       0,    11,    12,    13,     0,     0,     0,    15,     0,     0,
       0,     0,   637,     0,     0,     0,     0,     0,   638,   639,
     640,     0,     0,     0,     0,   249,   641,     0,   718,     0,
       0,   253,     0,     0,     0,     0,   642,    16,     0,    17,
     254,     0,   643,     0,     0,     0,    19,    20,    21,     0,
       0,     0,     0,     0,    14,     0,     0,     0,     0,    22,
       0,    23,    15,     0,     0,     0,     0,    24,    25,    26,
      27,    28,     0,     0,   255,     0,     0,    29,     0,     0,
       0,    30,    31,     0,     0,     2,   644,     0,     0,    32,
       0,     0,    16,     0,    17,   254,     0,     0,     0,     0,
       0,    19,    20,    21,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    22,     0,    23,     0,     0,     0,
       0,     0,    24,    25,    26,    27,    28,     0,     0,     0,
       0,     0,    29,     0,     0,     0,    30,    31,     0,   719,
       2,    11,    12,    13,    32,     0,     0,     0,     0,     0,
       0,     0,   245,     0,     0,     0,     0,     0,   246,   247,
     248,     0,     0,     0,     0,   249,   250,     0,   769,     0,
       0,     0,     0,     0,     0,     0,   251,     0,     0,     0,
       0,     0,   252,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    14,     0,    11,    12,    13,     0,
       0,     0,    15,     0,     0,     0,     0,   637,     0,     0,
       0,     0,     0,   638,   639,   640,     0,     0,     0,     0,
     249,   641,     0,     0,     0,     0,   253,     0,     0,     0,
       0,   642,    16,     0,    17,   254,     0,   643,     0,     0,
       0,    19,    20,    21,     0,     0,     0,     0,     0,    14,
       0,     0,     0,     0,    22,     0,    23,    15,     0,     0,
       0,     0,    24,    25,    26,    27,    28,     0,     0,   255,
       0,     0,    29,     0,     0,     0,    30,    31,     0,     0,
       2,   644,     0,     0,    32,     0,     0,    16,     0,    17,
     254,     0,     0,     0,     0,     0,    19,    20,    21,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    22,
       0,    23,     0,     0,     0,     0,     0,    24,    25,    26,
      27,    28,     0,     0,     0,     0,     0,    29,     0,   863,
       0,    30,    31,     0,   881,     2,    11,    12,    13,    32,
       0,     0,     0,     0,     0,     0,     0,   245,     0,     0,
       0,     0,     0,   246,   247,   248,     0,     0,     0,     0,
     249,   250,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   251,     0,     0,     0,     0,     0,   252,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    14,
       0,    11,    12,    13,     0,     0,     0,    15,     0,     0,
       0,     0,   637,     0,     0,     0,     0,     0,   638,   639,
     640,     0,     0,     0,     0,   249,   641,     0,   783,     0,
       0,   253,     0,     0,     0,     0,   642,    16,     0,    17,
     254,     0,   643,     0,     0,     0,    19,    20,    21,     0,
       0,     0,     0,     0,    14,     0,     0,     0,     0,    22,
       0,    23,    15,     0,     0,     0,     0,    24,    25,    26,
      27,    28,     0,     0,   255,     0,     0,    29,     0,     0,
       0,    30,    31,     0,     0,     2,   644,     0,     0,    32,
       0,     0,    16,     0,    17,   254,     0,     0,     0,     0,
       0,    19,    20,    21,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    22,     0,    23,     0,     0,     0,
       0,     0,    24,    25,    26,    27,    28,     0,    11,    12,
      13,     0,    29,     0,     0,     0,    30,    31,     0,   637,
       2,     0,     0,     0,    32,   638,   639,   640,     0,     0,
       0,     0,   249,   641,     0,   854,     0,     0,     0,     0,
       0,     0,     0,   642,     0,     0,     0,     0,     0,   643,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    14,     0,    11,    12,    13,     0,     0,     0,    15,
       0,     0,     0,     0,   637,     0,     0,     0,     0,     0,
     638,   639,   640,     0,     0,     0,     0,   249,   641,     0,
       0,     0,     0,   644,     0,     0,     0,     0,   642,    16,
       0,    17,   254,     0,   643,     0,     0,     0,    19,    20,
      21,     0,     0,     0,     0,     0,    14,     0,     0,     0,
       0,    22,     0,    23,    15,     0,     0,     0,     0,    24,
      25,    26,    27,    28,     0,     0,     0,     0,     0,    29,
       0,     0,     0,    30,    31,     0,     0,     2,   644,     0,
       0,    32,     0,     0,    16,     0,    17,   254,     0,     0,
       0,     0,     0,    19,    20,    21,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    22,     0,    23,     0,
       0,     0,     0,     0,    24,    25,    26,    27,    28,     0,
      11,    12,    13,     0,    29,     0,   863,     0,    30,    31,
       0,   637,     2,     0,     0,     0,    32,   638,   639,   640,
       0,     0,     0,     0,   249,   641,     0,   880,     0,     0,
       0,     0,     0,     0,     0,   642,     0,     0,     0,     0,
       0,   643,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    14,     0,     0,     0,     0,     0,     0,
       0,    15,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    11,
      12,    13,     0,     0,     0,   644,     0,     0,     0,     0,
       0,    16,     0,    17,   254,     0,     0,     0,     0,     0,
      19,    20,    21,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    22,     0,    23,     0,     0,   416,   417,
       0,    24,    25,    26,    27,    28,     0,     0,     0,     0,
       0,    29,    14,     0,     0,    30,    31,     0,     0,     2,
      15,   418,   419,    32,     0,     0,     0,     0,     0,     0,
       0,   420,   421,   422,   423,     0,     0,     0,    11,    12,
      13,     0,   424,   425,     0,     0,     0,     0,     0,   637,
      16,     0,    17,    18,     0,   638,   639,   640,     0,    19,
      20,    21,   249,   641,     0,     0,     0,     0,     0,     0,
       0,     0,    22,   642,    23,     0,     0,     0,     0,   643,
      24,    25,    26,    27,    28,     0,     0,     0,     0,     0,
      29,    14,     0,     0,    30,    31,     0,     0,     0,    15,
       0,     0,    32,     0,     0,    11,    12,    13,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   644,     0,     0,     0,     0,     0,    16,
       0,    17,   254,     0,     0,     0,     0,     0,    19,    20,
      21,     0,     0,     0,     0,     0,     0,     0,     0,   137,
     138,    22,     0,    23,     0,     0,     0,     0,    14,    24,
      25,    26,    27,    28,   147,     0,    15,     0,     0,    29,
      11,    12,    13,    30,    31,     0,     0,     2,     0,     0,
       0,    32,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    19,    20,    21,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    22,     0,
      23,     0,     0,    14,     0,     0,    24,    25,    26,    27,
      28,    15,     0,     0,     0,     0,    29,     0,   334,   335,
      30,    31,   190,     0,     2,     0,     0,     0,    32,     0,
       0,   336,     0,     0,     0,     0,     0,     0,    11,    12,
      13,    16,     0,    17,    18,     0,     0,     0,     0,     0,
      19,    20,    21,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    22,     0,    23,     0,     0,     0,     0,
       0,    24,    25,    26,    27,    28,     0,   272,     0,    86,
       0,    29,   137,   138,     0,    30,   273,     0,     0,     0,
       0,    14,     0,    32,     0,     0,     0,   147,     0,    15,
       0,     0,     0,    11,    12,    13,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    16,
       0,    17,    18,     0,     0,     0,     0,     0,    19,    20,
      21,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     631,    22,     0,    23,     0,     0,    14,     0,     0,    24,
      25,    26,    27,    28,    15,     0,     0,   632,     0,    29,
       0,     0,   633,    30,    31,   604,     0,     2,     0,     0,
       0,    32,    11,    12,    13,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    16,     0,    17,    18,     0,     0,
       0,     0,     0,    19,    20,    21,     0,     0,    11,    12,
      13,     0,     0,     0,     0,     0,    22,     0,    23,     0,
       0,     0,     0,     0,    24,    25,    26,    27,    28,     0,
     696,     0,    86,     0,    29,    14,   772,     0,    30,    31,
       0,     0,     0,    15,     0,     0,    32,     0,     0,     0,
       0,   330,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    14,   331,    11,    12,    13,     0,     0,     0,    15,
       0,     0,     0,    16,     0,    17,    18,     0,     0,     0,
       0,     0,    19,    20,    21,   696,     0,     0,     0,     0,
       0,   775,     0,     0,     0,    22,     0,    23,     0,    16,
       0,    17,    18,    24,    25,    26,    27,    28,    19,    20,
      21,    86,     0,    29,     0,     0,    14,    30,    31,     0,
       0,    22,     0,    23,    15,    32,     0,     0,     0,    24,
      25,    26,    27,    28,     0,     0,     0,     0,     0,    29,
      11,    12,    13,    30,    31,     0,     0,     0,     0,     0,
       0,    32,     0,     0,    16,     0,    17,    18,     0,     0,
       0,     0,   696,    19,    20,    21,     0,     0,   776,     0,
       0,     0,     0,     0,     0,     0,    22,     0,    23,     0,
       0,     0,     0,     0,    24,    25,    26,    27,    28,     0,
       0,     0,     0,    14,    29,    11,    12,    13,    30,    31,
       0,    15,     0,     0,     0,     0,    32,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   751,     0,     0,
       0,     0,     0,   807,     0,     0,     0,     0,     0,     0,
       0,    16,     0,    17,    18,     0,     0,     0,     0,     0,
      19,    20,    21,     0,     0,     0,     0,     0,    14,     0,
      11,    12,    13,    22,     0,    23,    15,     0,     0,     0,
       0,    24,    25,    26,    27,    28,     0,     0,     0,     0,
       0,    29,   855,     0,     0,    30,    31,     0,   883,     0,
       0,     0,     0,    32,     0,     0,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    19,    20,    21,     0,     0,
       0,     0,     0,    14,     0,    11,    12,    13,    22,     0,
      23,    15,     0,     0,     0,     0,    24,    25,    26,    27,
      28,     0,     0,     0,     0,     0,    29,   855,     0,     0,
      30,    31,     0,   886,     0,     0,     0,     0,    32,     0,
       0,    16,     0,    17,    18,     0,     0,     0,     0,     0,
      19,    20,    21,     0,     0,     0,     0,     0,    14,     0,
      11,    12,    13,    22,     0,    23,    15,     0,     0,     0,
       0,    24,    25,    26,    27,    28,     0,     0,     0,     0,
       0,    29,   855,     0,     0,    30,    31,     0,   887,     0,
       0,     0,     0,    32,     0,     0,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    19,    20,    21,     0,     0,
       0,     0,     0,    14,     0,    11,    12,    13,    22,     0,
      23,    15,     0,     0,     0,     0,    24,    25,    26,    27,
      28,     0,     0,     0,     0,     0,    29,     0,     0,     0,
      30,    31,     0,     0,     0,     0,     0,     0,    32,     0,
       0,    16,     0,    17,    18,     0,     0,     0,     0,     0,
      19,    20,    21,     0,     0,     0,     0,     0,    14,     0,
      11,    12,    13,    22,     0,    23,    15,     0,     0,     0,
       0,    24,    25,    26,    27,    28,     0,     0,     0,     0,
       0,    29,     0,     0,     0,    30,    31,     0,     0,     0,
       0,     0,     0,    32,     0,     0,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    19,    20,    21,     0,     0,
       0,     0,     0,    14,     0,    11,    12,    13,    22,     0,
      23,    15,     0,     0,     0,     0,    24,    25,    26,    27,
      28,     0,   272,     0,     0,     0,    29,     0,     0,     0,
      30,   273,     0,     0,     0,     0,     0,     0,    32,     0,
       0,    16,     0,    17,    18,     0,     0,     0,     0,     0,
      19,    20,    21,     0,     0,     0,     0,     0,    14,     0,
      11,    12,    13,    22,     0,    23,    15,     0,     0,     0,
       0,    24,    25,    26,    27,    28,     0,   309,     0,     0,
       0,    29,     0,     0,     0,    30,    31,     0,     0,     0,
       0,     0,     0,    32,     0,     0,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    19,    20,    21,     0,     0,
       0,     0,     0,    14,     0,    11,    12,    13,    22,     0,
      23,    15,     0,     0,     0,     0,    24,    25,    26,    27,
      28,     0,     0,     0,    86,     0,    29,     0,     0,     0,
      30,    31,     0,     0,     0,     0,     0,     0,    32,     0,
       0,    16,     0,    17,    18,     0,     0,     0,     0,     0,
      19,    20,    21,     0,     0,     0,     0,     0,    14,     0,
      11,    12,    13,    22,     0,    23,    15,     0,     0,     0,
       0,    24,    25,    26,    27,    28,     0,     0,     0,     0,
       0,    29,     0,     0,     0,    30,    31,   362,     0,     0,
       0,     0,     0,    32,     0,     0,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    19,    20,    21,     0,     0,
       0,     0,     0,    14,     0,     0,     0,     0,    22,     0,
      23,    15,     0,     0,     0,     0,    24,    25,    26,    27,
      28,     0,   272,    11,    12,    13,    29,     0,     0,     0,
      30,    31,     0,     0,     0,     0,     0,     0,    32,     0,
       0,    16,     0,    17,    18,     0,     0,     0,     0,     0,
      19,    20,    21,     0,     0,     0,     0,     0,     0,     0,
       0,   563,     0,    22,     0,    23,     0,     0,     0,     0,
       0,    24,    25,    26,    27,    28,    14,     0,   255,     0,
       0,    29,     0,     0,    15,    30,    31,     0,    11,    12,
      13,     0,     0,    32,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     696,     0,     0,     0,    16,     0,    17,    18,     0,     0,
       0,     0,     0,    19,    20,    21,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    22,     0,    23,     0,
       0,    14,     0,     0,    24,    25,    26,    27,    28,    15,
       0,     0,     0,     0,    29,    11,    12,    13,    30,    31,
       0,     0,     0,     0,     0,     0,    32,     0,     0,     0,
       0,     0,    11,    12,    13,     0,     0,   751,     0,    16,
       0,    17,    18,     0,     0,     0,     0,     0,    19,    20,
      21,     0,     0,     0,   855,     0,     0,     0,     0,     0,
       0,    22,     0,    23,     0,     0,     0,     0,    14,    24,
      25,    26,    27,    28,     0,     0,    15,     0,     0,    29,
       0,     0,     0,    30,    31,    14,     0,     0,    11,    12,
      13,    32,     0,    15,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    16,     0,    17,    18,
       0,     0,     0,     0,     0,    19,    20,    21,     0,     0,
       0,     0,     0,    16,     0,    17,    18,     0,    22,     0,
      23,     0,    19,    20,    21,     0,    24,    25,    26,    27,
      28,    14,     0,     0,     0,    22,    29,    23,     0,    15,
      30,    31,     0,    24,    25,    26,    27,    28,    32,     0,
       0,     0,     0,    29,    11,    12,    13,    30,    31,     0,
       0,     0,     0,     0,     0,    32,     0,     0,     0,    16,
       0,    17,    18,     0,     0,     0,     0,     0,    19,    20,
      21,    12,    13,     0,     0,     0,     0,     0,     0,     0,
       0,    22,     0,    23,     0,     0,     0,     0,     0,    24,
      25,    26,    27,    28,     0,     0,     0,    14,     0,    29,
       0,     0,     0,    30,    31,    15,     0,     0,     0,     0,
       0,    32,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    14,     0,     0,     0,     0,     0,     0,
       0,    15,     0,     0,     0,    16,     0,    17,    18,     0,
       0,     0,     0,     0,    19,    20,    21,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    22,     0,    23,
       0,    16,     0,    17,    18,    24,    25,    26,    27,    28,
      19,    20,    21,     0,     0,    29,     0,     0,     0,    30,
     414,     0,     0,    22,     0,    23,     0,    32,     0,     0,
       0,    24,    25,    26,    27,    28,     0,     0,     0,     0,
       0,    29,     0,     0,     0,    30,    31,   121,   122,   123,
     124,   125,   126,    32,     0,   127,   128,   129,   130,   131,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   133,
     134,   135,     0,     0,     0,     0,   136,   137,   138,     0,
     139,     0,     0,   140,     0,   141,     0,   142,   143,   144,
     145,   146,   147,   148,     0,     0,     0,   149,   150,   151,
     152,     0,     0,     0,   153,     0,     0,   154,   155,   156,
       0,   157,     0,     0,     0,   158,     0,     0,     0,   159,
     160,   161,   162,   163,   164,   165,   121,   122,   123,   124,
     125,   126,     0,   283,   127,   128,   129,   130,   131,   284,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   440,
       0,     0,     0,     0,     0,     0,     0,   286,   133,     0,
     135,     0,     0,   287,     0,   136,     0,     0,     0,   139,
       0,     0,     2,     0,   141,     0,   142,   143,   144,   145,
     146,     0,     0,     0,     0,     0,   149,   150,   151,   152,
       0,     0,     0,     0,     0,     0,   154,   155,   156,     0,
     157,     0,     0,     0,   158,     0,     0,     0,   159,   160,
     161,   162,   163,   164,   165,   121,   122,   123,   124,   125,
     126,     0,   283,   127,   128,   129,   130,   131,   284,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   286,   133,     0,   135,
       0,     0,   287,     0,   136,     0,     0,     0,   139,     0,
     441,     0,     0,   141,     0,   142,   143,   144,   145,   146,
       0,     0,     0,     0,     0,   149,   150,   151,   152,     0,
       0,     0,     0,     0,     0,   154,   155,   156,     0,   157,
       0,     0,     0,   158,     0,     0,     0,   159,   160,   161,
     162,   163,   164,   165,   121,   122,   123,   124,   125,   126,
       0,   283,   127,   128,   129,   130,   131,   284,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   905,     0,     0,
       0,     0,     0,     0,     0,   286,   133,     0,   135,     0,
       0,   287,     0,   136,   757,     0,     0,   139,     0,   805,
       0,     0,   141,     0,   142,   143,   144,   145,   146,     0,
       0,     0,     0,     0,   149,   150,   151,   152,     0,     0,
       0,     0,     0,     0,   154,   155,   156,     0,   157,     0,
       0,     0,   158,     0,     0,     0,   159,   160,   161,   162,
     163,   164,   165,   121,   122,   123,   124,   125,   126,     0,
     283,   127,   128,   129,   130,   131,   284,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   916,     0,     0,     0,
       0,     0,     0,     0,   286,   133,     0,   135,     0,     0,
     287,     0,   136,     0,     0,     0,   139,     0,   906,     0,
       0,   141,     0,   142,   143,   144,   145,   146,     0,     0,
       0,     0,     0,   149,   150,   151,   152,     0,     0,     0,
       0,     0,     0,   154,   155,   156,     0,   157,     0,     0,
       0,   158,     0,     0,     0,   159,   160,   161,   162,   163,
     164,   165,   121,   122,   123,   124,   125,   126,     0,   283,
     127,   128,   129,   130,   131,   284,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   286,   133,     0,   135,     0,     0,   287,
       0,   136,     0,     0,     0,   139,     0,   917,     0,     0,
     141,     0,   142,   143,   144,   145,   146,     0,     0,     0,
       0,     0,   149,   150,   151,   152,     0,     0,     0,     0,
       0,     0,   154,   155,   156,     0,   157,     0,     0,     0,
     158,     0,     0,     0,   159,   160,   161,   162,   163,   164,
     165,   121,   122,   123,   124,   125,   126,     0,   283,   127,
     128,   129,   130,   131,   284,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   285,     0,
       0,     0,   286,   133,     0,   135,     0,     0,   287,     0,
     136,   757,     0,     0,   139,     0,     0,     0,     0,   141,
       0,   142,   143,   144,   145,   146,     0,     0,     0,     0,
       0,   149,   150,   151,   152,     0,     0,     0,     0,     0,
       0,   154,   155,   156,     0,   157,     0,     0,     0,   158,
       0,     0,     0,   159,   160,   161,   162,   163,   164,   165,
     121,   122,   123,   124,   125,   126,     0,   283,   127,   128,
     129,   130,   131,   284,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   446,     0,     0,
       0,   286,   133,     0,   135,     0,     0,   287,     0,   136,
       0,     0,     0,   139,     0,     0,     0,     0,   141,     0,
     142,   143,   144,   145,   146,     0,     0,     0,     0,     0,
     149,   150,   151,   152,     0,     0,     0,     0,     0,     0,
     154,   155,   156,     0,   157,     0,     0,     0,   158,     0,
       0,     0,   159,   160,   161,   162,   163,   164,   165,   121,
     122,   123,   124,   125,   126,     0,   283,   127,   128,   129,
     130,   131,   284,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   561,     0,     0,     0,     0,     0,     0,     0,
     286,   133,     0,   135,     0,     0,   287,     0,   136,     0,
       0,     0,   139,     0,     0,     0,     0,   141,     0,   142,
     143,   144,   145,   146,     0,     0,     0,     0,     0,   149,
     150,   151,   152,     0,     0,     0,     0,     0,     0,   154,
     155,   156,     0,   157,     0,     0,     0,   158,     0,     0,
       0,   159,   160,   161,   162,   163,   164,   165,   121,   122,
     123,   124,   125,   126,     0,   283,   127,   128,   129,   130,
     131,   284,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   668,     0,     0,     0,     0,     0,     0,     0,   286,
     133,     0,   135,     0,     0,   287,     0,   136,     0,     0,
       0,   139,     0,     0,     0,     0,   141,     0,   142,   143,
     144,   145,   146,     0,     0,     0,     0,     0,   149,   150,
     151,   152,     0,     0,     0,     0,     0,     0,   154,   155,
     156,     0,   157,     0,     0,     0,   158,     0,     0,     0,
     159,   160,   161,   162,   163,   164,   165,   121,   122,   123,
     124,   125,   126,     0,   283,   127,   128,   129,   130,   131,
     284,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     750,     0,     0,     0,     0,     0,     0,     0,   286,   133,
       0,   135,     0,     0,   287,     0,   136,     0,     0,     0,
     139,     0,     0,     0,     0,   141,     0,   142,   143,   144,
     145,   146,     0,     0,     0,     0,     0,   149,   150,   151,
     152,     0,     0,     0,     0,     0,     0,   154,   155,   156,
       0,   157,     0,     0,     0,   158,     0,     0,     0,   159,
     160,   161,   162,   163,   164,   165,   121,   122,   123,   124,
     125,   126,     0,   283,   127,   128,   129,   130,   131,   284,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   911,
       0,     0,     0,     0,     0,     0,     0,   286,   133,     0,
     135,     0,     0,   287,     0,   136,     0,     0,     0,   139,
       0,     0,     0,     0,   141,     0,   142,   143,   144,   145,
     146,     0,     0,     0,     0,     0,   149,   150,   151,   152,
       0,     0,     0,     0,     0,     0,   154,   155,   156,     0,
     157,     0,     0,     0,   158,     0,     0,     0,   159,   160,
     161,   162,   163,   164,   165,   121,   122,   123,   124,   125,
     126,     0,   283,   127,   128,   129,   130,   131,   284,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   914,     0,
       0,     0,     0,     0,     0,     0,   286,   133,     0,   135,
       0,     0,   287,     0,   136,     0,     0,     0,   139,     0,
       0,     0,     0,   141,     0,   142,   143,   144,   145,   146,
       0,     0,     0,     0,     0,   149,   150,   151,   152,     0,
       0,     0,     0,     0,     0,   154,   155,   156,     0,   157,
       0,     0,     0,   158,     0,     0,     0,   159,   160,   161,
     162,   163,   164,   165,   121,   122,   123,   124,   125,   126,
       0,   283,   127,   128,   129,   130,   131,   284,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   919,     0,     0,
       0,     0,     0,     0,     0,   286,   133,     0,   135,     0,
       0,   287,     0,   136,     0,     0,     0,   139,     0,     0,
       0,     0,   141,     0,   142,   143,   144,   145,   146,     0,
       0,     0,     0,     0,   149,   150,   151,   152,     0,     0,
       0,     0,     0,     0,   154,   155,   156,     0,   157,     0,
       0,     0,   158,     0,     0,     0,   159,   160,   161,   162,
     163,   164,   165,   121,   122,   123,   124,   125,   126,     0,
     283,   127,   128,   129,   130,   131,   284,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   921,     0,     0,     0,
       0,     0,     0,     0,   286,   133,     0,   135,     0,     0,
     287,     0,   136,     0,     0,     0,   139,     0,     0,     0,
       0,   141,     0,   142,   143,   144,   145,   146,     0,     0,
       0,     0,     0,   149,   150,   151,   152,     0,     0,     0,
       0,     0,     0,   154,   155,   156,     0,   157,     0,     0,
       0,   158,     0,     0,     0,   159,   160,   161,   162,   163,
     164,   165,   121,   122,   123,   124,   125,   126,     0,   283,
     127,   128,   129,   130,   131,   284,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   922,     0,     0,     0,     0,
       0,     0,     0,   286,   133,     0,   135,     0,     0,   287,
       0,   136,     0,     0,     0,   139,     0,     0,     0,     0,
     141,     0,   142,   143,   144,   145,   146,     0,     0,     0,
       0,     0,   149,   150,   151,   152,     0,     0,     0,     0,
       0,     0,   154,   155,   156,     0,   157,     0,     0,     0,
     158,     0,     0,     0,   159,   160,   161,   162,   163,   164,
     165,   121,   122,   123,   124,   125,   126,     0,   283,   127,
     128,   129,   130,   131,   284,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   924,     0,     0,     0,     0,     0,
       0,     0,   286,   133,     0,   135,     0,     0,   287,     0,
     136,     0,     0,     0,   139,     0,     0,     0,     0,   141,
       0,   142,   143,   144,   145,   146,     0,     0,     0,     0,
       0,   149,   150,   151,   152,     0,     0,     0,     0,     0,
       0,   154,   155,   156,     0,   157,     0,     0,     0,   158,
       0,     0,     0,   159,   160,   161,   162,   163,   164,   165
};

static const yytype_int16 yycheck[] =
{
       0,    62,    61,   283,   126,     5,   119,     8,    36,   166,
     168,    61,   547,   195,   121,   122,   123,   124,   289,    65,
       6,   654,   268,   268,   268,   571,   654,   268,   268,   136,
      61,    62,   654,     4,     4,   268,   268,   782,   555,   617,
       4,   558,     3,    17,   556,    17,     4,   559,   514,   436,
     751,   471,   743,   654,     4,    98,    76,   477,   240,   111,
       4,    61,    62,   185,     4,   457,     4,    87,   140,   141,
     457,   458,    76,    65,    54,   766,    54,    54,   498,   824,
      54,   133,     5,    87,   697,    98,   181,   700,   701,   722,
     185,   782,    76,   136,   722,   141,    76,    58,    76,    76,
     722,   147,    76,    87,   805,   133,     0,   166,   809,   800,
     136,   812,    98,   804,   149,    58,   166,   143,   696,    51,
      52,   722,   514,   814,    98,   153,    98,   662,   674,   143,
     189,   666,    65,   143,    66,   166,   195,   123,   245,   189,
     168,    58,   608,   250,   172,   195,   143,   664,   839,   141,
      65,   179,   274,   665,   400,   400,   400,   143,   189,   400,
     400,   581,   136,   194,   195,   798,   166,   400,   400,   556,
     798,   442,   559,   144,   144,   595,   798,   569,   598,   571,
     144,   240,   569,   570,   571,   146,   144,   148,   189,   347,
     240,   373,   770,   194,   144,   195,   774,   798,    65,   356,
     144,   779,    98,   146,   144,   148,   144,   140,   141,   240,
      65,   746,    65,   335,   146,   372,   608,   339,   141,   855,
      65,   144,   344,   112,   113,    65,   141,   140,   141,   146,
     145,   148,    65,    57,   120,    76,   122,   126,   127,    65,
     240,   104,   105,    67,    65,   881,    87,   401,   402,   885,
      65,   114,   115,   281,   890,   121,   140,    65,    65,   143,
     260,   374,   375,   107,   108,   109,   110,   268,   688,    65,
      65,   130,   379,   660,   141,   613,   614,   144,   665,    65,
     560,    65,   674,    65,   137,   132,   141,   674,   141,   144,
     145,   352,   145,   680,   139,   323,   141,   356,    98,   152,
     153,   141,   330,   331,   144,   145,   356,   335,   141,    65,
      65,   339,   145,   372,   373,   141,    65,    65,   144,   347,
     141,   352,   372,   373,   145,   356,   141,    65,   131,   144,
     576,   576,   576,   141,   141,   576,   576,   145,   145,    65,
      65,   372,   373,   576,   576,   141,   141,   149,   144,   144,
     457,   743,   352,   510,    65,   141,   356,   141,   144,   141,
     144,    65,   144,    65,   486,   611,   611,   611,   490,    65,
     611,   611,   372,   373,   766,   134,   106,    65,   611,   611,
     140,   140,   143,   143,   143,   141,   141,    65,   144,   144,
     782,    65,   141,   141,   140,   144,   144,    65,   669,   400,
     143,    65,   673,   141,   796,    65,   144,   514,   800,    65,
      65,    65,   804,   827,   828,   141,   141,    65,   144,   144,
     144,    65,   814,   815,   856,   134,   140,   859,   860,    65,
     141,   140,   824,   144,   143,   435,   436,   141,   139,   141,
     144,   137,   144,   140,   836,   141,    65,   839,   840,    65,
     140,   510,   513,   141,    65,   847,   144,   457,   458,    65,
     510,    65,   569,   141,   571,    98,   144,   141,    65,   497,
     144,   143,    65,   141,   138,   139,   144,   141,   870,   510,
     751,   141,   513,   140,   144,   141,   141,   141,   144,   144,
     144,   140,   551,   141,   143,   140,   144,   141,    65,   140,
     144,   608,   143,   610,   140,   141,   140,    65,   143,   143,
     510,   618,   143,   513,   514,   543,    65,   576,   143,   112,
     551,   140,   141,   554,   140,   141,    65,    54,   121,   140,
     141,   137,    97,    98,   805,   141,   140,   141,   809,    65,
     134,   812,   136,   140,   141,   576,    19,   547,   141,    22,
     551,   143,   611,   554,   112,   555,   556,   140,   558,   559,
     143,   140,    65,   121,   143,   143,   535,   674,   537,   569,
     570,   571,   143,   140,   141,   576,    70,    98,    51,    52,
      65,    54,   140,   141,    57,   140,    80,   694,    82,   143,
     143,   140,   141,    66,    67,   654,    65,    91,    71,    72,
      98,   140,   141,    65,    87,   143,   634,    65,   608,    65,
     611,   547,    65,    87,   140,   141,   896,   617,    65,   123,
     124,   125,    95,   654,    65,   536,    99,   538,   656,   143,
     910,    98,    87,   913,   137,    87,   907,   637,   141,    65,
     920,   641,    65,   140,   915,   140,    92,   918,    65,    94,
      95,    96,   923,   654,   140,   140,   141,    65,    54,   766,
     660,   141,   662,   141,   664,   665,   666,   116,   117,   118,
     119,   140,   141,   146,   674,     2,    65,   141,   140,   141,
     680,   141,   140,   141,   140,   141,    65,   140,   141,    65,
     134,    98,    65,   140,   141,    98,   696,    65,   140,   140,
     141,   637,    29,   154,    31,   641,   143,   814,   815,    41,
      65,   739,    65,    98,   140,   141,    65,   140,   141,   140,
     720,   722,   144,   140,   141,   144,   662,    65,   144,   144,
     666,   144,   140,   141,   144,    62,    76,    64,    65,   798,
     847,    68,   143,   743,   851,   143,   746,    65,   143,   143,
     143,   140,   141,    65,    37,   143,    83,    84,   140,    86,
      87,   140,   141,   121,   140,   141,   766,   140,   141,    41,
     770,    41,   140,   141,   774,    99,   100,   101,   102,   779,
     140,    33,   782,   144,   720,   140,   141,   140,   141,   116,
      98,   140,   141,    92,    37,   435,   796,   798,   140,   126,
     800,    37,   140,   141,   804,   140,    69,   743,   135,    33,
     746,    41,   139,   143,   814,   815,    79,   457,    81,   140,
     268,   140,   140,   141,   824,   825,   153,    90,   140,   141,
      37,   831,   832,    37,   140,    46,   836,   164,    41,   839,
     840,   168,    37,    37,    37,   172,   782,   847,   103,   104,
     105,   106,   179,   853,   181,   855,    41,    41,   185,    70,
     796,    33,    37,    37,   800,    75,    76,    37,   804,    80,
     870,    82,   199,    18,   514,   202,    41,   204,    88,   140,
      91,   881,    37,    98,    18,   885,    98,    47,   824,   825,
     890,   107,   108,   109,   110,     5,   832,   117,   513,   189,
     836,   340,   306,   839,   840,   452,   569,   547,   908,    69,
     189,   551,   347,   752,   656,   555,     5,   853,   558,    79,
     570,    81,   673,    79,   134,   111,   136,   114,    89,   569,
      90,   571,   112,   115,   870,   113,   576,   370,    -1,    -1,
      -1,   268,    -1,    -1,    -1,   272,   273,   274,   275,    -1,
      -1,    -1,   400,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   608,    -1,
      -1,   611,   908,    -1,    -1,    -1,    -1,    -1,    -1,   306,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   323,    -1,    -1,   326,
      -1,   328,    -1,   330,   331,    -1,   333,    -1,    -1,    -1,
     337,   338,    -1,    -1,   654,    -1,    -1,   344,   345,    -1,
     347,    -1,   662,    -1,   664,    -1,   666,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   674,    -1,    -1,    -1,    -1,   366,
     367,   368,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   381,   382,   383,    -1,    -1,   386,
     387,   388,    -1,   390,    -1,    -1,    -1,   394,    -1,    -1,
     268,    -1,    -1,   400,   401,   402,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   414,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   547,
      -1,   428,    -1,   743,    -1,    -1,   746,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   443,   444,   445,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   766,    -1,   576,    -1,
      -1,    -1,   459,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   782,    -1,    -1,   472,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   480,    -1,   482,   796,    -1,   798,    -1,
     800,    -1,    -1,   611,   804,    -1,   493,    -1,    -1,    -1,
     497,    -1,   499,    -1,   814,   815,   503,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   824,    -1,   513,    -1,    -1,   637,
      -1,    -1,    -1,   641,    -1,    -1,   836,    -1,    -1,   839,
     840,   528,   400,   530,    -1,    -1,   654,   847,    -1,    -1,
      -1,    -1,    -1,    -1,   662,    -1,   543,    -1,   666,    -1,
     547,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     870,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   576,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   596,
      -1,    -1,   720,    -1,   722,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   611,   612,   613,   614,   615,   616,
      -1,    -1,    -1,    -1,    -1,   743,   623,    -1,   746,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   634,    -1,   636,
     637,    -1,    -1,    -1,   641,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   654,    -1,   656,
      -1,    -1,    -1,    -1,   782,   662,    -1,    -1,   435,   666,
      -1,    -1,    -1,   670,    -1,   672,    -1,    -1,   796,   547,
     798,    -1,   800,    -1,    -1,   682,   804,    -1,    -1,    -1,
     457,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     697,    -1,    -1,   700,   701,    -1,   824,   825,   576,    -1,
      -1,    -1,    -1,   831,   832,    -1,    -1,    -1,   836,   716,
      -1,   839,   840,   720,    -1,   722,   723,   724,   725,    -1,
     727,   728,   729,    -1,    -1,   853,    -1,   855,    -1,    -1,
      -1,    -1,   739,   611,   741,    -1,   743,   514,    -1,   746,
      -1,    -1,   870,    -1,    -1,   752,    -1,    -1,   755,    -1,
      -1,    -1,    -1,   881,    -1,    -1,    -1,   885,    -1,   637,
      -1,    -1,   890,   641,    -1,    -1,    -1,    -1,    -1,    -1,
     547,   778,    -1,    -1,   551,   782,   654,    -1,   555,    -1,
     908,   558,    -1,    -1,   662,    -1,    -1,   794,   666,   796,
      -1,   798,   569,   800,   571,    -1,    -1,   804,    -1,   576,
      -1,    -1,    -1,    -1,   811,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     7,     8,     9,   824,   825,   826,
     827,   828,   829,   830,   831,   832,    -1,    -1,    -1,   836,
      -1,   608,   839,   840,   611,    -1,    -1,   844,    -1,    -1,
      -1,    -1,   720,    -1,   722,    -1,   853,    -1,   855,   856,
      -1,    -1,   859,   860,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   870,    -1,   743,    -1,    60,   746,    -1,
      -1,    -1,    -1,    -1,   881,    68,    -1,   654,   885,    -1,
      -1,    -1,   889,   890,    -1,   662,    -1,   664,   895,   666,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   674,    -1,    -1,
      -1,   908,    -1,    -1,   782,    98,    -1,   100,   101,    -1,
      -1,    -1,    -1,    -1,   107,   108,   109,    -1,   796,    -1,
     798,    -1,   800,    -1,    -1,    -1,   804,   120,    -1,   122,
      -1,    -1,    -1,    -1,    -1,   128,   129,   130,   131,   132,
      -1,    -1,    -1,    -1,    -1,   138,   824,   825,    -1,   142,
     143,   144,    -1,   831,   832,    -1,    -1,   150,   836,    -1,
      -1,   839,   840,    -1,    -1,    -1,   743,    -1,    -1,   746,
      -1,    -1,    -1,    -1,    -1,   853,    -1,   855,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   766,
      -1,    -1,   870,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   881,    -1,   782,    -1,   885,    -1,    -1,
      -1,    -1,   890,    -1,    -1,    -1,    -1,    -1,    -1,   796,
      -1,   798,    -1,   800,    -1,    -1,    -1,   804,    -1,    -1,
     908,    -1,    -1,    -1,    -1,    -1,    -1,   814,   815,    -1,
      -1,    -1,    -1,    14,    15,    -1,    -1,   824,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    -1,   836,
      -1,    -1,   839,   840,    -1,    -1,    -1,    -1,    -1,    -1,
     847,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   870,     7,     8,     9,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,    90,
      91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,   112,   113,   114,   115,    -1,    -1,    60,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    68,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    68,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    98,    -1,   100,   101,    -1,
      -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,    -1,
      -1,    -1,    98,    -1,   100,   101,    -1,   120,    -1,   122,
      -1,   107,   108,   109,    -1,   128,   129,   130,   131,   132,
      -1,    -1,    -1,   136,   120,   138,   122,    -1,    -1,   142,
     143,    -1,   128,   129,   130,   131,   132,   150,    -1,    -1,
      -1,   154,   138,    -1,    -1,    -1,   142,   143,    -1,     1,
      -1,    -1,    -1,    -1,   150,    -1,    -1,    -1,   154,    11,
      12,    13,    14,    15,    16,    -1,    -1,    19,    20,    21,
      22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    -1,    -1,
      -1,    43,    44,    45,    -1,    -1,    -1,    -1,    50,    51,
      52,    -1,    54,    -1,    -1,    57,    -1,    59,    -1,    61,
      62,    63,    64,    65,    66,    67,    -1,    -1,    -1,    71,
      72,    73,    74,    -1,    -1,    -1,    78,    -1,    -1,    81,
      82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,    -1,
       1,    93,    94,    95,    96,    97,    98,    99,    -1,    -1,
      11,    12,    13,    14,    15,    16,    -1,    -1,    19,    20,
      21,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    -1,
      -1,    -1,    43,    44,    45,    -1,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,   146,    -1,    57,    -1,    59,   370,
      61,    62,    63,    64,    65,    66,    67,    -1,    -1,    -1,
      71,    72,    73,    74,    -1,    -1,    -1,    78,    -1,    -1,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,
       1,    -1,    93,    94,    95,    96,    97,    98,    99,    -1,
      11,    12,    13,    14,    15,    16,    -1,    -1,    19,    20,
      21,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    -1,
      -1,    -1,    43,    44,    45,    -1,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,    -1,   146,    57,    -1,    59,    -1,
      61,    62,    63,    64,    65,    66,    67,    -1,    -1,    -1,
      71,    72,    73,    74,    -1,    -1,    -1,    78,    -1,    -1,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,
       1,    -1,    93,    94,    95,    96,    97,    98,    99,    -1,
      11,    12,    13,    14,    15,    16,    -1,    -1,    19,    20,
      21,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    -1,
      -1,    -1,    43,    44,    45,    -1,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,    -1,   146,    57,    -1,    59,    -1,
      61,    62,    63,    64,    65,    66,    67,    -1,    -1,    -1,
      71,    72,    73,    74,    -1,    -1,    -1,    78,    -1,    -1,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,
       1,    -1,    93,    94,    95,    96,    97,    98,    99,    -1,
      11,    12,    13,    14,    15,    16,    -1,    -1,    19,    20,
      21,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    -1,
      -1,    -1,    43,    44,    45,    -1,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,    -1,   146,    57,    -1,    59,    -1,
      61,    62,    63,    64,    65,    66,    67,    -1,    -1,    -1,
      71,    72,    73,    74,    -1,    -1,    -1,    78,    -1,    -1,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,
       1,    -1,    93,    94,    95,    96,    97,    98,    99,    -1,
      11,    12,    13,    14,    15,    16,    -1,    -1,    19,    20,
      21,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    -1,
      -1,    -1,    43,    44,    45,    -1,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,    -1,   146,    57,    -1,    59,    -1,
      61,    62,    63,    64,    65,    66,    67,    -1,    -1,    -1,
      71,    72,    73,    74,    -1,    -1,    -1,    78,    -1,    -1,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,
       1,    -1,    93,    94,    95,    96,    97,    98,    99,    -1,
      11,    12,    13,    14,    15,    16,    -1,    -1,    19,    20,
      21,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    -1,
      -1,    -1,    43,    44,    45,    -1,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,    -1,   146,    57,    -1,    59,    -1,
      61,    62,    63,    64,    65,    66,    67,    -1,    -1,    -1,
      71,    72,    73,    74,    -1,    -1,    -1,    78,    -1,    -1,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,
       1,    -1,    93,    94,    95,    96,    97,    98,    99,    -1,
      11,    12,    13,    14,    15,    16,    -1,    -1,    19,    20,
      21,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    -1,
      -1,    -1,    43,    44,    45,    -1,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,    -1,   146,    57,    -1,    59,    -1,
      61,    62,    63,    64,    65,    66,    67,    -1,    -1,    -1,
      71,    72,    73,    74,    -1,    -1,    -1,    78,    -1,    -1,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,     7,
       8,     9,    93,    94,    95,    96,    97,    98,    99,    -1,
      18,    19,    -1,    -1,    22,    -1,    24,    25,    26,    -1,
      -1,    -1,    -1,    31,    32,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    -1,    -1,    51,    52,    -1,    54,    -1,    -1,    57,
      -1,    -1,    60,    -1,    -1,   146,    -1,    -1,    66,    67,
      68,    -1,    -1,    71,    72,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    92,    -1,    -1,    95,    -1,    -1,
      98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,
     108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    -1,
     128,   129,   130,   131,   132,    -1,    -1,   135,    -1,    -1,
     138,    -1,    -1,    -1,   142,   143,    -1,    -1,   146,     7,
       8,     9,   150,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    -1,    -1,    22,    -1,    24,    25,    26,    -1,
      -1,    -1,    -1,    31,    32,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    -1,    -1,    51,    52,    -1,    54,    -1,    -1,    57,
      -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,    66,    67,
      68,    -1,    -1,    71,    72,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    92,    -1,    -1,    95,    -1,    -1,
      98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,
     108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    -1,
     128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,    -1,
     138,    -1,    -1,    -1,   142,   143,    -1,    -1,   146,     7,
       8,     9,   150,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    -1,    -1,    22,    -1,    24,    25,    26,    -1,
      -1,    -1,    -1,    31,    32,    -1,    34,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,
      -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,    -1,    67,
      68,    -1,    -1,    71,    72,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    92,    -1,    -1,    95,    -1,    -1,
      98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,
     108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    -1,
     128,   129,   130,   131,   132,    -1,    -1,   135,    -1,    -1,
     138,    -1,    -1,    -1,   142,   143,    -1,    -1,   146,     7,
       8,     9,   150,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    -1,    -1,    22,    -1,    24,    25,    26,    -1,
      -1,    -1,    -1,    31,    32,    -1,    34,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,
      -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,    -1,    67,
      68,    -1,    -1,    71,    72,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    92,    -1,    -1,    95,    -1,    -1,
      98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,
     108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    -1,
     128,   129,   130,   131,   132,    -1,    -1,   135,    -1,    -1,
     138,    -1,    -1,    -1,   142,   143,    -1,    -1,   146,     7,
       8,     9,   150,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    -1,    -1,    22,    -1,    24,    25,    26,    -1,
      -1,    -1,    -1,    31,    32,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,
      -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,    -1,    67,
      68,    -1,    -1,    71,    72,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    92,    -1,    -1,    95,    -1,    -1,
      98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,
     108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    -1,
     128,   129,   130,   131,   132,    -1,    -1,   135,    -1,    -1,
     138,    -1,    -1,    -1,   142,   143,    -1,    -1,   146,     7,
       8,     9,   150,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    -1,    -1,    22,    -1,    24,    25,    26,    -1,
      -1,    -1,    -1,    31,    32,    -1,    34,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,
      -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,    -1,    67,
      68,    -1,    -1,    71,    72,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    92,    -1,    -1,    95,    -1,    -1,
      98,    99,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,
     108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    -1,
     128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,    -1,
     138,    -1,    -1,    -1,   142,   143,    -1,    -1,   146,     7,
       8,     9,   150,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    -1,    -1,    22,    -1,    24,    25,    26,    -1,
      -1,    -1,    -1,    31,    32,    -1,    34,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,
      -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,    -1,    67,
      68,    -1,    -1,    71,    72,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    92,    -1,    -1,    95,    -1,    -1,
      98,    99,   100,   101,     7,     8,     9,    -1,    -1,   107,
     108,   109,    -1,    -1,    -1,    -1,    19,    -1,    -1,    22,
      -1,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    -1,
     128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,    -1,
     138,    -1,    -1,    -1,   142,   143,    -1,    -1,   146,    -1,
      -1,    54,   150,    -1,    -1,    -1,    -1,    60,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    68,    -1,    -1,    71,    72,
      73,    74,    -1,    76,    -1,    -1,    -1,    -1,    81,    82,
      -1,    84,    85,    -1,    87,    -1,    89,    -1,    -1,    -1,
      93,    94,    95,    -1,    -1,    98,    99,   100,   101,    -1,
      -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   120,    -1,   122,
      -1,    -1,    -1,    -1,    -1,   128,   129,   130,   131,   132,
      -1,    -1,    -1,   136,    -1,   138,    -1,    -1,    -1,   142,
     143,     7,     8,     9,    -1,    -1,    -1,   150,    -1,    -1,
      -1,    -1,    18,    19,    -1,    -1,    22,    -1,    24,    25,
      26,    -1,    -1,    -1,    -1,    31,    32,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,
      -1,    -1,    48,    -1,    -1,    -1,    -1,    -1,    54,    -1,
      -1,    57,    -1,    -1,    60,    -1,     7,     8,     9,    -1,
      -1,    67,    68,    -1,    -1,    71,    72,    18,    -1,    -1,
      -1,    -1,    -1,    24,    25,    26,    -1,    -1,    -1,    -1,
      31,    32,    -1,    34,    -1,    -1,    92,    -1,    -1,    95,
      -1,    42,    98,    99,   100,   101,    -1,    48,    -1,    -1,
      -1,   107,   108,   109,    -1,    -1,    -1,    -1,    -1,    60,
      -1,    -1,    -1,    -1,   120,    -1,   122,    68,    -1,    -1,
      -1,    -1,   128,   129,   130,   131,   132,    -1,    -1,    -1,
      -1,    -1,   138,    -1,    -1,    -1,   142,   143,    -1,    -1,
     146,    92,    -1,    -1,   150,    -1,    -1,    98,    -1,   100,
     101,    -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   120,
      -1,   122,    -1,    -1,    -1,    -1,    -1,   128,   129,   130,
     131,   132,    -1,    -1,   135,    -1,    -1,   138,    -1,    -1,
      -1,   142,   143,    -1,   145,   146,     7,     8,     9,   150,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    -1,    -1,
      -1,    -1,    -1,    24,    25,    26,    -1,    -1,    -1,    -1,
      31,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    60,
      -1,     7,     8,     9,    -1,    -1,    -1,    68,    -1,    -1,
      -1,    -1,    18,    -1,    -1,    -1,    -1,    -1,    24,    25,
      26,    -1,    -1,    -1,    -1,    31,    32,    -1,    -1,    -1,
      -1,    92,    -1,    -1,    -1,    -1,    42,    98,    -1,   100,
     101,    -1,    48,    -1,    -1,    -1,   107,   108,   109,    -1,
      -1,    -1,    -1,    -1,    60,    -1,    -1,    -1,    -1,   120,
      -1,   122,    68,    -1,    -1,    -1,    -1,   128,   129,   130,
     131,   132,    -1,    -1,   135,    -1,    -1,   138,    -1,   140,
      -1,   142,   143,    -1,   145,   146,    92,    -1,    -1,   150,
      -1,    -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,
      -1,   107,   108,   109,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   120,    -1,   122,    -1,    -1,    -1,
      -1,    -1,   128,   129,   130,   131,   132,    -1,    -1,   135,
      -1,    -1,   138,    -1,   140,    -1,   142,   143,    -1,    -1,
     146,     7,     8,     9,   150,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    -1,    -1,    -1,    -1,    -1,    24,    25,
      26,    -1,    -1,    -1,    -1,    31,    32,    -1,    34,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,
      -1,    -1,    48,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    60,    -1,     7,     8,     9,    -1,
      -1,    -1,    68,    -1,    -1,    -1,    -1,    18,    -1,    -1,
      -1,    -1,    -1,    24,    25,    26,    -1,    -1,    -1,    -1,
      31,    32,    -1,    -1,    -1,    -1,    92,    -1,    -1,    -1,
      -1,    42,    98,    -1,   100,   101,    -1,    48,    -1,    -1,
      -1,   107,   108,   109,    -1,    -1,    -1,    -1,    -1,    60,
      -1,    -1,    -1,    -1,   120,    -1,   122,    68,    -1,    -1,
      -1,    -1,   128,   129,   130,   131,   132,    -1,    -1,   135,
      -1,    -1,   138,    -1,    -1,    -1,   142,   143,    -1,    -1,
     146,    92,    -1,    -1,   150,    -1,    -1,    98,    -1,   100,
     101,    -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   120,
      -1,   122,    -1,    -1,    -1,    -1,    -1,   128,   129,   130,
     131,   132,    -1,    -1,   135,    -1,    -1,   138,    -1,   140,
      -1,   142,   143,    -1,    -1,   146,     7,     8,     9,   150,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    -1,    -1,
      -1,    -1,    -1,    24,    25,    26,    -1,    -1,    -1,    -1,
      31,    32,    -1,    34,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    60,
      -1,     7,     8,     9,    -1,    -1,    -1,    68,    -1,    -1,
      -1,    -1,    18,    -1,    -1,    -1,    -1,    -1,    24,    25,
      26,    -1,    -1,    -1,    -1,    31,    32,    -1,    34,    -1,
      -1,    92,    -1,    -1,    -1,    -1,    42,    98,    -1,   100,
     101,    -1,    48,    -1,    -1,    -1,   107,   108,   109,    -1,
      -1,    -1,    -1,    -1,    60,    -1,    -1,    -1,    -1,   120,
      -1,   122,    68,    -1,    -1,    -1,    -1,   128,   129,   130,
     131,   132,    -1,    -1,   135,    -1,    -1,   138,    -1,    -1,
      -1,   142,   143,    -1,    -1,   146,    92,    -1,    -1,   150,
      -1,    -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,
      -1,   107,   108,   109,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   120,    -1,   122,    -1,    -1,    -1,
      -1,    -1,   128,   129,   130,   131,   132,    -1,    -1,    -1,
      -1,    -1,   138,    -1,    -1,    -1,   142,   143,    -1,   145,
     146,     7,     8,     9,   150,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    -1,    -1,    -1,    -1,    -1,    24,    25,
      26,    -1,    -1,    -1,    -1,    31,    32,    -1,    34,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,
      -1,    -1,    48,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    60,    -1,     7,     8,     9,    -1,
      -1,    -1,    68,    -1,    -1,    -1,    -1,    18,    -1,    -1,
      -1,    -1,    -1,    24,    25,    26,    -1,    -1,    -1,    -1,
      31,    32,    -1,    -1,    -1,    -1,    92,    -1,    -1,    -1,
      -1,    42,    98,    -1,   100,   101,    -1,    48,    -1,    -1,
      -1,   107,   108,   109,    -1,    -1,    -1,    -1,    -1,    60,
      -1,    -1,    -1,    -1,   120,    -1,   122,    68,    -1,    -1,
      -1,    -1,   128,   129,   130,   131,   132,    -1,    -1,   135,
      -1,    -1,   138,    -1,    -1,    -1,   142,   143,    -1,    -1,
     146,    92,    -1,    -1,   150,    -1,    -1,    98,    -1,   100,
     101,    -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   120,
      -1,   122,    -1,    -1,    -1,    -1,    -1,   128,   129,   130,
     131,   132,    -1,    -1,    -1,    -1,    -1,   138,    -1,   140,
      -1,   142,   143,    -1,   145,   146,     7,     8,     9,   150,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    -1,    -1,
      -1,    -1,    -1,    24,    25,    26,    -1,    -1,    -1,    -1,
      31,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    60,
      -1,     7,     8,     9,    -1,    -1,    -1,    68,    -1,    -1,
      -1,    -1,    18,    -1,    -1,    -1,    -1,    -1,    24,    25,
      26,    -1,    -1,    -1,    -1,    31,    32,    -1,    34,    -1,
      -1,    92,    -1,    -1,    -1,    -1,    42,    98,    -1,   100,
     101,    -1,    48,    -1,    -1,    -1,   107,   108,   109,    -1,
      -1,    -1,    -1,    -1,    60,    -1,    -1,    -1,    -1,   120,
      -1,   122,    68,    -1,    -1,    -1,    -1,   128,   129,   130,
     131,   132,    -1,    -1,   135,    -1,    -1,   138,    -1,    -1,
      -1,   142,   143,    -1,    -1,   146,    92,    -1,    -1,   150,
      -1,    -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,
      -1,   107,   108,   109,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   120,    -1,   122,    -1,    -1,    -1,
      -1,    -1,   128,   129,   130,   131,   132,    -1,     7,     8,
       9,    -1,   138,    -1,    -1,    -1,   142,   143,    -1,    18,
     146,    -1,    -1,    -1,   150,    24,    25,    26,    -1,    -1,
      -1,    -1,    31,    32,    -1,    34,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    60,    -1,     7,     8,     9,    -1,    -1,    -1,    68,
      -1,    -1,    -1,    -1,    18,    -1,    -1,    -1,    -1,    -1,
      24,    25,    26,    -1,    -1,    -1,    -1,    31,    32,    -1,
      -1,    -1,    -1,    92,    -1,    -1,    -1,    -1,    42,    98,
      -1,   100,   101,    -1,    48,    -1,    -1,    -1,   107,   108,
     109,    -1,    -1,    -1,    -1,    -1,    60,    -1,    -1,    -1,
      -1,   120,    -1,   122,    68,    -1,    -1,    -1,    -1,   128,
     129,   130,   131,   132,    -1,    -1,    -1,    -1,    -1,   138,
      -1,    -1,    -1,   142,   143,    -1,    -1,   146,    92,    -1,
      -1,   150,    -1,    -1,    98,    -1,   100,   101,    -1,    -1,
      -1,    -1,    -1,   107,   108,   109,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   120,    -1,   122,    -1,
      -1,    -1,    -1,    -1,   128,   129,   130,   131,   132,    -1,
       7,     8,     9,    -1,   138,    -1,   140,    -1,   142,   143,
      -1,    18,   146,    -1,    -1,    -1,   150,    24,    25,    26,
      -1,    -1,    -1,    -1,    31,    32,    -1,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    42,    -1,    -1,    -1,    -1,
      -1,    48,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    68,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     7,
       8,     9,    -1,    -1,    -1,    92,    -1,    -1,    -1,    -1,
      -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,    -1,
     107,   108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   120,    -1,   122,    -1,    -1,    46,    47,
      -1,   128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,
      -1,   138,    60,    -1,    -1,   142,   143,    -1,    -1,   146,
      68,    69,    70,   150,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    79,    80,    81,    82,    -1,    -1,    -1,     7,     8,
       9,    -1,    90,    91,    -1,    -1,    -1,    -1,    -1,    18,
      98,    -1,   100,   101,    -1,    24,    25,    26,    -1,   107,
     108,   109,    31,    32,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   120,    42,   122,    -1,    -1,    -1,    -1,    48,
     128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,    -1,
     138,    60,    -1,    -1,   142,   143,    -1,    -1,    -1,    68,
      -1,    -1,   150,    -1,    -1,     7,     8,     9,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    92,    -1,    -1,    -1,    -1,    -1,    98,
      -1,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,   108,
     109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    51,
      52,   120,    -1,   122,    -1,    -1,    -1,    -1,    60,   128,
     129,   130,   131,   132,    66,    -1,    68,    -1,    -1,   138,
       7,     8,     9,   142,   143,    -1,    -1,   146,    -1,    -1,
      -1,   150,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,   100,   101,
      -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   120,    -1,
     122,    -1,    -1,    60,    -1,    -1,   128,   129,   130,   131,
     132,    68,    -1,    -1,    -1,    -1,   138,    -1,    75,    76,
     142,   143,   144,    -1,   146,    -1,    -1,    -1,   150,    -1,
      -1,    88,    -1,    -1,    -1,    -1,    -1,    -1,     7,     8,
       9,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,    -1,
     107,   108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,
      -1,   128,   129,   130,   131,   132,    -1,   134,    -1,   136,
      -1,   138,    51,    52,    -1,   142,   143,    -1,    -1,    -1,
      -1,    60,    -1,   150,    -1,    -1,    -1,    66,    -1,    68,
      -1,    -1,    -1,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,
      -1,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,   108,
     109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      54,   120,    -1,   122,    -1,    -1,    60,    -1,    -1,   128,
     129,   130,   131,   132,    68,    -1,    -1,    71,    -1,   138,
      -1,    -1,    76,   142,   143,   144,    -1,   146,    -1,    -1,
      -1,   150,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    98,    -1,   100,   101,    -1,    -1,
      -1,    -1,    -1,   107,   108,   109,    -1,    -1,     7,     8,
       9,    -1,    -1,    -1,    -1,    -1,   120,    -1,   122,    -1,
      -1,    -1,    -1,    -1,   128,   129,   130,   131,   132,    -1,
      29,    -1,   136,    -1,   138,    60,    35,    -1,   142,   143,
      -1,    -1,    -1,    68,    -1,    -1,   150,    -1,    -1,    -1,
      -1,    76,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    60,    87,     7,     8,     9,    -1,    -1,    -1,    68,
      -1,    -1,    -1,    98,    -1,   100,   101,    -1,    -1,    -1,
      -1,    -1,   107,   108,   109,    29,    -1,    -1,    -1,    -1,
      -1,    35,    -1,    -1,    -1,   120,    -1,   122,    -1,    98,
      -1,   100,   101,   128,   129,   130,   131,   132,   107,   108,
     109,   136,    -1,   138,    -1,    -1,    60,   142,   143,    -1,
      -1,   120,    -1,   122,    68,   150,    -1,    -1,    -1,   128,
     129,   130,   131,   132,    -1,    -1,    -1,    -1,    -1,   138,
       7,     8,     9,   142,   143,    -1,    -1,    -1,    -1,    -1,
      -1,   150,    -1,    -1,    98,    -1,   100,   101,    -1,    -1,
      -1,    -1,    29,   107,   108,   109,    -1,    -1,    35,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   120,    -1,   122,    -1,
      -1,    -1,    -1,    -1,   128,   129,   130,   131,   132,    -1,
      -1,    -1,    -1,    60,   138,     7,     8,     9,   142,   143,
      -1,    68,    -1,    -1,    -1,    -1,   150,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,    -1,    -1,
      -1,    -1,    -1,    35,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,    -1,
     107,   108,   109,    -1,    -1,    -1,    -1,    -1,    60,    -1,
       7,     8,     9,   120,    -1,   122,    68,    -1,    -1,    -1,
      -1,   128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,
      -1,   138,    29,    -1,    -1,   142,   143,    -1,    35,    -1,
      -1,    -1,    -1,   150,    -1,    -1,    98,    -1,   100,   101,
      -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,
      -1,    -1,    -1,    60,    -1,     7,     8,     9,   120,    -1,
     122,    68,    -1,    -1,    -1,    -1,   128,   129,   130,   131,
     132,    -1,    -1,    -1,    -1,    -1,   138,    29,    -1,    -1,
     142,   143,    -1,    35,    -1,    -1,    -1,    -1,   150,    -1,
      -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,    -1,
     107,   108,   109,    -1,    -1,    -1,    -1,    -1,    60,    -1,
       7,     8,     9,   120,    -1,   122,    68,    -1,    -1,    -1,
      -1,   128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,
      -1,   138,    29,    -1,    -1,   142,   143,    -1,    35,    -1,
      -1,    -1,    -1,   150,    -1,    -1,    98,    -1,   100,   101,
      -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,
      -1,    -1,    -1,    60,    -1,     7,     8,     9,   120,    -1,
     122,    68,    -1,    -1,    -1,    -1,   128,   129,   130,   131,
     132,    -1,    -1,    -1,    -1,    -1,   138,    -1,    -1,    -1,
     142,   143,    -1,    -1,    -1,    -1,    -1,    -1,   150,    -1,
      -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,    -1,
     107,   108,   109,    -1,    -1,    -1,    -1,    -1,    60,    -1,
       7,     8,     9,   120,    -1,   122,    68,    -1,    -1,    -1,
      -1,   128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,
      -1,   138,    -1,    -1,    -1,   142,   143,    -1,    -1,    -1,
      -1,    -1,    -1,   150,    -1,    -1,    98,    -1,   100,   101,
      -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,
      -1,    -1,    -1,    60,    -1,     7,     8,     9,   120,    -1,
     122,    68,    -1,    -1,    -1,    -1,   128,   129,   130,   131,
     132,    -1,   134,    -1,    -1,    -1,   138,    -1,    -1,    -1,
     142,   143,    -1,    -1,    -1,    -1,    -1,    -1,   150,    -1,
      -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,    -1,
     107,   108,   109,    -1,    -1,    -1,    -1,    -1,    60,    -1,
       7,     8,     9,   120,    -1,   122,    68,    -1,    -1,    -1,
      -1,   128,   129,   130,   131,   132,    -1,   134,    -1,    -1,
      -1,   138,    -1,    -1,    -1,   142,   143,    -1,    -1,    -1,
      -1,    -1,    -1,   150,    -1,    -1,    98,    -1,   100,   101,
      -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,
      -1,    -1,    -1,    60,    -1,     7,     8,     9,   120,    -1,
     122,    68,    -1,    -1,    -1,    -1,   128,   129,   130,   131,
     132,    -1,    -1,    -1,   136,    -1,   138,    -1,    -1,    -1,
     142,   143,    -1,    -1,    -1,    -1,    -1,    -1,   150,    -1,
      -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,    -1,
     107,   108,   109,    -1,    -1,    -1,    -1,    -1,    60,    -1,
       7,     8,     9,   120,    -1,   122,    68,    -1,    -1,    -1,
      -1,   128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,
      -1,   138,    -1,    -1,    -1,   142,   143,   144,    -1,    -1,
      -1,    -1,    -1,   150,    -1,    -1,    98,    -1,   100,   101,
      -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,
      -1,    -1,    -1,    60,    -1,    -1,    -1,    -1,   120,    -1,
     122,    68,    -1,    -1,    -1,    -1,   128,   129,   130,   131,
     132,    -1,   134,     7,     8,     9,   138,    -1,    -1,    -1,
     142,   143,    -1,    -1,    -1,    -1,    -1,    -1,   150,    -1,
      -1,    98,    -1,   100,   101,    -1,    -1,    -1,    -1,    -1,
     107,   108,   109,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    45,    -1,   120,    -1,   122,    -1,    -1,    -1,    -1,
      -1,   128,   129,   130,   131,   132,    60,    -1,   135,    -1,
      -1,   138,    -1,    -1,    68,   142,   143,    -1,     7,     8,
       9,    -1,    -1,   150,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      29,    -1,    -1,    -1,    98,    -1,   100,   101,    -1,    -1,
      -1,    -1,    -1,   107,   108,   109,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   120,    -1,   122,    -1,
      -1,    60,    -1,    -1,   128,   129,   130,   131,   132,    68,
      -1,    -1,    -1,    -1,   138,     7,     8,     9,   142,   143,
      -1,    -1,    -1,    -1,    -1,    -1,   150,    -1,    -1,    -1,
      -1,    -1,     7,     8,     9,    -1,    -1,    29,    -1,    98,
      -1,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,   108,
     109,    -1,    -1,    -1,    29,    -1,    -1,    -1,    -1,    -1,
      -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    60,   128,
     129,   130,   131,   132,    -1,    -1,    68,    -1,    -1,   138,
      -1,    -1,    -1,   142,   143,    60,    -1,    -1,     7,     8,
       9,   150,    -1,    68,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,   100,   101,
      -1,    -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,
      -1,    -1,    -1,    98,    -1,   100,   101,    -1,   120,    -1,
     122,    -1,   107,   108,   109,    -1,   128,   129,   130,   131,
     132,    60,    -1,    -1,    -1,   120,   138,   122,    -1,    68,
     142,   143,    -1,   128,   129,   130,   131,   132,   150,    -1,
      -1,    -1,    -1,   138,     7,     8,     9,   142,   143,    -1,
      -1,    -1,    -1,    -1,    -1,   150,    -1,    -1,    -1,    98,
      -1,   100,   101,    -1,    -1,    -1,    -1,    -1,   107,   108,
     109,     8,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   120,    -1,   122,    -1,    -1,    -1,    -1,    -1,   128,
     129,   130,   131,   132,    -1,    -1,    -1,    60,    -1,   138,
      -1,    -1,    -1,   142,   143,    68,    -1,    -1,    -1,    -1,
      -1,   150,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    60,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    68,    -1,    -1,    -1,    98,    -1,   100,   101,    -1,
      -1,    -1,    -1,    -1,   107,   108,   109,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   120,    -1,   122,
      -1,    98,    -1,   100,   101,   128,   129,   130,   131,   132,
     107,   108,   109,    -1,    -1,   138,    -1,    -1,    -1,   142,
     143,    -1,    -1,   120,    -1,   122,    -1,   150,    -1,    -1,
      -1,   128,   129,   130,   131,   132,    -1,    -1,    -1,    -1,
      -1,   138,    -1,    -1,    -1,   142,   143,    11,    12,    13,
      14,    15,    16,   150,    -1,    19,    20,    21,    22,    23,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    43,
      44,    45,    -1,    -1,    -1,    -1,    50,    51,    52,    -1,
      54,    -1,    -1,    57,    -1,    59,    -1,    61,    62,    63,
      64,    65,    66,    67,    -1,    -1,    -1,    71,    72,    73,
      74,    -1,    -1,    -1,    78,    -1,    -1,    81,    82,    83,
      -1,    85,    -1,    -1,    -1,    89,    -1,    -1,    -1,    93,
      94,    95,    96,    97,    98,    99,    11,    12,    13,    14,
      15,    16,    -1,    18,    19,    20,    21,    22,    23,    24,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    34,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    42,    43,    -1,
      45,    -1,    -1,    48,    -1,    50,    -1,    -1,    -1,    54,
      -1,    -1,   146,    -1,    59,    -1,    61,    62,    63,    64,
      65,    -1,    -1,    -1,    -1,    -1,    71,    72,    73,    74,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,
      85,    -1,    -1,    -1,    89,    -1,    -1,    -1,    93,    94,
      95,    96,    97,    98,    99,    11,    12,    13,    14,    15,
      16,    -1,    18,    19,    20,    21,    22,    23,    24,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    42,    43,    -1,    45,
      -1,    -1,    48,    -1,    50,    -1,    -1,    -1,    54,    -1,
     145,    -1,    -1,    59,    -1,    61,    62,    63,    64,    65,
      -1,    -1,    -1,    -1,    -1,    71,    72,    73,    74,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,    85,
      -1,    -1,    -1,    89,    -1,    -1,    -1,    93,    94,    95,
      96,    97,    98,    99,    11,    12,    13,    14,    15,    16,
      -1,    18,    19,    20,    21,    22,    23,    24,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    42,    43,    -1,    45,    -1,
      -1,    48,    -1,    50,   140,    -1,    -1,    54,    -1,   145,
      -1,    -1,    59,    -1,    61,    62,    63,    64,    65,    -1,
      -1,    -1,    -1,    -1,    71,    72,    73,    74,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    -1,    85,    -1,
      -1,    -1,    89,    -1,    -1,    -1,    93,    94,    95,    96,
      97,    98,    99,    11,    12,    13,    14,    15,    16,    -1,
      18,    19,    20,    21,    22,    23,    24,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    34,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    43,    -1,    45,    -1,    -1,
      48,    -1,    50,    -1,    -1,    -1,    54,    -1,   145,    -1,
      -1,    59,    -1,    61,    62,    63,    64,    65,    -1,    -1,
      -1,    -1,    -1,    71,    72,    73,    74,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    -1,    85,    -1,    -1,
      -1,    89,    -1,    -1,    -1,    93,    94,    95,    96,    97,
      98,    99,    11,    12,    13,    14,    15,    16,    -1,    18,
      19,    20,    21,    22,    23,    24,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    42,    43,    -1,    45,    -1,    -1,    48,
      -1,    50,    -1,    -1,    -1,    54,    -1,   145,    -1,    -1,
      59,    -1,    61,    62,    63,    64,    65,    -1,    -1,    -1,
      -1,    -1,    71,    72,    73,    74,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    -1,    85,    -1,    -1,    -1,
      89,    -1,    -1,    -1,    93,    94,    95,    96,    97,    98,
      99,    11,    12,    13,    14,    15,    16,    -1,    18,    19,
      20,    21,    22,    23,    24,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,    -1,
      -1,    -1,    42,    43,    -1,    45,    -1,    -1,    48,    -1,
      50,   140,    -1,    -1,    54,    -1,    -1,    -1,    -1,    59,
      -1,    61,    62,    63,    64,    65,    -1,    -1,    -1,    -1,
      -1,    71,    72,    73,    74,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,
      -1,    -1,    -1,    93,    94,    95,    96,    97,    98,    99,
      11,    12,    13,    14,    15,    16,    -1,    18,    19,    20,
      21,    22,    23,    24,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,    -1,    -1,
      -1,    42,    43,    -1,    45,    -1,    -1,    48,    -1,    50,
      -1,    -1,    -1,    54,    -1,    -1,    -1,    -1,    59,    -1,
      61,    62,    63,    64,    65,    -1,    -1,    -1,    -1,    -1,
      71,    72,    73,    74,    -1,    -1,    -1,    -1,    -1,    -1,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,
      -1,    -1,    93,    94,    95,    96,    97,    98,    99,    11,
      12,    13,    14,    15,    16,    -1,    18,    19,    20,    21,
      22,    23,    24,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      42,    43,    -1,    45,    -1,    -1,    48,    -1,    50,    -1,
      -1,    -1,    54,    -1,    -1,    -1,    -1,    59,    -1,    61,
      62,    63,    64,    65,    -1,    -1,    -1,    -1,    -1,    71,
      72,    73,    74,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      82,    83,    -1,    85,    -1,    -1,    -1,    89,    -1,    -1,
      -1,    93,    94,    95,    96,    97,    98,    99,    11,    12,
      13,    14,    15,    16,    -1,    18,    19,    20,    21,    22,
      23,    24,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    42,
      43,    -1,    45,    -1,    -1,    48,    -1,    50,    -1,    -1,
      -1,    54,    -1,    -1,    -1,    -1,    59,    -1,    61,    62,
      63,    64,    65,    -1,    -1,    -1,    -1,    -1,    71,    72,
      73,    74,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,
      83,    -1,    85,    -1,    -1,    -1,    89,    -1,    -1,    -1,
      93,    94,    95,    96,    97,    98,    99,    11,    12,    13,
      14,    15,    16,    -1,    18,    19,    20,    21,    22,    23,
      24,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    42,    43,
      -1,    45,    -1,    -1,    48,    -1,    50,    -1,    -1,    -1,
      54,    -1,    -1,    -1,    -1,    59,    -1,    61,    62,    63,
      64,    65,    -1,    -1,    -1,    -1,    -1,    71,    72,    73,
      74,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,
      -1,    85,    -1,    -1,    -1,    89,    -1,    -1,    -1,    93,
      94,    95,    96,    97,    98,    99,    11,    12,    13,    14,
      15,    16,    -1,    18,    19,    20,    21,    22,    23,    24,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    34,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    42,    43,    -1,
      45,    -1,    -1,    48,    -1,    50,    -1,    -1,    -1,    54,
      -1,    -1,    -1,    -1,    59,    -1,    61,    62,    63,    64,
      65,    -1,    -1,    -1,    -1,    -1,    71,    72,    73,    74,
      -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,
      85,    -1,    -1,    -1,    89,    -1,    -1,    -1,    93,    94,
      95,    96,    97,    98,    99,    11,    12,    13,    14,    15,
      16,    -1,    18,    19,    20,    21,    22,    23,    24,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    34,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    42,    43,    -1,    45,
      -1,    -1,    48,    -1,    50,    -1,    -1,    -1,    54,    -1,
      -1,    -1,    -1,    59,    -1,    61,    62,    63,    64,    65,
      -1,    -1,    -1,    -1,    -1,    71,    72,    73,    74,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,    85,
      -1,    -1,    -1,    89,    -1,    -1,    -1,    93,    94,    95,
      96,    97,    98,    99,    11,    12,    13,    14,    15,    16,
      -1,    18,    19,    20,    21,    22,    23,    24,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    42,    43,    -1,    45,    -1,
      -1,    48,    -1,    50,    -1,    -1,    -1,    54,    -1,    -1,
      -1,    -1,    59,    -1,    61,    62,    63,    64,    65,    -1,
      -1,    -1,    -1,    -1,    71,    72,    73,    74,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    83,    -1,    85,    -1,
      -1,    -1,    89,    -1,    -1,    -1,    93,    94,    95,    96,
      97,    98,    99,    11,    12,    13,    14,    15,    16,    -1,
      18,    19,    20,    21,    22,    23,    24,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    34,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    43,    -1,    45,    -1,    -1,
      48,    -1,    50,    -1,    -1,    -1,    54,    -1,    -1,    -1,
      -1,    59,    -1,    61,    62,    63,    64,    65,    -1,    -1,
      -1,    -1,    -1,    71,    72,    73,    74,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    83,    -1,    85,    -1,    -1,
      -1,    89,    -1,    -1,    -1,    93,    94,    95,    96,    97,
      98,    99,    11,    12,    13,    14,    15,    16,    -1,    18,
      19,    20,    21,    22,    23,    24,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    34,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    42,    43,    -1,    45,    -1,    -1,    48,
      -1,    50,    -1,    -1,    -1,    54,    -1,    -1,    -1,    -1,
      59,    -1,    61,    62,    63,    64,    65,    -1,    -1,    -1,
      -1,    -1,    71,    72,    73,    74,    -1,    -1,    -1,    -1,
      -1,    -1,    81,    82,    83,    -1,    85,    -1,    -1,    -1,
      89,    -1,    -1,    -1,    93,    94,    95,    96,    97,    98,
      99,    11,    12,    13,    14,    15,    16,    -1,    18,    19,
      20,    21,    22,    23,    24,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    34,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    42,    43,    -1,    45,    -1,    -1,    48,    -1,
      50,    -1,    -1,    -1,    54,    -1,    -1,    -1,    -1,    59,
      -1,    61,    62,    63,    64,    65,    -1,    -1,    -1,    -1,
      -1,    71,    72,    73,    74,    -1,    -1,    -1,    -1,    -1,
      -1,    81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,
      -1,    -1,    -1,    93,    94,    95,    96,    97,    98,    99
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int16 yystos[] =
{
       0,    58,   146,   148,   170,   171,   172,   229,   276,   277,
      98,     7,     8,     9,    60,    68,    98,   100,   101,   107,
     108,   109,   120,   122,   128,   129,   130,   131,   132,   138,
     142,   143,   150,   254,   255,   257,   258,   260,   261,   262,
     263,   264,   265,   266,   267,   268,   269,   270,   271,   272,
     273,   275,   149,     0,     3,   172,   229,    58,   148,   277,
     134,   140,   143,   173,   143,   143,   260,   260,   143,   260,
     260,   260,   260,   260,   260,   260,   260,   260,   260,   257,
      98,   257,   274,    65,   141,   147,   136,   143,   259,   121,
     107,   108,   109,   110,   123,   124,   125,   120,   122,   104,
     105,   114,   115,   112,   113,   126,   127,   116,   117,   118,
     119,   130,   132,   131,   106,   111,   133,    98,   149,   143,
       1,    11,    12,    13,    14,    15,    16,    19,    20,    21,
      22,    23,    39,    43,    44,    45,    50,    51,    52,    54,
      57,    59,    61,    62,    63,    64,    65,    66,    67,    71,
      72,    73,    74,    78,    81,    82,    83,    85,    89,    93,
      94,    95,    96,    97,    98,    99,   174,   177,   179,   181,
     182,   183,   184,   185,   186,   187,   188,   189,   190,   194,
     195,   196,   203,   209,   216,   217,   218,   219,   230,   276,
     144,   176,   177,   257,   276,   140,   257,   257,   257,   138,
     139,   254,   143,   144,   145,   144,   257,   257,   257,   144,
     257,   273,   260,   260,   260,   260,   260,   261,   261,   261,
     262,   262,   263,   263,   263,   263,   264,   264,   264,   264,
     265,   265,   265,   265,   266,   267,   268,   269,   270,   257,
     140,   173,   175,   185,   140,    18,    24,    25,    26,    31,
      32,    42,    48,    92,   101,   135,   231,   232,   237,   238,
     241,   242,   243,   244,   246,   253,   256,   257,   276,   238,
     238,   238,   134,   143,   197,   200,   257,    17,    54,    76,
      98,   204,   259,    18,    24,    38,    42,    48,   182,   220,
     222,   223,   224,   227,   228,   257,   238,   257,    54,    76,
      54,    76,   154,   201,   202,   257,   259,    17,    98,   134,
     257,    39,   181,    19,    22,    54,    71,    72,    76,    84,
      87,    95,    99,   180,   196,   257,   259,   257,   259,   140,
      76,    87,   257,   259,    75,    76,    88,   191,   192,   193,
     197,   200,   257,   259,   197,   200,   257,   179,   182,   186,
     187,   219,     4,   144,   144,    39,   174,   144,   144,   144,
     257,   139,   144,   257,   257,   137,   145,   152,   153,   144,
     145,    39,   174,   140,     5,   141,   144,    34,   145,   236,
     238,   143,   143,   143,    98,   238,   143,   143,   143,   140,
     143,     6,    98,   123,   143,   140,   140,   140,   238,   239,
     276,   112,   121,   140,   231,   232,   237,   242,   243,   244,
     246,   253,   256,   257,   143,   257,    46,    47,    69,    70,
      79,    80,    81,    82,    90,    91,   198,   199,   200,   257,
     257,   140,    54,    76,    54,   140,   143,    98,   259,    98,
      34,   145,   220,   143,   143,   143,    38,   222,   140,   140,
     140,   140,   141,   140,   201,   257,    98,   140,   143,   143,
     140,    76,    87,    87,    87,    76,    87,    87,    87,    76,
      87,   257,   259,    76,    87,   140,   178,   257,   257,   257,
     259,   257,   259,   140,   257,   200,   259,   257,   257,   200,
     259,   191,   140,   200,   257,   257,   140,   180,   257,   259,
     177,    39,   144,   145,   257,   257,   257,   272,    39,    39,
     174,   185,   185,   143,    98,    34,   238,   257,   257,   257,
     140,    92,   257,   257,   257,   257,   257,   140,   241,   257,
     241,   257,   140,   140,   257,   141,   141,   141,   141,   257,
     140,   140,    54,   179,   186,   189,   195,   205,   207,   214,
     215,   276,   208,   214,   276,   140,   143,    98,   140,   143,
      98,    34,   257,    45,   257,   257,   202,   140,   140,   140,
     143,   210,   211,   214,   215,   238,   276,   212,   214,   257,
     178,   257,   178,   140,   257,   140,   257,   140,   200,   140,
     140,   200,   257,   140,   140,   257,   259,   178,   257,   257,
     137,   137,   137,    39,   144,   176,   257,    34,   206,   215,
     236,   276,   144,   144,   144,   143,   140,   144,   144,   144,
     144,   257,   257,   141,   199,   198,    46,   199,    47,   198,
     140,    54,    71,    76,   213,   257,   259,    18,    24,    25,
      26,    32,    42,    48,    92,   207,   234,   240,   242,   245,
     249,   252,   256,   257,   276,   140,   179,   186,   189,   195,
       4,   144,   205,   208,   140,   143,   205,   208,    34,   220,
     144,    98,   140,   144,   210,   238,   212,   211,   238,    41,
       4,   144,   144,   178,   140,   140,   140,   178,   257,   178,
     144,   144,    34,   215,   236,    34,    29,   247,   248,   257,
     247,   247,   257,   257,   239,   238,   140,   257,   144,   144,
     144,   144,   144,   144,    76,   257,   259,   257,    34,   145,
     235,   240,   276,   143,   143,   143,   240,   143,   143,   143,
      37,   140,   234,   242,   245,   249,   252,   256,   257,   213,
     257,   259,   214,   140,   240,   144,   205,   208,   240,   144,
      34,    29,   225,   226,   257,   121,   257,   140,   221,   222,
     230,   238,    41,   144,    41,   214,   140,   257,   178,    34,
     145,   239,    35,   248,   145,    35,    35,   144,   140,    33,
     144,   257,    98,    34,   240,   257,   257,   257,    92,   257,
     257,   257,   140,   257,   259,   257,   206,   240,   276,    37,
     140,   240,   144,    37,   140,   145,   221,    35,   226,   145,
     257,   140,    33,    41,   140,   206,   238,   140,   239,   239,
     140,   257,   239,    34,   206,   235,   144,   144,   144,   143,
     140,   144,   144,   257,   240,    37,   206,   240,    37,   140,
     206,   240,   221,   221,   140,   257,   221,   206,   238,   238,
      41,   144,    34,   235,    34,    29,   250,   251,   257,   250,
     250,   257,   257,   140,   233,   240,   240,    37,   240,    37,
     206,   240,   240,    37,   257,   144,   238,    41,    41,   238,
      34,   145,   233,    35,   251,   145,    35,    35,   144,   140,
      33,    37,   240,    37,    37,   140,    18,    41,   233,   233,
     140,   257,   233,    37,   257,    34,   145,   220,   144,   144,
      98,    34,   240,    18,    34,   220,    34,   145,   220,    34,
      98,    34,    34,   220,    34
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int16 yyr1[] =
{
       0,   169,   170,   171,   171,   171,   171,   172,   172,   172,
     172,   172,   172,   172,   172,   173,   173,   173,   173,   173,
     173,   173,   174,   174,   175,   175,   175,   176,   176,   177,
     177,   177,   177,   177,   177,   177,   177,   178,   178,   179,
     179,   179,   180,   180,   180,   180,   180,   180,   180,   180,
     180,   180,   180,   180,   180,   180,   180,   180,   180,   180,
     180,   180,   180,   180,   180,   181,   181,   181,   181,   181,
     181,   181,   181,   181,   181,   182,   182,   182,   182,   182,
     182,   182,   182,   182,   183,   183,   183,   183,   183,   183,
     184,   184,   184,   184,   184,   184,   185,   185,   186,   187,
     187,   187,   187,   188,   189,   190,   190,   190,   191,   191,
     191,   191,   191,   191,   191,   191,   191,   191,   192,   192,
     193,   193,   194,   194,   194,   194,   194,   194,   195,   195,
     195,   195,   195,   195,   196,   196,   196,   196,   196,   196,
     196,   196,   197,   197,   197,   197,   197,   197,   198,   198,
     198,   198,   199,   199,   199,   199,   200,   200,   201,   201,
     202,   203,   203,   203,   203,   203,   203,   203,   203,   203,
     203,   203,   203,   204,   204,   204,   204,   204,   204,   204,
     205,   205,   206,   206,   207,   207,   208,   208,   209,   209,
     209,   209,   209,   209,   209,   209,   210,   210,   211,   211,
     212,   212,   213,   213,   213,   213,   214,   214,   214,   214,
     214,   214,   214,   214,   215,   215,   215,   215,   215,   215,
     216,   216,   216,   216,   217,   217,   217,   217,   217,   217,
     217,   217,   217,   217,   217,   217,   218,   218,   219,   219,
     220,   220,   221,   221,   222,   222,   222,   222,   222,   222,
     222,   223,   223,   224,   225,   225,   226,   226,   226,   227,
     227,   227,   227,   227,   227,   227,   227,   228,   228,   228,
     228,   229,   229,   230,   230,   230,   230,   231,   231,   232,
     232,   233,   233,   234,   234,   234,   234,   234,   234,   235,
     235,   236,   236,   237,   237,   237,   237,   237,   237,   238,
     238,   238,   238,   238,   238,   238,   238,   238,   238,   238,
     238,   238,   238,   238,   238,   238,   238,   238,   239,   239,
     239,   240,   240,   240,   240,   240,   240,   240,   240,   240,
     240,   240,   240,   240,   240,   241,   241,   241,   241,   242,
     243,   244,   244,   245,   245,   246,   246,   246,   247,   247,
     248,   248,   248,   249,   249,   249,   250,   250,   251,   251,
     251,   252,   252,   252,   253,   253,   253,   254,   255,   256,
     256,   257,   257,   257,   257,   258,   258,   258,   258,   259,
     259,   259,   259,   260,   260,   260,   260,   260,   260,   260,
     260,   260,   260,   260,   260,   260,   260,   260,   261,   261,
     261,   261,   261,   262,   262,   262,   262,   263,   263,   263,
     264,   264,   264,   264,   264,   265,   265,   265,   265,   265,
     266,   266,   266,   266,   266,   267,   267,   268,   268,   269,
     269,   270,   270,   271,   271,   272,   272,   273,   273,   274,
     275,   275,   275,   275,   275,   275,   275,   275,   275,   275,
     275,   275,   276,   276,   277
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     1,     1,     2,     2,     4,     5,     5,
       6,     5,     6,     6,     7,     2,     3,     3,     4,     6,
       7,     7,     1,     2,     1,     3,     3,     1,     3,     3,
       4,     4,     5,     4,     5,     5,     6,     1,     0,     1,
       1,     1,     1,     1,     2,     1,     2,     1,     1,     1,
       2,     2,     2,     1,     2,     2,     1,     2,     2,     1,
       2,     1,     2,     1,     2,     1,     1,     1,     1,     1,
       2,     2,     2,     2,     2,     1,     1,     1,     1,     2,
       2,     2,     2,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     2,     2,     2,     2,     3,     2,     3,
       3,     4,     4,     3,     3,     3,     4,     4,     1,     1,
       1,     1,     2,     2,     2,     2,     3,     3,     1,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     4,
       4,     5,     4,     5,     1,     1,     1,     1,     1,     1,
       1,     1,     5,     5,     5,     5,     5,     5,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     6,     1,     3,
       2,     6,     8,     9,     7,     9,    10,     7,     9,    10,
       8,    10,    11,     1,     1,     2,     1,     2,     2,     3,
       1,     2,     1,     2,     1,     2,     1,     3,     5,     6,
       6,     7,     8,     9,     9,    10,     1,     2,     1,     1,
       1,     3,     1,     1,     2,     1,     2,     3,     3,     4,
       3,     4,     4,     5,     1,     1,     1,     2,     2,     2,
       3,     4,     4,     5,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     7,     2,     3,
       1,     2,     1,     1,     1,     5,     7,     1,     1,     1,
       1,     5,     7,     6,     1,     2,     3,     2,     3,    12,
      13,    10,    11,    15,    16,    13,    14,     2,     3,     4,
       5,     2,     3,     3,     4,     4,     5,     4,     3,     4,
       3,     1,     1,     2,     3,     4,     5,     5,     6,     1,
       2,     1,     2,     2,     3,     4,     5,     5,     6,     2,
       2,     1,     1,     1,     1,     2,     1,     1,     1,     3,
       2,     2,     2,     2,     3,     2,     2,     2,     1,     1,
       2,     2,     1,     1,     1,     1,     1,     1,     3,     2,
       2,     2,     2,     2,     2,     2,     4,     2,     2,     3,
       2,     5,     7,     5,     7,     6,     6,     6,     1,     2,
       3,     2,     3,     6,     6,     6,     1,     2,     3,     2,
       3,     9,     5,     7,     9,     5,     7,     3,     4,     2,
       5,     1,     1,     3,     3,     1,     3,     4,     2,     3,
       5,     5,     5,     1,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     4,     4,     1,     3,
       3,     3,     3,     1,     3,     3,     3,     1,     3,     3,
       1,     3,     3,     3,     3,     1,     3,     3,     3,     3,
       1,     3,     3,     3,     3,     1,     3,     1,     3,     1,
       3,     1,     3,     1,     3,     1,     5,     1,     3,     5,
       1,     1,     1,     1,     4,     2,     5,     4,     1,     1,
       3,     3,     1,     2,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* verilog_synthesis_unit: source_text MY_EOF  */
#line 329 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      YYACCEPT;
    }
#line 3550 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 3: /* source_text: module_declaration  */
#line 341 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 3557 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 4: /* source_text: udp_declaration  */
#line 344 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 3564 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 5: /* source_text: source_text module_declaration  */
#line 347 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 3571 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 6: /* source_text: source_text udp_declaration  */
#line 350 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 3578 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 7: /* module_declaration: vMODULE vIDENT ';' vENDMODULE  */
#line 357 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      veri_parser->gen_mod( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-2].symbol).content, NULL, NULL, NULL );
      free((yyvsp[-2].symbol).content);
    }
#line 3587 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 8: /* module_declaration: vMODULE vIDENT module_port_part ';' vENDMODULE  */
#line 362 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      veri_parser->gen_mod( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].symbol).content, (yyvsp[-2].extra_tok).node[0],
                            (yyvsp[-2].extra_tok).node[1], NULL );
      free((yyvsp[-3].symbol).content);
    }
#line 3597 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 9: /* module_declaration: vMODULE vIDENT ';' module_item_list vENDMODULE  */
#line 368 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      veri_parser->gen_mod( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].symbol).content, NULL, NULL, (yyvsp[-1].tok) );
      free((yyvsp[-3].symbol).content);
    }
#line 3606 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 10: /* module_declaration: vMODULE vIDENT module_port_part ';' module_item_list vENDMODULE  */
#line 374 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      veri_parser->gen_mod( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, (yyvsp[-4].symbol).content, (yyvsp[-3].extra_tok).node[0],
                            (yyvsp[-3].extra_tok).node[1], (yyvsp[-1].tok) );
      free((yyvsp[-4].symbol).content);
    }
#line 3616 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 11: /* module_declaration: attr_inst_list vMODULE vIDENT ';' vENDMODULE  */
#line 380 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      veri_parser->gen_mod( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-2].symbol).content, NULL, NULL, NULL );
      free((yyvsp[-2].symbol).content);
    }
#line 3625 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 12: /* module_declaration: attr_inst_list vMODULE vIDENT module_port_part ';' vENDMODULE  */
#line 385 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      veri_parser->gen_mod( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].symbol).content, (yyvsp[-2].extra_tok).node[0],
                            (yyvsp[-2].extra_tok).node[1], NULL );
      free((yyvsp[-3].symbol).content);
    }
#line 3635 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 13: /* module_declaration: attr_inst_list vMODULE vIDENT ';' module_item_list vENDMODULE  */
#line 391 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      veri_parser->gen_mod( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].symbol).content, NULL, NULL, (yyvsp[-1].tok) );
      free((yyvsp[-3].symbol).content);
    }
#line 3644 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 14: /* module_declaration: attr_inst_list vMODULE vIDENT module_port_part ';' module_item_list vENDMODULE  */
#line 397 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      veri_parser->gen_mod( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, (yyvsp[-4].symbol).content, (yyvsp[-3].extra_tok).node[0],
                            (yyvsp[-3].extra_tok).node[1], (yyvsp[-1].tok) );
      free((yyvsp[-4].symbol).content);
    }
#line 3654 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 15: /* module_port_part: '(' ')'  */
#line 406 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = NULL;
    }
#line 3665 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 16: /* module_port_part: '(' expression ')'  */
#line 413 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* arg-list or .arg()-list */
      (yyval.extra_tok).line = (yyvsp[-2].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-2].symbol).col;
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = (yyvsp[-1].tok);
    }
#line 3677 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 17: /* module_port_part: '(' port_decl_list ')'  */
#line 421 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* arg-list or .arg()-list */
      (yyval.extra_tok).line = (yyvsp[-2].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-2].symbol).col;
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = (yyvsp[-1].tok);
    }
#line 3689 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 18: /* module_port_part: '#' '(' param_decl_list ')'  */
#line 429 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-3].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-3].symbol).col;
      (yyval.extra_tok).node[0] = (yyvsp[-1].tok);
      (yyval.extra_tok).node[1] = NULL;
    }
#line 3700 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 19: /* module_port_part: '#' '(' param_decl_list ')' '(' ')'  */
#line 436 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-5].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-5].symbol).col;
      (yyval.extra_tok).node[0] = (yyvsp[-3].tok);
      (yyval.extra_tok).node[1] = NULL;
    }
#line 3711 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 20: /* module_port_part: '#' '(' param_decl_list ')' '(' expression ')'  */
#line 443 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* arg-list or .arg()-list */
      (yyval.extra_tok).line = (yyvsp[-6].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-6].symbol).col;
      (yyval.extra_tok).node[0] = (yyvsp[-4].tok);
      (yyval.extra_tok).node[1] = (yyvsp[-1].tok);
    }
#line 3723 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 21: /* module_port_part: '#' '(' param_decl_list ')' '(' port_decl_list ')'  */
#line 451 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* arg-list or .arg()-list */
      (yyval.extra_tok).line = (yyvsp[-6].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-6].symbol).col;
      (yyval.extra_tok).node[0] = (yyvsp[-4].tok);
      (yyval.extra_tok).node[1] = (yyvsp[-1].tok);
    }
#line 3735 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 22: /* module_item_list: module_item  */
#line 462 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_mod_item_list( (yyvsp[0].tok) );
    }
#line 3743 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 23: /* module_item_list: module_item_list module_item  */
#line 466 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_mod_item_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 3751 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 24: /* param_decl_list: param_decl_item  */
#line 474 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_param_decl_list( (yyvsp[0].tok) );
    }
#line 3759 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 25: /* param_decl_list: param_decl_list ',' param_decl_item  */
#line 478 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_param_decl_list( (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 3767 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 26: /* param_decl_list: param_decl_list vPARAM_DELIM param_decl_item  */
#line 482 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_param_decl_list( (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 3775 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 27: /* port_decl_list: port_declaration  */
#line 490 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_port_decl_list( (yyvsp[0].tok) );
    }
#line 3783 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 28: /* port_decl_list: port_decl_list vPORT_DELIM port_declaration  */
#line 494 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_port_decl_list( (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 3791 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 29: /* port_declaration: in_or_out expression port_term  */
#line 502 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, (yyvsp[-2].extra_tok).extra[0],
                                           vvWIRE, IS_FALSE, vpSCALAR, NULL,
                                           NULL, NULL, (yyvsp[-1].tok) );
    }
#line 3801 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 30: /* port_declaration: in_or_out port_type expression port_term  */
#line 508 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, (yyvsp[-3].extra_tok).extra[0],
                                           (yyvsp[-2].extra_tok).extra[0], (yyvsp[-2].extra_tok).extra[1], vpSCALAR,
                                           NULL, NULL, NULL,
                                           (yyvsp[-1].tok) );
    }
#line 3812 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 31: /* port_declaration: attr_inst_list in_or_out expression port_term  */
#line 515 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, (yyvsp[-2].extra_tok).extra[0],
                                           vvWIRE, IS_FALSE, vpSCALAR, NULL,
                                           NULL, NULL, (yyvsp[-1].tok) );
    }
#line 3822 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 32: /* port_declaration: attr_inst_list in_or_out port_type expression port_term  */
#line 521 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, (yyvsp[-3].extra_tok).extra[0],
                                           (yyvsp[-2].extra_tok).extra[0], (yyvsp[-2].extra_tok).extra[1], vpSCALAR,
                                           NULL, NULL, NULL,
                                           (yyvsp[-1].tok) );
    }
#line 3833 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 33: /* port_declaration: in_or_out range expression port_term  */
#line 528 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, (yyvsp[-3].extra_tok).extra[0],
                                           vvWIRE, IS_FALSE, vpSCALAR, NULL,
                                           (yyvsp[-2].tok), NULL, (yyvsp[-1].tok) );
    }
#line 3843 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 34: /* port_declaration: in_or_out port_type range expression port_term  */
#line 534 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-4].extra_tok).line, (yyvsp[-4].extra_tok).col, (yyvsp[-4].extra_tok).extra[0],
                                           (yyvsp[-3].extra_tok).extra[0], (yyvsp[-3].extra_tok).extra[1], vpSCALAR,
                                           NULL, (yyvsp[-2].tok), NULL,
                                           (yyvsp[-1].tok) );
    }
#line 3854 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 35: /* port_declaration: attr_inst_list in_or_out range expression port_term  */
#line 541 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, (yyvsp[-3].extra_tok).extra[0],
                                           vvWIRE, IS_FALSE, vpSCALAR, NULL,
                                           (yyvsp[-2].tok), NULL, (yyvsp[-1].tok) );
    }
#line 3864 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 36: /* port_declaration: attr_inst_list in_or_out port_type range expression port_term  */
#line 547 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-4].extra_tok).line, (yyvsp[-4].extra_tok).col, (yyvsp[-4].extra_tok).extra[0],
                                           (yyvsp[-3].extra_tok).extra[0], (yyvsp[-3].extra_tok).extra[1], vpSCALAR,
                                           NULL, (yyvsp[-2].tok), NULL,
                                           (yyvsp[-1].tok) );
    }
#line 3875 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 39: /* in_or_out: vINPUT  */
#line 562 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpIN;
    }
#line 3885 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 40: /* in_or_out: vOUTPUT  */
#line 568 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpOUT;
    }
#line 3895 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 41: /* in_or_out: vINOUT  */
#line 574 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpINOUT;
    }
#line 3905 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 42: /* port_type: vSIGNED  */
#line 583 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvWIRE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 3916 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 43: /* port_type: net_type  */
#line 590 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].extra_tok).line;
      (yyval.extra_tok).col  = (yyvsp[0].extra_tok).col;
      (yyval.extra_tok).extra[0] = (yyvsp[0].extra_tok).extra[0];
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 3927 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 44: /* port_type: net_type vSIGNED  */
#line 597 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].extra_tok).line;
      (yyval.extra_tok).col  = (yyvsp[-1].extra_tok).col;
      (yyval.extra_tok).extra[0] = (yyvsp[-1].extra_tok).extra[0];
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 3938 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 45: /* port_type: vREG  */
#line 604 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvREG;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 3949 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 46: /* port_type: vREG vSIGNED  */
#line 611 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvREG;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 3960 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 47: /* port_type: vINT  */
#line 618 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvINT;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 3971 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 48: /* port_type: vTIME  */
#line 625 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvTIME;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 3982 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 49: /* port_type: vUNSIGNED  */
#line 632 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* NOTE: Standalone "unsigned" in a port declaration is accepted
         as "wire unsigned". Strict SystemVerilog requires unsigned
         to modify a concrete type (e.g. "logic unsigned"). This is an
         accepted superset behavior. */
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvWIRE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 3997 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 50: /* port_type: net_type vUNSIGNED  */
#line 643 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].extra_tok).line;
      (yyval.extra_tok).col  = (yyvsp[-1].extra_tok).col;
      (yyval.extra_tok).extra[0] = (yyvsp[-1].extra_tok).extra[0];
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4008 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 51: /* port_type: vREG vUNSIGNED  */
#line 650 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvREG;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4019 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 52: /* port_type: vINT vUNSIGNED  */
#line 657 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvINT;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4030 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 53: /* port_type: vLOGIC  */
#line 664 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvLOGIC;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4041 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 54: /* port_type: vLOGIC vSIGNED  */
#line 671 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvLOGIC;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 4052 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 55: /* port_type: vLOGIC vUNSIGNED  */
#line 678 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvLOGIC;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4063 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 56: /* port_type: vBIT  */
#line 685 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvBIT;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4074 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 57: /* port_type: vBIT vSIGNED  */
#line 692 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvBIT;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 4085 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 58: /* port_type: vBIT vUNSIGNED  */
#line 699 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvBIT;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4096 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 59: /* port_type: vBYTE  */
#line 706 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvBYTE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 4107 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 60: /* port_type: vBYTE vUNSIGNED  */
#line 713 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvBYTE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4118 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 61: /* port_type: vSHORTINT  */
#line 720 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvSHORTINT;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 4129 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 62: /* port_type: vSHORTINT vUNSIGNED  */
#line 727 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvSHORTINT;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4140 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 63: /* port_type: vLONGINT  */
#line 734 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvLONGINT;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 4151 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 64: /* port_type: vLONGINT vUNSIGNED  */
#line 741 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvLONGINT;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 4162 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 65: /* module_item: port_declaration  */
#line 753 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4170 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 66: /* module_item: module_or_gen_item  */
#line 757 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4178 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 67: /* module_item: generated_instantiation  */
#line 761 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4186 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 68: /* module_item: param_declaration  */
#line 765 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4194 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 69: /* module_item: specparam_declaration  */
#line 769 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4202 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 70: /* module_item: attr_inst_list module_or_gen_item  */
#line 773 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4210 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 71: /* module_item: attr_inst_list generated_instantiation  */
#line 777 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4218 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 72: /* module_item: attr_inst_list param_declaration  */
#line 781 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4226 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 73: /* module_item: attr_inst_list specparam_declaration  */
#line 785 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4234 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 74: /* module_item: error ';'  */
#line 789 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_dummy_stmt( veri_lno, veri_col );
    }
#line 4242 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 75: /* module_or_gen_item: module_or_gen_item_declaration  */
#line 796 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4250 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 76: /* module_or_gen_item: continuous_assign  */
#line 800 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4258 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 77: /* module_or_gen_item: gate_instantiation  */
#line 804 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4266 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 78: /* module_or_gen_item: module_instantiation  */
#line 808 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4274 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 79: /* module_or_gen_item: vINIT statement  */
#line 812 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_init_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 4282 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 80: /* module_or_gen_item: vALWAYS statement  */
#line 816 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_always_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok), akALWAYS );
    }
#line 4290 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 81: /* module_or_gen_item: vALWAYS_COMB statement  */
#line 820 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_always_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok), akALWAYS_COMB );
    }
#line 4298 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 82: /* module_or_gen_item: vALWAYS_FF statement  */
#line 824 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_always_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok), akALWAYS_FF );
    }
#line 4306 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 83: /* module_or_gen_item: vALWAYS_LATCH statement  */
#line 828 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_always_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok), akALWAYS_LATCH );
    }
#line 4314 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 84: /* module_or_gen_item_declaration: net_declaration  */
#line 835 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4322 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 85: /* module_or_gen_item_declaration: reg_declaration  */
#line 839 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4330 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 86: /* module_or_gen_item_declaration: int_declaration  */
#line 843 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4338 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 87: /* module_or_gen_item_declaration: genvar_declaration  */
#line 847 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4346 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 88: /* module_or_gen_item_declaration: task_declaration  */
#line 851 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4354 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 89: /* module_or_gen_item_declaration: func_declaration  */
#line 855 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 4362 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 90: /* param_declarator: vLOCAL_PARAM  */
#line 867 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
      (yyval.extra_tok).extra[2] = IS_TRUE;
    }
#line 4374 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 91: /* param_declarator: vPARAMETER  */
#line 875 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
      (yyval.extra_tok).extra[2] = IS_FALSE;
    }
#line 4386 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 92: /* param_declarator: vLOCAL_PARAM vSIGNED  */
#line 883 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
      (yyval.extra_tok).extra[2] = IS_TRUE;
    }
#line 4398 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 93: /* param_declarator: vLOCAL_PARAM vINT  */
#line 891 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
      (yyval.extra_tok).extra[2] = IS_TRUE;
    }
#line 4410 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 94: /* param_declarator: vPARAMETER vSIGNED  */
#line 899 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
      (yyval.extra_tok).extra[2] = IS_FALSE;
    }
#line 4422 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 95: /* param_declarator: vPARAMETER vINT  */
#line 907 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
      (yyval.extra_tok).extra[2] = IS_FALSE;
    }
#line 4434 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 96: /* param_decl_item: param_declarator expression  */
#line 918 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* expression-list or .arg()-list */
      (yyval.tok) = veri_parser->gen_param_decl( (yyvsp[-1].extra_tok).line, (yyvsp[-1].extra_tok).col, (yyvsp[-1].extra_tok).extra[0],
                                             (yyvsp[-1].extra_tok).extra[1], (yyvsp[-1].extra_tok).extra[2],
                                             NULL, (yyvsp[0].tok) );
    }
#line 4445 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 97: /* param_decl_item: param_declarator range expression  */
#line 925 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* expression-list or .arg()-list */
      (yyval.tok) = veri_parser->gen_param_decl( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, (yyvsp[-2].extra_tok).extra[0],
                                             (yyvsp[-2].extra_tok).extra[1], (yyvsp[-2].extra_tok).extra[2],
                                             (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 4456 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 98: /* param_declaration: param_decl_item ';'  */
#line 935 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 4464 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 99: /* specparam_declaration: vSPEC_PARAM expression ';'  */
#line 942 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // vIDENT = mintypmax-or-range-expression
      // const-mintypmax-expression
    }
#line 4473 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 100: /* specparam_declaration: vSPEC_PARAM specparam_assignment_list ';'  */
#line 947 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // first could be range[a:b]
    }
#line 4481 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 101: /* specparam_declaration: vSPEC_PARAM range expression ';'  */
#line 951 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // vIDENT = mintypmax-or-range-expression
      // const-mintypmax-expression
    }
#line 4490 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 102: /* specparam_declaration: vSPEC_PARAM range specparam_assignment_list ';'  */
#line 956 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // first could be range[a:b]
    }
#line 4498 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 103: /* genvar_declaration: vGENVAR expression ';'  */
#line 965 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // genvar-identifier-list
      (yyval.tok) = veri_parser->gen_genvar_decl( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[-1].tok) );
    }
#line 4507 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 104: /* int_declaration: vINT expression ';'  */
#line 973 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // var-identifier-list -> expression
      (yyval.tok) = veri_parser->gen_int_decl( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[-1].tok) );
    }
#line 4516 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 105: /* net_declaration: net_type expression ';'  */
#line 981 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // { vIDENT + dimension_list } _list
      // or .id() -list
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, vpNO_IO, (yyvsp[-2].extra_tok).extra[0],
                                           IS_FALSE, vpSCALAR, NULL, NULL,
                                           NULL, (yyvsp[-1].tok)  );
    }
#line 4528 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 106: /* net_declaration: net_type net_decl_a expression ';'  */
#line 989 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // { vIDENT + dimension_list } _list
      // or .id() -list
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, vpNO_IO, (yyvsp[-3].extra_tok).extra[0],
                                           (yyvsp[-2].extra_tok).extra[0], (yyvsp[-2].extra_tok).extra[1],
                                           NULL, (yyvsp[-2].extra_tok).node[0],
                                           (yyvsp[-2].extra_tok).node[1], (yyvsp[-1].tok)  );
    }
#line 4541 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 107: /* net_declaration: net_type net_decl_b expression ';'  */
#line 998 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // const-assignment-exp, type-1
      // or .id() -list
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, vpNO_IO, (yyvsp[-3].extra_tok).extra[0],
                                           (yyvsp[-2].extra_tok).extra[0], (yyvsp[-2].extra_tok).extra[1],
                                           (yyvsp[-2].extra_tok).node[2], (yyvsp[-2].extra_tok).node[0],
                                           (yyvsp[-2].extra_tok).node[1], (yyvsp[-1].tok)  );
    }
#line 4554 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 108: /* net_decl_a: range  */
#line 1010 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].tok)->line();
      (yyval.extra_tok).col  = (yyvsp[0].tok)->col();
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = vpSCALAR;
      (yyval.extra_tok).node[0] = (yyvsp[0].tok);
      (yyval.extra_tok).node[1] = NULL;
    }
#line 4567 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 109: /* net_decl_a: vSIGNED  */
#line 1019 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = vpSCALAR;
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = NULL;
    }
#line 4580 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 110: /* net_decl_a: vector_or_scalar  */
#line 1028 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].extra_tok).line;
      (yyval.extra_tok).col  = (yyvsp[0].extra_tok).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = (yyvsp[0].extra_tok).extra[0];
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = NULL;
    }
#line 4593 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 111: /* net_decl_a: delay3  */
#line 1037 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].tok)->line();
      (yyval.extra_tok).col  = (yyvsp[0].tok)->col();
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = vpSCALAR;
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = (yyvsp[0].tok);
    }
#line 4606 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 112: /* net_decl_a: vSIGNED range  */
#line 1046 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = vpSCALAR;
      (yyval.extra_tok).node[0] = (yyvsp[0].tok);
      (yyval.extra_tok).node[1] = NULL;
    }
#line 4619 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 113: /* net_decl_a: vector_or_scalar range  */
#line 1055 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].extra_tok).line;
      (yyval.extra_tok).col  = (yyvsp[-1].extra_tok).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = (yyvsp[-1].extra_tok).extra[0];
      (yyval.extra_tok).node[0] = (yyvsp[0].tok);
      (yyval.extra_tok).node[1] = NULL;
    }
#line 4632 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 114: /* net_decl_a: vSIGNED delay3  */
#line 1064 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = vpSCALAR;
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = (yyvsp[0].tok);
    }
#line 4645 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 115: /* net_decl_a: vector_or_scalar delay3  */
#line 1073 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].extra_tok).line;
      (yyval.extra_tok).col  = (yyvsp[-1].extra_tok).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = (yyvsp[-1].extra_tok).extra[0];
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = (yyvsp[0].tok);
    }
#line 4658 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 116: /* net_decl_a: vSIGNED range delay3  */
#line 1082 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-2].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-2].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = vpSCALAR;
      (yyval.extra_tok).node[0] = (yyvsp[-1].tok);
      (yyval.extra_tok).node[1] = (yyvsp[0].tok);
    }
#line 4671 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 117: /* net_decl_a: vector_or_scalar range delay3  */
#line 1091 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-2].extra_tok).line;
      (yyval.extra_tok).col  = (yyvsp[-2].extra_tok).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = (yyvsp[-2].extra_tok).extra[0];
      (yyval.extra_tok).node[0] = (yyvsp[-1].tok);
      (yyval.extra_tok).node[1] = (yyvsp[0].tok);
    }
#line 4684 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 118: /* net_decl_b: drive_strength  */
#line 1103 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].tok)->line();
      (yyval.extra_tok).col  = (yyvsp[0].tok)->col();
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = vpSCALAR;
      (yyval.extra_tok).node[0] = NULL;
      (yyval.extra_tok).node[1] = NULL;
      (yyval.extra_tok).node[2] = (yyvsp[0].tok);
    }
#line 4698 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 119: /* net_decl_b: drive_strength net_decl_a  */
#line 1113 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].tok)->line();
      (yyval.extra_tok).col  = (yyvsp[-1].tok)->col();
      (yyval.extra_tok).extra[0] = (yyvsp[0].extra_tok).extra[0];
      (yyval.extra_tok).extra[1] = (yyvsp[0].extra_tok).extra[1];
      (yyval.extra_tok).node[0] = (yyvsp[0].extra_tok).node[0];
      (yyval.extra_tok).node[1] = (yyvsp[0].extra_tok).node[1];
      (yyval.extra_tok).node[2] = (yyvsp[-1].tok);
    }
#line 4712 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 120: /* vector_or_scalar: vVECTORED  */
#line 1126 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpVECTOR;
    }
#line 4722 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 121: /* vector_or_scalar: vSCALARED  */
#line 1132 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpSCALAR;
    }
#line 4732 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 122: /* variable_type: vREG  */
#line 1141 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    { (yyval.extra_tok).line = (yyvsp[0].symbol).line; (yyval.extra_tok).col = (yyvsp[0].symbol).col; (yyval.extra_tok).extra[0] = vvREG; }
#line 4738 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 123: /* variable_type: vLOGIC  */
#line 1143 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    { (yyval.extra_tok).line = (yyvsp[0].symbol).line; (yyval.extra_tok).col = (yyvsp[0].symbol).col; (yyval.extra_tok).extra[0] = vvLOGIC; }
#line 4744 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 124: /* variable_type: vBIT  */
#line 1145 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    { (yyval.extra_tok).line = (yyvsp[0].symbol).line; (yyval.extra_tok).col = (yyvsp[0].symbol).col; (yyval.extra_tok).extra[0] = vvBIT; }
#line 4750 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 125: /* variable_type: vBYTE  */
#line 1147 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    { (yyval.extra_tok).line = (yyvsp[0].symbol).line; (yyval.extra_tok).col = (yyvsp[0].symbol).col; (yyval.extra_tok).extra[0] = vvBYTE; }
#line 4756 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 126: /* variable_type: vSHORTINT  */
#line 1149 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    { (yyval.extra_tok).line = (yyvsp[0].symbol).line; (yyval.extra_tok).col = (yyvsp[0].symbol).col; (yyval.extra_tok).extra[0] = vvSHORTINT; }
#line 4762 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 127: /* variable_type: vLONGINT  */
#line 1151 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    { (yyval.extra_tok).line = (yyvsp[0].symbol).line; (yyval.extra_tok).col = (yyvsp[0].symbol).col; (yyval.extra_tok).extra[0] = vvLONGINT; }
#line 4768 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 128: /* reg_declaration: variable_type expression ';'  */
#line 1156 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, vpNO_IO, (yyvsp[-2].extra_tok).extra[0],
                                      IS_FALSE, vpSCALAR, NULL, NULL,
                                      NULL, (yyvsp[-1].tok)  );
    }
#line 4778 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 129: /* reg_declaration: variable_type vSIGNED expression ';'  */
#line 1162 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, vpNO_IO, (yyvsp[-3].extra_tok).extra[0],
                                           IS_TRUE, vpSCALAR, NULL, NULL,
                                           NULL, (yyvsp[-1].tok) );
    }
#line 4788 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 130: /* reg_declaration: variable_type range expression ';'  */
#line 1168 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, vpNO_IO, (yyvsp[-3].extra_tok).extra[0],
                                           IS_FALSE, vpSCALAR, NULL, (yyvsp[-2].tok),
                                           NULL, (yyvsp[-1].tok)  );
    }
#line 4798 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 131: /* reg_declaration: variable_type vSIGNED range expression ';'  */
#line 1174 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-4].extra_tok).line, (yyvsp[-4].extra_tok).col, vpNO_IO, (yyvsp[-4].extra_tok).extra[0],
                                           IS_TRUE, vpSCALAR, NULL, (yyvsp[-2].tok),
                                           NULL, (yyvsp[-1].tok)  );
    }
#line 4808 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 132: /* reg_declaration: variable_type vUNSIGNED expression ';'  */
#line 1180 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, vpNO_IO, (yyvsp[-3].extra_tok).extra[0],
                                           IS_FALSE, vpSCALAR, NULL, NULL,
                                           NULL, (yyvsp[-1].tok) );
    }
#line 4818 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 133: /* reg_declaration: variable_type vUNSIGNED range expression ';'  */
#line 1186 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_var_decl( (yyvsp[-4].extra_tok).line, (yyvsp[-4].extra_tok).col, vpNO_IO, (yyvsp[-4].extra_tok).extra[0],
                                           IS_FALSE, vpSCALAR, NULL, (yyvsp[-2].tok),
                                           NULL, (yyvsp[-1].tok)  );
    }
#line 4828 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 134: /* net_type: vSUPPLY_A  */
#line 1198 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvSUPPLY0;
    }
#line 4838 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 135: /* net_type: vSUPPLY_B  */
#line 1204 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvSUPPLY1;
    }
#line 4848 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 136: /* net_type: vTRI  */
#line 1210 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvTRI;
    }
#line 4858 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 137: /* net_type: vTRIAND  */
#line 1216 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvTRIAND;
    }
#line 4868 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 138: /* net_type: vTRIOR  */
#line 1222 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvTRIOR;
    }
#line 4878 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 139: /* net_type: vWIRE  */
#line 1228 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvWIRE;
    }
#line 4888 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 140: /* net_type: vWAND  */
#line 1234 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvWAND;
    }
#line 4898 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 141: /* net_type: vWOR  */
#line 1240 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvWOR;
    }
#line 4908 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 142: /* drive_strength: '(' strength0 ',' strength1 ')'  */
#line 1250 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_drive_exp( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].extra_tok).extra[0],
                                            (yyvsp[-1].extra_tok).extra[0] );
    }
#line 4917 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 143: /* drive_strength: '(' strength1 ',' strength0 ')'  */
#line 1255 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_drive_exp( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].extra_tok).extra[0],
                                            (yyvsp[-1].extra_tok).extra[0] );
    }
#line 4926 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 144: /* drive_strength: '(' strength0 ',' vHIGHZ_A ')'  */
#line 1260 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_drive_exp( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].extra_tok).extra[0],
                                            vpHIGHZ0 );
    }
#line 4935 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 145: /* drive_strength: '(' strength1 ',' vHIGHZ_B ')'  */
#line 1265 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_drive_exp( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].extra_tok).extra[0],
                                            vpHIGHZ1 );
    }
#line 4944 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 146: /* drive_strength: '(' vHIGHZ_A ',' strength1 ')'  */
#line 1270 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_drive_exp( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, vpHIGHZ0,
                                            (yyvsp[-1].extra_tok).extra[0] );
    }
#line 4953 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 147: /* drive_strength: '(' vHIGHZ_B ',' strength0 ')'  */
#line 1275 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_drive_exp( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, vpHIGHZ1,
                                            (yyvsp[-1].extra_tok).extra[0] );
    }
#line 4962 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 148: /* strength0: vSUPPLY_A  */
#line 1283 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpSUPPLY0;
    }
#line 4972 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 149: /* strength0: vSTRONG_A  */
#line 1289 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpSTRONG0;
    }
#line 4982 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 150: /* strength0: vPULL_A  */
#line 1295 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpPULL0;
    }
#line 4992 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 151: /* strength0: vWEAK_A  */
#line 1301 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpWEAK0;
    }
#line 5002 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 152: /* strength1: vSUPPLY_B  */
#line 1310 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpSUPPLY1;
    }
#line 5012 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 153: /* strength1: vSTRONG_B  */
#line 1316 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpSTRONG1;
    }
#line 5022 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 154: /* strength1: vPULL_B  */
#line 1322 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpPULL1;
    }
#line 5032 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 155: /* strength1: vWEAK_B  */
#line 1328 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpWEAK1;
    }
#line 5042 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 156: /* delay3: '#' expression  */
#line 1338 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_delay_exp( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok), NULL );
    }
#line 5050 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 157: /* delay3: '#' '(' expression ',' expression ')'  */
#line 1342 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_delay_exp( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 5058 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 158: /* specparam_assignment_list: specparam_assignment  */
#line 1350 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 5065 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 159: /* specparam_assignment_list: specparam_assignment_list ',' specparam_assignment  */
#line 1353 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 5072 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 160: /* specparam_assignment: vPATHPULSE ';'  */
#line 1360 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 5079 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 161: /* func_declaration: vFUNC vIDENT ';' func_item_decl_list func_statement vENDFUNC  */
#line 1369 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // expression is id
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, IS_FALSE, 
                                  IS_FALSE, IS_FALSE, NULL, (yyvsp[-4].symbol).content,
                                  NULL, (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free( (yyvsp[-4].symbol).content );
    }
#line 5091 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 162: /* func_declaration: vFUNC vIDENT '(' func_port_list ')' ';' func_statement vENDFUNC  */
#line 1378 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // ANSI-style function port list with no separate item declarations.
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-7].symbol).line, (yyvsp[-7].symbol).col, IS_FALSE,
                                  IS_FALSE, IS_FALSE, NULL, (yyvsp[-6].symbol).content,
                                  (yyvsp[-4].tok), NULL, (yyvsp[-1].tok) );
      free( (yyvsp[-6].symbol).content );
    }
#line 5103 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 163: /* func_declaration: vFUNC vIDENT '(' func_port_list ')' ';' block_item_decl_list func_statement vENDFUNC  */
#line 1387 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // expression is id
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-8].symbol).line, (yyvsp[-8].symbol).col, IS_FALSE,
                                  IS_FALSE, IS_FALSE, NULL, (yyvsp[-7].symbol).content,
                                  (yyvsp[-5].tok), (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free( (yyvsp[-7].symbol).content );
    }
#line 5115 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 164: /* func_declaration: vFUNC range vIDENT ';' func_item_decl_list func_statement vENDFUNC  */
#line 1396 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // last exp is id
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, IS_FALSE,
                                  IS_FALSE, IS_FALSE, (yyvsp[-5].tok), (yyvsp[-4].symbol).content,
                                  NULL, (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free( (yyvsp[-4].symbol).content );
    }
#line 5127 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 165: /* func_declaration: vFUNC range vIDENT '(' func_port_list ')' ';' func_statement vENDFUNC  */
#line 1405 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // ANSI-style function port list with no separate item declarations.
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-8].symbol).line, (yyvsp[-8].symbol).col, IS_FALSE,
                                  IS_FALSE, IS_FALSE, (yyvsp[-7].tok), (yyvsp[-6].symbol).content,
                                  (yyvsp[-4].tok), NULL, (yyvsp[-1].tok) );
      free( (yyvsp[-6].symbol).content );
    }
#line 5139 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 166: /* func_declaration: vFUNC range vIDENT '(' func_port_list ')' ';' block_item_decl_list func_statement vENDFUNC  */
#line 1414 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // last exp is id
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-9].symbol).line, (yyvsp[-9].symbol).col, IS_FALSE,
                                  IS_FALSE, IS_FALSE, (yyvsp[-8].tok), (yyvsp[-7].symbol).content,
                                  (yyvsp[-5].tok), (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free( (yyvsp[-7].symbol).content );
    }
#line 5151 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 167: /* func_declaration: vFUNC func_declarator vIDENT ';' func_item_decl_list func_statement vENDFUNC  */
#line 1423 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // expression is id
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, (yyvsp[-5].extra_tok).extra[0],
                                  (yyvsp[-5].extra_tok).extra[1], (yyvsp[-5].extra_tok).extra[2], NULL, (yyvsp[-4].symbol).content,
                                  NULL, (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free( (yyvsp[-4].symbol).content );
    }
#line 5163 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 168: /* func_declaration: vFUNC func_declarator vIDENT '(' func_port_list ')' ';' func_statement vENDFUNC  */
#line 1432 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // ANSI-style function port list with no separate item declarations.
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-8].symbol).line, (yyvsp[-8].symbol).col, (yyvsp[-7].extra_tok).extra[0],
                                  (yyvsp[-7].extra_tok).extra[1], (yyvsp[-7].extra_tok).extra[2], NULL, (yyvsp[-6].symbol).content,
                                  (yyvsp[-4].tok), NULL, (yyvsp[-1].tok) );
      free( (yyvsp[-6].symbol).content );
    }
#line 5175 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 169: /* func_declaration: vFUNC func_declarator vIDENT '(' func_port_list ')' ';' block_item_decl_list func_statement vENDFUNC  */
#line 1441 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // expression is id
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-9].symbol).line, (yyvsp[-9].symbol).col, (yyvsp[-8].extra_tok).extra[0],
                                  (yyvsp[-8].extra_tok).extra[1], (yyvsp[-8].extra_tok).extra[2], NULL, (yyvsp[-7].symbol).content,
                                  (yyvsp[-5].tok), (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free( (yyvsp[-7].symbol).content );
    }
#line 5187 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 170: /* func_declaration: vFUNC func_declarator range vIDENT ';' func_item_decl_list func_statement vENDFUNC  */
#line 1450 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // last exp is id
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-7].symbol).line, (yyvsp[-7].symbol).col, (yyvsp[-6].extra_tok).extra[0],
                                  (yyvsp[-6].extra_tok).extra[1], (yyvsp[-6].extra_tok).extra[2], (yyvsp[-5].tok), (yyvsp[-4].symbol).content,
                                  NULL, (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free( (yyvsp[-4].symbol).content );
    }
#line 5199 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 171: /* func_declaration: vFUNC func_declarator range vIDENT '(' func_port_list ')' ';' func_statement vENDFUNC  */
#line 1459 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // ANSI-style function port list with no separate item declarations.
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-9].symbol).line, (yyvsp[-9].symbol).col, (yyvsp[-8].extra_tok).extra[0],
                                  (yyvsp[-8].extra_tok).extra[1], (yyvsp[-8].extra_tok).extra[2], (yyvsp[-7].tok), (yyvsp[-6].symbol).content,
                                  (yyvsp[-4].tok), NULL, (yyvsp[-1].tok) );
      free( (yyvsp[-6].symbol).content );
    }
#line 5211 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 172: /* func_declaration: vFUNC func_declarator range vIDENT '(' func_port_list ')' ';' block_item_decl_list func_statement vENDFUNC  */
#line 1468 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // last exp is id
      (yyval.tok) = veri_parser->gen_func_decl( (yyvsp[-10].symbol).line, (yyvsp[-10].symbol).col, (yyvsp[-9].extra_tok).extra[0],
                                  (yyvsp[-9].extra_tok).extra[1], (yyvsp[-9].extra_tok).extra[2], (yyvsp[-8].tok), (yyvsp[-7].symbol).content,
                                  (yyvsp[-5].tok), (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free( (yyvsp[-7].symbol).content );
    }
#line 5223 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 173: /* func_declarator: vINT  */
#line 1479 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
      (yyval.extra_tok).extra[2] = IS_TRUE;
    }
#line 5235 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 174: /* func_declarator: vSIGNED  */
#line 1487 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
      (yyval.extra_tok).extra[2] = IS_FALSE;
    }
#line 5247 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 175: /* func_declarator: vSIGNED vINT  */
#line 1495 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_FALSE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
      (yyval.extra_tok).extra[2] = IS_TRUE;
    }
#line 5259 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 176: /* func_declarator: vAUTO  */
#line 1503 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
      (yyval.extra_tok).extra[2] = IS_FALSE;
    }
#line 5271 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 177: /* func_declarator: vAUTO vINT  */
#line 1511 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = IS_FALSE;
      (yyval.extra_tok).extra[2] = IS_TRUE;
    }
#line 5283 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 178: /* func_declarator: vAUTO vSIGNED  */
#line 1519 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
      (yyval.extra_tok).extra[2] = IS_FALSE;
    }
#line 5295 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 179: /* func_declarator: vAUTO vSIGNED vINT  */
#line 1527 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-2].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-2].symbol).col;
      (yyval.extra_tok).extra[0] = IS_TRUE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
      (yyval.extra_tok).extra[2] = IS_TRUE;
    }
#line 5307 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 180: /* func_item_decl_list: func_item_declaration  */
#line 1538 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_item_list( (yyvsp[0].tok) );
    }
#line 5315 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 181: /* func_item_decl_list: func_item_decl_list func_item_declaration  */
#line 1542 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_func_item_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 5323 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 182: /* block_item_decl_list: block_item_declaration  */
#line 1549 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_block_item_list( (yyvsp[0].tok) );
    }
#line 5331 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 183: /* block_item_decl_list: block_item_decl_list block_item_declaration  */
#line 1553 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_block_item_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 5339 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 184: /* func_item_declaration: block_item_declaration  */
#line 1560 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5347 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 185: /* func_item_declaration: tf_declaration ';'  */
#line 1564 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 5355 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 186: /* func_port_list: tf_declaration  */
#line 1571 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_fp_list( (yyvsp[0].tok) );
    }
#line 5363 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 187: /* func_port_list: func_port_list vPORT_DELIM tf_declaration  */
#line 1575 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_fp_list( (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 5371 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 188: /* task_declaration: vTASK vIDENT ';' statement vENDTASK  */
#line 1583 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_decl( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, IS_FALSE,
                                  (yyvsp[-3].symbol).content, NULL, NULL, (yyvsp[-1].tok) );
      free((yyvsp[-3].symbol).content);
    }
#line 5381 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 189: /* task_declaration: vTASK vIDENT ';' task_item_decl_list statement vENDTASK  */
#line 1589 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_decl( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, IS_FALSE,
                                  (yyvsp[-4].symbol).content, NULL, (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free((yyvsp[-4].symbol).content);
    }
#line 5391 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 190: /* task_declaration: vTASK vAUTO vIDENT ';' statement vENDTASK  */
#line 1595 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_decl( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, IS_TRUE,
                                  (yyvsp[-3].symbol).content, NULL, NULL, (yyvsp[-1].tok) );
      free((yyvsp[-3].symbol).content);
    }
#line 5401 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 191: /* task_declaration: vTASK vAUTO vIDENT ';' task_item_decl_list statement vENDTASK  */
#line 1601 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_decl( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, IS_TRUE,
                                  (yyvsp[-4].symbol).content, NULL, (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free((yyvsp[-4].symbol).content);
    }
#line 5411 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 192: /* task_declaration: vTASK vIDENT '(' task_port_list ')' ';' statement vENDTASK  */
#line 1607 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_decl( (yyvsp[-7].symbol).line, (yyvsp[-7].symbol).col, IS_FALSE,
                                  (yyvsp[-6].symbol).content, (yyvsp[-4].tok), NULL, (yyvsp[-1].tok) );
      free((yyvsp[-6].symbol).content);
    }
#line 5421 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 193: /* task_declaration: vTASK vIDENT '(' task_port_list ')' ';' block_item_decl_list statement vENDTASK  */
#line 1614 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_decl( (yyvsp[-8].symbol).line, (yyvsp[-8].symbol).col, IS_FALSE,
                                  (yyvsp[-7].symbol).content, (yyvsp[-5].tok), (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free((yyvsp[-7].symbol).content);
    }
#line 5431 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 194: /* task_declaration: vTASK vAUTO vIDENT '(' task_port_list ')' ';' statement vENDTASK  */
#line 1621 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_decl( (yyvsp[-8].symbol).line, (yyvsp[-8].symbol).col, IS_TRUE,
                                  (yyvsp[-6].symbol).content, (yyvsp[-4].tok), NULL, (yyvsp[-1].tok) );
      free((yyvsp[-6].symbol).content);
    }
#line 5441 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 195: /* task_declaration: vTASK vAUTO vIDENT '(' task_port_list ')' ';' block_item_decl_list statement vENDTASK  */
#line 1628 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_decl( (yyvsp[-9].symbol).line, (yyvsp[-9].symbol).col, IS_TRUE,
                                  (yyvsp[-7].symbol).content, (yyvsp[-5].tok), (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free((yyvsp[-7].symbol).content);
    }
#line 5451 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 196: /* task_item_decl_list: task_item_declaration  */
#line 1637 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_task_item_list( (yyvsp[0].tok) );
    }
#line 5459 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 197: /* task_item_decl_list: task_item_decl_list task_item_declaration  */
#line 1641 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_task_item_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 5467 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 198: /* task_item_declaration: block_item_declaration  */
#line 1648 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5475 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 199: /* task_item_declaration: tf_declaration  */
#line 1652 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5483 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 200: /* task_port_list: tf_declaration  */
#line 1659 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_tp_list( (yyvsp[0].tok) );
    }
#line 5491 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 201: /* task_port_list: task_port_list vPORT_DELIM tf_declaration  */
#line 1663 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_tp_list( (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 5499 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 202: /* tf_port_declarator: vSIGNED  */
#line 1670 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvWIRE;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 5510 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 203: /* tf_port_declarator: vREG  */
#line 1677 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvREG;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 5521 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 204: /* tf_port_declarator: vREG vSIGNED  */
#line 1684 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[-1].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[-1].symbol).col;
      (yyval.extra_tok).extra[0] = vvREG;
      (yyval.extra_tok).extra[1] = IS_TRUE;
    }
#line 5532 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 205: /* tf_port_declarator: vINT  */
#line 1691 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col  = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vvINT;
      (yyval.extra_tok).extra[1] = IS_FALSE;
    }
#line 5543 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 206: /* tf_declaration: in_or_out expression  */
#line 1701 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // port-identifier-list
      (yyval.tok) = veri_parser->gen_tf_declaration( (yyvsp[-1].extra_tok).line, (yyvsp[-1].extra_tok).col, (yyvsp[-1].extra_tok).extra[0],
                                           vvWIRE, IS_FALSE, NULL, (yyvsp[0].tok) );
    }
#line 5553 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 207: /* tf_declaration: in_or_out tf_port_declarator expression  */
#line 1707 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // port-identifier-list
      (yyval.tok) = veri_parser->gen_tf_declaration( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, (yyvsp[-2].extra_tok).extra[0],
                                           (yyvsp[-1].extra_tok).extra[0], (yyvsp[-1].extra_tok).extra[1], NULL,
                                           (yyvsp[0].tok) );
    }
#line 5564 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 208: /* tf_declaration: attr_inst_list in_or_out expression  */
#line 1714 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // port-identifier-list
      (yyval.tok) = veri_parser->gen_tf_declaration( (yyvsp[-1].extra_tok).line, (yyvsp[-1].extra_tok).col, (yyvsp[-1].extra_tok).extra[0],
                                           vvWIRE, IS_FALSE, NULL, (yyvsp[0].tok) );
    }
#line 5574 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 209: /* tf_declaration: attr_inst_list in_or_out tf_port_declarator expression  */
#line 1720 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // port-identifier-list
      (yyval.tok) = veri_parser->gen_tf_declaration( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, (yyvsp[-2].extra_tok).extra[0],
                                           (yyvsp[-1].extra_tok).extra[0], (yyvsp[-1].extra_tok).extra[1], NULL,
                                           (yyvsp[0].tok) );
    }
#line 5585 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 210: /* tf_declaration: in_or_out range expression  */
#line 1727 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // port-identifier-list
      (yyval.tok) = veri_parser->gen_tf_declaration( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, (yyvsp[-2].extra_tok).extra[0],
                                           vvWIRE, IS_FALSE, (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 5595 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 211: /* tf_declaration: in_or_out tf_port_declarator range expression  */
#line 1733 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // port-identifier-list
      (yyval.tok) = veri_parser->gen_tf_declaration( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, (yyvsp[-3].extra_tok).extra[0],
                                           (yyvsp[-2].extra_tok).extra[0], (yyvsp[-2].extra_tok).extra[1], (yyvsp[-1].tok),
                                           (yyvsp[0].tok) );
    }
#line 5606 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 212: /* tf_declaration: attr_inst_list in_or_out range expression  */
#line 1740 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // port-identifier-list
      (yyval.tok) = veri_parser->gen_tf_declaration( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col, (yyvsp[-2].extra_tok).extra[0],
                                           vvWIRE, IS_FALSE, (yyvsp[-1].tok),
                                           (yyvsp[0].tok) );
    }
#line 5617 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 213: /* tf_declaration: attr_inst_list in_or_out tf_port_declarator range expression  */
#line 1747 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // port-identifier-list
      (yyval.tok) = veri_parser->gen_tf_declaration( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col, (yyvsp[-3].extra_tok).extra[0],
                                           (yyvsp[-2].extra_tok).extra[0], (yyvsp[-2].extra_tok).extra[1], (yyvsp[-1].tok),
                                           (yyvsp[0].tok) );
    }
#line 5628 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 214: /* block_item_declaration: reg_declaration  */
#line 1758 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5636 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 215: /* block_item_declaration: int_declaration  */
#line 1762 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5644 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 216: /* block_item_declaration: param_declaration  */
#line 1766 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5652 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 217: /* block_item_declaration: attr_inst_list reg_declaration  */
#line 1770 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5660 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 218: /* block_item_declaration: attr_inst_list param_declaration  */
#line 1775 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5668 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 219: /* block_item_declaration: attr_inst_list int_declaration  */
#line 1779 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5676 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 220: /* gate_instantiation: gatetype expression ';'  */
#line 1795 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gate_instantiation( (yyvsp[-2].extra_tok).line, (yyvsp[-2].extra_tok).col,
                               (yyvsp[-2].extra_tok).extra[0], NULL, NULL, (yyvsp[-1].tok) );
    }
#line 5685 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 221: /* gate_instantiation: gatetype drive_strength expression ';'  */
#line 1800 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gate_instantiation( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col,
                               (yyvsp[-3].extra_tok).extra[0], (yyvsp[-2].tok), NULL, (yyvsp[-1].tok) );
    }
#line 5694 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 222: /* gate_instantiation: gatetype delay3 expression ';'  */
#line 1805 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gate_instantiation( (yyvsp[-3].extra_tok).line, (yyvsp[-3].extra_tok).col,
                               (yyvsp[-3].extra_tok).extra[0], NULL, (yyvsp[-2].tok), (yyvsp[-1].tok) );
    }
#line 5703 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 223: /* gate_instantiation: gatetype drive_strength delay3 expression ';'  */
#line 1810 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gate_instantiation( (yyvsp[-4].extra_tok).line, (yyvsp[-4].extra_tok).col,
                               (yyvsp[-4].extra_tok).extra[0], (yyvsp[-3].tok), (yyvsp[-2].tok), (yyvsp[-1].tok) );
    }
#line 5712 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 224: /* gatetype: vBUFIF_A  */
#line 1822 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpBUFFIF0;
    }
#line 5722 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 225: /* gatetype: vBUFIF_B  */
#line 1828 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpBUFFIF1;
    }
#line 5732 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 226: /* gatetype: vNOTIF_A  */
#line 1834 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpNOTIF0;
    }
#line 5742 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 227: /* gatetype: vNOTIF_B  */
#line 1840 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpNOTIF1;
    }
#line 5752 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 228: /* gatetype: vAND_ASCII  */
#line 1846 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpAND;
    }
#line 5762 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 229: /* gatetype: vNAND_ASCII  */
#line 1852 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpNAND;
    }
#line 5772 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 230: /* gatetype: vOR_ASCII  */
#line 1858 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpOR;
    }
#line 5782 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 231: /* gatetype: vNOR_ASCII  */
#line 1864 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpNOR;
    }
#line 5792 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 232: /* gatetype: vXOR_ASCII  */
#line 1870 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpXOR;
    }
#line 5802 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 233: /* gatetype: vXNOR_ASCII  */
#line 1876 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpXNOR;
    }
#line 5812 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 234: /* gatetype: vBUF_ASCII  */
#line 1882 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpBUF;
    }
#line 5822 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 235: /* gatetype: vNOT_ASCII  */
#line 1888 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.extra_tok).line  = (yyvsp[0].symbol).line;
      (yyval.extra_tok).col   = (yyvsp[0].symbol).col;
      (yyval.extra_tok).extra[0] = vpNOT;
    }
#line 5832 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 236: /* module_instantiation: vIDENT expression ';'  */
#line 1901 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_mod_instantiation( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col,
                                   (yyvsp[-2].symbol).content, NULL, (yyvsp[-1].tok) );
      free((yyvsp[-2].symbol).content);
    }
#line 5842 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 237: /* module_instantiation: vIDENT '#' '(' expression ')' expression ';'  */
#line 1907 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* second is param-val-assignment */
      /* third is module-instance-list */
      (yyval.tok) = veri_parser->gen_mod_instantiation( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col,
                                   (yyvsp[-6].symbol).content, (yyvsp[-3].tok), (yyvsp[-1].tok) );
      free((yyvsp[-6].symbol).content);
    }
#line 5854 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 238: /* generated_instantiation: vGEN vENDGEN  */
#line 1919 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_dummy_inst( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col );
    }
#line 5862 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 239: /* generated_instantiation: vGEN gen_item_list vENDGEN  */
#line 1923 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 5870 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 240: /* gen_item_list: gen_item  */
#line 1930 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gen_item_list( (yyvsp[0].tok) );
    }
#line 5878 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 241: /* gen_item_list: gen_item_list gen_item  */
#line 1934 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_gen_item_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 5886 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 242: /* gen_item_or_null: gen_item  */
#line 1941 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5894 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 243: /* gen_item_or_null: ';'  */
#line 1945 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_dummy_inst( (yyvsp[0].symbol).line, (yyvsp[0].symbol).col );
    }
#line 5902 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 244: /* gen_item: gen_cond_statement  */
#line 1952 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5910 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 245: /* gen_item: vIF '(' expression ')' continuous_assign  */
#line 1956 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* generate if with single continuous assign (no begin/end) */
      (yyval.tok) = veri_parser->gen_gen_cond_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].tok), (yyvsp[0].tok), NULL );
    }
#line 5919 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 246: /* gen_item: vIF '(' expression ')' continuous_assign vELSE continuous_assign  */
#line 1961 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* generate if-else with continuous assign */
      (yyval.tok) = veri_parser->gen_gen_cond_stmt( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, (yyvsp[-4].tok), (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 5928 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 247: /* gen_item: gen_case_statement  */
#line 1966 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5936 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 248: /* gen_item: gen_loop_statement  */
#line 1970 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5944 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 249: /* gen_item: gen_block  */
#line 1974 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5952 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 250: /* gen_item: module_or_gen_item  */
#line 1978 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 5960 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 251: /* gen_cond_statement: vIF '(' expression ')' gen_item_or_null  */
#line 1985 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // const-expression
      // 1 expression only
      (yyval.tok) = veri_parser->gen_gen_cond_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].tok),
                                                (yyvsp[0].tok), NULL );
    }
#line 5971 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 252: /* gen_cond_statement: vIF '(' expression ')' gen_item_or_null vELSE gen_item_or_null  */
#line 1992 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // const-expression
      // 1 expression only
      (yyval.tok) = veri_parser->gen_gen_cond_stmt( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, (yyvsp[-4].tok),
                                                (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 5982 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 253: /* gen_case_statement: vCASE '(' expression ')' genvar_case_item_list vENDCASE  */
#line 2002 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // const-expression
      // 1 expression only
      (yyval.tok) = veri_parser->gen_gen_case_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, 
                                                (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 5993 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 254: /* genvar_case_item_list: genvar_case_item  */
#line 2012 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gen_case_item_list( (yyvsp[0].tok) );
    }
#line 6001 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 255: /* genvar_case_item_list: genvar_case_item_list genvar_case_item  */
#line 2016 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_gen_case_item_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 6009 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 256: /* genvar_case_item: expression ':' gen_item_or_null  */
#line 2023 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // const-exp-list
      (yyval.tok) = veri_parser->gen_gen_case_item( (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 6018 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 257: /* genvar_case_item: vDEFAULT gen_item_or_null  */
#line 2028 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_default_gen_case_item( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col,
                                                        (yyvsp[0].tok) );
    }
#line 6027 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 258: /* genvar_case_item: vDEFAULT ':' gen_item_or_null  */
#line 2033 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_default_gen_case_item( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col,
                                                        (yyvsp[0].tok) );
    }
#line 6036 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 259: /* gen_loop_statement: vFOR '(' expression ';' expression ';' expression ')' vBEGIN ':' vIDENT vEND  */
#line 2042 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // const-expression
      // 1 expression only
      (yyval.tok) = veri_parser->gen_gen_loop_stmt( (yyvsp[-11].symbol).line, (yyvsp[-11].symbol).col, (yyvsp[-9].tok), (yyvsp[-7].tok),
                                (yyvsp[-5].tok), (yyvsp[-1].symbol).content, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, NULL );
      free((yyvsp[-1].symbol).content);
    }
#line 6048 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 260: /* gen_loop_statement: vFOR '(' expression ';' expression ';' expression ')' vBEGIN ':' vIDENT gen_item_list vEND  */
#line 2051 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // const-expression
      // 1 expression only
      (yyval.tok) = veri_parser->gen_gen_loop_stmt( (yyvsp[-12].symbol).line, (yyvsp[-12].symbol).col, (yyvsp[-10].tok), (yyvsp[-8].tok),
                                (yyvsp[-6].tok), (yyvsp[-2].symbol).content, (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[-1].tok) );
      free((yyvsp[-2].symbol).content);
    }
#line 6060 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 261: /* gen_loop_statement: vFOR '(' expression ';' expression ';' expression ')' vBEGIN vEND  */
#line 2060 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gen_loop_stmt( (yyvsp[-9].symbol).line, (yyvsp[-9].symbol).col, (yyvsp[-7].tok), (yyvsp[-5].tok),
                                (yyvsp[-3].tok), NULL, -1, -1, NULL );
    }
#line 6069 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 262: /* gen_loop_statement: vFOR '(' expression ';' expression ';' expression ')' vBEGIN gen_item_list vEND  */
#line 2066 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gen_loop_stmt( (yyvsp[-10].symbol).line, (yyvsp[-10].symbol).col, (yyvsp[-8].tok), (yyvsp[-6].tok),
                                (yyvsp[-4].tok), NULL, -1, -1, (yyvsp[-1].tok) );
    }
#line 6078 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 263: /* gen_loop_statement: vFOR '(' vGENVAR vIDENT '=' expression ';' expression ';' expression ')' vBEGIN ':' vIDENT vEND  */
#line 2072 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* build: genvar_i = init_expr as assignment */
      VeriNode * init_assign = veri_parser->gen_binary(
        veri_parser->gen_primary( (yyvsp[-11].symbol).content, (yyvsp[-11].symbol).line, (yyvsp[-11].symbol).col, veVAR ),
        vtASSIGN, (yyvsp[-10].symbol).line, (yyvsp[-10].symbol).col, (yyvsp[-9].tok) );
      (yyval.tok) = veri_parser->gen_gen_loop_stmt( (yyvsp[-14].symbol).line, (yyvsp[-14].symbol).col, init_assign, (yyvsp[-7].tok),
                                (yyvsp[-5].tok), (yyvsp[-1].symbol).content, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, NULL );
      free((yyvsp[-1].symbol).content);
    }
#line 6092 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 264: /* gen_loop_statement: vFOR '(' vGENVAR vIDENT '=' expression ';' expression ';' expression ')' vBEGIN ':' vIDENT gen_item_list vEND  */
#line 2083 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      VeriNode * init_assign = veri_parser->gen_binary(
        veri_parser->gen_primary( (yyvsp[-12].symbol).content, (yyvsp[-12].symbol).line, (yyvsp[-12].symbol).col, veVAR ),
        vtASSIGN, (yyvsp[-11].symbol).line, (yyvsp[-11].symbol).col, (yyvsp[-10].tok) );
      (yyval.tok) = veri_parser->gen_gen_loop_stmt( (yyvsp[-15].symbol).line, (yyvsp[-15].symbol).col, init_assign, (yyvsp[-8].tok),
                                (yyvsp[-6].tok), (yyvsp[-2].symbol).content, (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[-1].tok) );
      free((yyvsp[-2].symbol).content);
    }
#line 6105 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 265: /* gen_loop_statement: vFOR '(' vGENVAR vIDENT '=' expression ';' expression ';' expression ')' vBEGIN vEND  */
#line 2093 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      VeriNode * init_assign = veri_parser->gen_binary(
        veri_parser->gen_primary( (yyvsp[-9].symbol).content, (yyvsp[-9].symbol).line, (yyvsp[-9].symbol).col, veVAR ),
        vtASSIGN, (yyvsp[-8].symbol).line, (yyvsp[-8].symbol).col, (yyvsp[-7].tok) );
      (yyval.tok) = veri_parser->gen_gen_loop_stmt( (yyvsp[-12].symbol).line, (yyvsp[-12].symbol).col, init_assign, (yyvsp[-5].tok),
                                (yyvsp[-3].tok), NULL, -1, -1, NULL );
    }
#line 6117 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 266: /* gen_loop_statement: vFOR '(' vGENVAR vIDENT '=' expression ';' expression ';' expression ')' vBEGIN gen_item_list vEND  */
#line 2102 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      VeriNode * init_assign = veri_parser->gen_binary(
        veri_parser->gen_primary( (yyvsp[-10].symbol).content, (yyvsp[-10].symbol).line, (yyvsp[-10].symbol).col, veVAR ),
        vtASSIGN, (yyvsp[-9].symbol).line, (yyvsp[-9].symbol).col, (yyvsp[-8].tok) );
      (yyval.tok) = veri_parser->gen_gen_loop_stmt( (yyvsp[-13].symbol).line, (yyvsp[-13].symbol).col, init_assign, (yyvsp[-6].tok),
                                (yyvsp[-4].tok), NULL, -1, -1, (yyvsp[-1].tok) );
    }
#line 6129 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 267: /* gen_block: vBEGIN vEND  */
#line 2113 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gen_block_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, NULL, -1, -1,
                                            NULL );
    }
#line 6138 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 268: /* gen_block: vBEGIN gen_item_list vEND  */
#line 2118 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gen_block_stmt( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, NULL, -1, -1,
                                            (yyvsp[-1].tok) );
    }
#line 6147 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 269: /* gen_block: vBEGIN ':' vIDENT vEND  */
#line 2123 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gen_block_stmt( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-1].symbol).content,
                                            (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, NULL );
      free((yyvsp[-1].symbol).content);
    }
#line 6157 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 270: /* gen_block: vBEGIN ':' vIDENT gen_item_list vEND  */
#line 2129 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_gen_block_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].symbol).content,
                                            (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[-1].tok) );
      free((yyvsp[-2].symbol).content);
    }
#line 6167 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 271: /* udp_declaration: vPRIMITIVE vENDPRI  */
#line 2140 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 6174 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 272: /* udp_declaration: attr_inst_list vPRIMITIVE vENDPRI  */
#line 2143 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 6181 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 273: /* continuous_assign: vASSIGN expression ';'  */
#line 2156 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_continuous_assign_stmt( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col,
                                    NULL, NULL, (yyvsp[-1].tok) );
    }
#line 6190 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 274: /* continuous_assign: vASSIGN drive_strength expression ';'  */
#line 2161 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_continuous_assign_stmt( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col,
                                    NULL, (yyvsp[-2].tok), (yyvsp[-1].tok) );
    }
#line 6199 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 275: /* continuous_assign: vASSIGN delay3 expression ';'  */
#line 2166 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_continuous_assign_stmt( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col,
                                    (yyvsp[-2].tok), NULL, (yyvsp[-1].tok) );
    }
#line 6208 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 276: /* continuous_assign: vASSIGN drive_strength delay3 expression ';'  */
#line 2171 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_continuous_assign_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col,
                                    (yyvsp[-3].tok), (yyvsp[-2].tok), (yyvsp[-1].tok) );
    }
#line 6217 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 277: /* blocking_assignment: expression '=' event_control expression  */
#line 2180 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_blocking_stmt( (yyvsp[-3].tok), (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 6226 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 278: /* blocking_assignment: expression '=' expression  */
#line 2185 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // blocking assignment without timing control
      (yyval.tok) = veri_parser->gen_blocking_stmt( (yyvsp[-2].tok), NULL, (yyvsp[0].tok) );
    }
#line 6235 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 279: /* nonblocking_assignment: expression vLE event_control expression  */
#line 2193 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_non_blocking_stmt( (yyvsp[-3].tok), (yyvsp[-1].tok), (yyvsp[0].tok));
    }
#line 6244 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 280: /* nonblocking_assignment: expression vLE expression  */
#line 2198 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // nonblocking assignment without timing control
      (yyval.tok) = veri_parser->gen_non_blocking_stmt( (yyvsp[-2].tok), NULL, (yyvsp[0].tok) );
    }
#line 6253 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 281: /* func_stmt_or_null: func_statement  */
#line 2206 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6261 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 282: /* func_stmt_or_null: ';'  */
#line 2210 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_dummy_stmt( (yyvsp[0].symbol).line, (yyvsp[0].symbol).col );
    }
#line 6269 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 283: /* func_seq_block: vBEGIN vEND  */
#line 2218 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_seq_block_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, NULL,
                                                 -1, -1, NULL, NULL );
    }
#line 6278 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 284: /* func_seq_block: vBEGIN func_stmt_list vEND  */
#line 2223 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_seq_block_stmt( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, NULL,
                                                 -1, -1, NULL, (yyvsp[-1].tok) );
    }
#line 6287 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 285: /* func_seq_block: vBEGIN ':' vIDENT vEND  */
#line 2228 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_seq_block_stmt( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-1].symbol).content,
                                                 (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, NULL, NULL );
      free((yyvsp[-1].symbol).content);
    }
#line 6297 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 286: /* func_seq_block: vBEGIN ':' vIDENT func_stmt_list vEND  */
#line 2234 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_seq_block_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].symbol).content,
                                                 (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, NULL, (yyvsp[-1].tok) );
      free((yyvsp[-2].symbol).content);
    }
#line 6307 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 287: /* func_seq_block: vBEGIN ':' vIDENT block_item_decl_list vEND  */
#line 2240 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_seq_block_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].symbol).content,
                                                 (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[-1].tok), NULL );
      free((yyvsp[-2].symbol).content);
    }
#line 6317 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 288: /* func_seq_block: vBEGIN ':' vIDENT block_item_decl_list func_stmt_list vEND  */
#line 2246 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_seq_block_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, (yyvsp[-3].symbol).content,
                                                 (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free((yyvsp[-3].symbol).content);
    }
#line 6327 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 289: /* func_stmt_list: func_statement  */
#line 2255 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_stmt_list( (yyvsp[0].tok) );
    }
#line 6335 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 290: /* func_stmt_list: func_stmt_list func_statement  */
#line 2259 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_func_stmt_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 6343 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 291: /* stmt_list: statement  */
#line 2266 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_stmt_list( (yyvsp[0].tok) );
    }
#line 6351 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 292: /* stmt_list: stmt_list statement  */
#line 2270 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_stmt_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 6359 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 293: /* seq_block: vBEGIN vEND  */
#line 2277 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_seq_block_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, NULL,
                                            -1, -1, NULL, NULL );
    }
#line 6368 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 294: /* seq_block: vBEGIN stmt_list vEND  */
#line 2282 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_seq_block_stmt( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, NULL,
                                            -1, -1, NULL, (yyvsp[-1].tok) );
    }
#line 6377 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 295: /* seq_block: vBEGIN ':' vIDENT vEND  */
#line 2287 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_seq_block_stmt( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-1].symbol).content,
                                            (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, NULL, NULL );
      free((yyvsp[-1].symbol).content);
    }
#line 6387 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 296: /* seq_block: vBEGIN ':' vIDENT stmt_list vEND  */
#line 2293 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_seq_block_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].symbol).content,
                                            (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, NULL, (yyvsp[-1].tok) );
      free((yyvsp[-2].symbol).content);
    }
#line 6397 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 297: /* seq_block: vBEGIN ':' vIDENT block_item_decl_list vEND  */
#line 2299 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_seq_block_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].symbol).content,
                                            (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[-1].tok), NULL );
      free((yyvsp[-2].symbol).content);
    }
#line 6407 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 298: /* seq_block: vBEGIN ':' vIDENT block_item_decl_list stmt_list vEND  */
#line 2305 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_seq_block_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, (yyvsp[-3].symbol).content,
                                            (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-2].tok), (yyvsp[-1].tok) );
      free((yyvsp[-3].symbol).content);
    }
#line 6417 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 299: /* statement: expression ';'  */
#line 2315 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* '=' is blocking, '<=' is non-blocking */
      (yyval.tok) = veri_parser->gen_block_or_non_or_caller_stmt( (yyvsp[-1].tok) );
    }
#line 6426 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 300: /* statement: blocking_assignment ';'  */
#line 2320 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 6434 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 301: /* statement: case_statement  */
#line 2324 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6442 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 302: /* statement: cond_statement  */
#line 2328 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6450 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 303: /* statement: disable_statement  */
#line 2332 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6458 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 304: /* statement: loop_statement  */
#line 2336 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6466 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 305: /* statement: nonblocking_assignment ';'  */
#line 2340 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 6474 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 306: /* statement: procedural_timing_control_statement  */
#line 2344 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6482 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 307: /* statement: seq_block  */
#line 2348 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6490 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 308: /* statement: sys_caller  */
#line 2352 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6498 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 309: /* statement: attr_inst_list blocking_assignment ';'  */
#line 2356 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 6506 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 310: /* statement: attr_inst_list case_statement  */
#line 2360 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6514 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 311: /* statement: attr_inst_list cond_statement  */
#line 2364 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6522 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 312: /* statement: attr_inst_list disable_statement  */
#line 2368 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6530 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 313: /* statement: attr_inst_list loop_statement  */
#line 2372 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6538 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 314: /* statement: attr_inst_list nonblocking_assignment ';'  */
#line 2376 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 6546 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 315: /* statement: attr_inst_list procedural_timing_control_statement  */
#line 2380 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6554 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 316: /* statement: attr_inst_list seq_block  */
#line 2384 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6562 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 317: /* statement: attr_inst_list sys_caller  */
#line 2388 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6570 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 318: /* stmt_or_null: statement  */
#line 2395 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6578 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 319: /* stmt_or_null: ';'  */
#line 2399 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_dummy_stmt( (yyvsp[0].symbol).line, (yyvsp[0].symbol).col );
    }
#line 6586 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 320: /* stmt_or_null: attr_inst_list ';'  */
#line 2403 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_dummy_stmt( (yyvsp[0].symbol).line, (yyvsp[0].symbol).col );
    }
#line 6594 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 321: /* func_statement: expression ';'  */
#line 2410 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // function-blocking-assignment
      // 1 expression only
      (yyval.tok) = veri_parser->gen_func_blocking_assign_stmt( (yyvsp[-1].tok) );
    }
#line 6604 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 322: /* func_statement: func_case_statement  */
#line 2416 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6612 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 323: /* func_statement: func_cond_statement  */
#line 2420 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6620 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 324: /* func_statement: func_loop_statement  */
#line 2424 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6628 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 325: /* func_statement: func_seq_block  */
#line 2428 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6636 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 326: /* func_statement: disable_statement  */
#line 2432 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6644 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 327: /* func_statement: sys_caller  */
#line 2436 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* only for task */
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6653 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 328: /* func_statement: attr_inst_list expression ';'  */
#line 2441 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // function-blocking-assignment
      // 1 expression only
      (yyval.tok) = veri_parser->gen_func_blocking_assign_stmt( (yyvsp[-1].tok) );
    }
#line 6663 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 329: /* func_statement: attr_inst_list func_case_statement  */
#line 2447 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6671 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 330: /* func_statement: attr_inst_list func_cond_statement  */
#line 2451 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6679 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 331: /* func_statement: attr_inst_list func_loop_statement  */
#line 2455 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6687 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 332: /* func_statement: attr_inst_list func_seq_block  */
#line 2459 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6695 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 333: /* func_statement: attr_inst_list disable_statement  */
#line 2463 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6703 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 334: /* func_statement: attr_inst_list sys_caller  */
#line 2467 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* only for task */
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 6712 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 335: /* event_control: '@' vIDENT  */
#line 2476 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_event_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, IS_FALSE,
                         veri_parser->gen_primary( (yyvsp[0].symbol).content, (yyvsp[0].symbol).line,
                                                   (yyvsp[0].symbol).col, veVAR ));
      free((yyvsp[0].symbol).content);
    }
#line 6723 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 336: /* event_control: '@' '(' expression ')'  */
#line 2483 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* event expression check, only id or event expression list */
      (yyval.tok) = veri_parser->gen_event_stmt( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col,
                                             IS_FALSE, (yyvsp[-1].tok) );
    }
#line 6733 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 337: /* event_control: '@' '*'  */
#line 2489 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_event_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, IS_TRUE, NULL );
    }
#line 6741 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 338: /* event_control: '@' vEVENT_ALL  */
#line 2493 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_event_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, IS_TRUE, NULL );
    }
#line 6749 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 339: /* disable_statement: vDISABLE vIDENT ';'  */
#line 2500 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // hier_block_identifier
      // original --> hier-block-identifier or hier-task-identifier
      // ori --> hier identifier
      (yyval.tok) = veri_parser->gen_disable_stmt( (yyvsp[-1].symbol).content, (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col );
      free((yyvsp[-1].symbol).content);
    }
#line 6761 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 340: /* procedural_timing_control_statement: event_control stmt_or_null  */
#line 2511 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_proc_timing_control_stmt( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 6769 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 341: /* cond_statement: vIF '(' expression ')' stmt_or_null  */
#line 2519 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_cond_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].tok),
                                            (yyvsp[0].tok), NULL );
    }
#line 6779 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 342: /* cond_statement: vIF '(' expression ')' stmt_or_null vELSE stmt_or_null  */
#line 2525 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_cond_stmt( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, (yyvsp[-4].tok),
                                            (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 6789 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 343: /* func_cond_statement: vIF '(' expression ')' func_stmt_or_null  */
#line 2534 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_func_cond_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-2].tok),
                                                 (yyvsp[0].tok), NULL );
    }
#line 6799 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 344: /* func_cond_statement: vIF '(' expression ')' func_stmt_or_null vELSE func_stmt_or_null  */
#line 2540 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_func_cond_stmt( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, (yyvsp[-4].tok),
                                                 (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 6809 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 345: /* case_statement: vCASE '(' expression ')' case_item_list vENDCASE  */
#line 2550 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_case_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, vcCASE,
                                            (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 6819 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 346: /* case_statement: vCASEZ '(' expression ')' case_item_list vENDCASE  */
#line 2556 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_case_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, vcCASEZ,
                                            (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 6829 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 347: /* case_statement: vCASEX '(' expression ')' case_item_list vENDCASE  */
#line 2562 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_case_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, vcCASEX,
                                            (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 6839 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 348: /* case_item_list: case_item  */
#line 2571 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_case_item_list( (yyvsp[0].tok) );
    }
#line 6847 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 349: /* case_item_list: case_item_list case_item  */
#line 2575 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_case_item_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 6855 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 350: /* case_item: expression ':' stmt_or_null  */
#line 2582 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_case_item( (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 6863 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 351: /* case_item: vDEFAULT stmt_or_null  */
#line 2586 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_default_case_item( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 6871 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 352: /* case_item: vDEFAULT ':' stmt_or_null  */
#line 2590 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_default_case_item( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[0].tok) );
    }
#line 6879 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 353: /* func_case_statement: vCASE '(' expression ')' func_case_item_list vENDCASE  */
#line 2597 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_func_case_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, vcCASE,
                                                 (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 6889 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 354: /* func_case_statement: vCASEZ '(' expression ')' func_case_item_list vENDCASE  */
#line 2603 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_func_case_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, vcCASEZ,
                                                 (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 6899 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 355: /* func_case_statement: vCASEX '(' expression ')' func_case_item_list vENDCASE  */
#line 2609 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_func_case_stmt( (yyvsp[-5].symbol).line, (yyvsp[-5].symbol).col, vcCASEX,
                                                 (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 6909 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 356: /* func_case_item_list: func_case_item  */
#line 2618 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_case_item_list( (yyvsp[0].tok) );
    }
#line 6917 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 357: /* func_case_item_list: func_case_item_list func_case_item  */
#line 2622 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->append_func_case_item_list( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 6925 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 358: /* func_case_item: expression ':' func_stmt_or_null  */
#line 2629 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_case_item( (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 6933 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 359: /* func_case_item: vDEFAULT func_stmt_or_null  */
#line 2633 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_default_case_item( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 6941 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 360: /* func_case_item: vDEFAULT ':' func_stmt_or_null  */
#line 2637 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_default_case_item( (yyvsp[-2].symbol).line, (yyvsp[-2].symbol).col, (yyvsp[0].tok) );
    }
#line 6949 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 361: /* func_loop_statement: vFOR '(' expression ';' expression ';' expression ')' func_statement  */
#line 2646 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_func_loop_stmt( (yyvsp[-8].symbol).line, (yyvsp[-8].symbol).col, (yyvsp[-6].tok),
                                    (yyvsp[-4].tok), (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 6959 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 362: /* func_loop_statement: vWHILE '(' expression ')' func_statement  */
#line 2653 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_loop_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, NULL,
                                    (yyvsp[-2].tok), NULL, (yyvsp[0].tok) );
    }
#line 6968 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 363: /* func_loop_statement: vDO func_statement vWHILE '(' expression ')' ';'  */
#line 2658 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_func_loop_stmt( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, NULL,
                                    (yyvsp[-2].tok), NULL, (yyvsp[-5].tok) );
    }
#line 6977 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 364: /* loop_statement: vFOR '(' expression ';' expression ';' expression ')' statement  */
#line 2667 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // 1 expression only
      (yyval.tok) = veri_parser->gen_loop_stmt( (yyvsp[-8].symbol).line, (yyvsp[-8].symbol).col, (yyvsp[-6].tok),
                                    (yyvsp[-4].tok), (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 6987 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 365: /* loop_statement: vWHILE '(' expression ')' statement  */
#line 2674 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_loop_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, NULL,
                                    (yyvsp[-2].tok), NULL, (yyvsp[0].tok) );
    }
#line 6996 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 366: /* loop_statement: vDO statement vWHILE '(' expression ')' ';'  */
#line 2679 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_loop_stmt( (yyvsp[-6].symbol).line, (yyvsp[-6].symbol).col, NULL,
                                    (yyvsp[-2].tok), NULL, (yyvsp[-5].tok) );
    }
#line 7005 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 367: /* concat: '{' expression '}'  */
#line 2704 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // could be const
      (yyval.tok) = veri_parser->gen_concat_exp( (yyvsp[-1].tok) );
    }
#line 7014 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 368: /* multi_concat: '{' expression concat '}'  */
#line 2712 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      // const + non-const, two structures
      // 1 const-expression only 
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtMULTI_CONCAT, (yyvsp[-3].symbol).line,
                                         (yyvsp[-3].symbol).col, (yyvsp[-1].tok) );
    }
#line 7025 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 369: /* sys_caller: vSYS_IDENT ';'  */
#line 2724 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_sys_caller_stmt( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[-1].symbol).content, NULL );
    }
#line 7033 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 370: /* sys_caller: vSYS_IDENT '(' expression ')' ';'  */
#line 2728 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_sys_caller_stmt( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col,
                                             (yyvsp[-4].symbol).content, (yyvsp[-2].tok) );
    }
#line 7042 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 371: /* expression: assignment_expression  */
#line 2737 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7050 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 372: /* expression: vDUMMY_PORT  */
#line 2741 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_dummy_port( (yyvsp[0].symbol).line, (yyvsp[0].symbol).col );
    }
#line 7058 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 373: /* expression: expression ',' expression  */
#line 2745 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_multi( (yyvsp[-2].tok), (yyvsp[0].tok), vemCOMMA_EXP, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col );
    }
#line 7066 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 374: /* expression: expression vOR_ASCII expression  */
#line 2749 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* for event only */
      (yyval.tok) = veri_parser->gen_multi( (yyvsp[-2].tok), (yyvsp[0].tok), vemEVENT_EXP, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col );
    }
#line 7075 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 375: /* postfix_expression: primary  */
#line 2757 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7083 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 376: /* postfix_expression: postfix_expression '(' ')'  */
#line 2761 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_caller( (yyvsp[-2].tok), NULL );
    }
#line 7091 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 377: /* postfix_expression: postfix_expression '(' expression ')'  */
#line 2765 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* could be const */
      (yyval.tok) = veri_parser->gen_caller( (yyvsp[-3].tok), (yyvsp[-1].tok) );
    }
#line 7100 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 378: /* postfix_expression: postfix_expression range  */
#line 2770 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* could be range or array or dimension ... */
      (yyval.tok) = veri_parser->gen_array( (yyvsp[-1].tok), (yyvsp[0].tok) );
    }
#line 7109 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 379: /* range: '[' expression ']'  */
#line 2778 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_range( (yyvsp[-1].tok), vrSINGLE, NULL );
    }
#line 7117 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 380: /* range: '[' expression ':' expression ']'  */
#line 2782 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_range( (yyvsp[-3].tok), vrSEMI, (yyvsp[-1].tok) );
    }
#line 7125 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 381: /* range: '[' expression vRANGE_ADD expression ']'  */
#line 2786 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_range( (yyvsp[-3].tok), vrRAN_ADD, (yyvsp[-1].tok) );
    }
#line 7133 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 382: /* range: '[' expression vRANGE_SUB expression ']'  */
#line 2790 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_range( (yyvsp[-3].tok), vrRAN_SUB, (yyvsp[-1].tok) );
    }
#line 7141 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 383: /* unary_expression: postfix_expression  */
#line 2797 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7149 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 384: /* unary_expression: '+' unary_expression  */
#line 2801 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUADD, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7157 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 385: /* unary_expression: '-' unary_expression  */
#line 2805 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUSUB, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7165 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 386: /* unary_expression: '~' unary_expression  */
#line 2809 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUNEG, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7173 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 387: /* unary_expression: '&' unary_expression  */
#line 2813 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUAND, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7181 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 388: /* unary_expression: '|' unary_expression  */
#line 2817 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUOR, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7189 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 389: /* unary_expression: vNAND unary_expression  */
#line 2821 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUNAND, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7197 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 390: /* unary_expression: vNOR unary_expression  */
#line 2825 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUNOR, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7205 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 391: /* unary_expression: vXNOR unary_expression  */
#line 2829 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUXNOR, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7213 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 392: /* unary_expression: '!' unary_expression  */
#line 2833 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUNOT, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7221 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 393: /* unary_expression: '^' unary_expression  */
#line 2837 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unary( vtUXOR, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7229 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 394: /* unary_expression: vPOSEDGE unary_expression  */
#line 2841 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* event */
      (yyval.tok) = veri_parser->gen_unary( vtUPOSE, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7238 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 395: /* unary_expression: vNEGEDGE unary_expression  */
#line 2846 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* event */
      (yyval.tok) = veri_parser->gen_unary( vtUNEGE, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7247 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 396: /* unary_expression: vSIGN_FUNC '(' expression ')'  */
#line 2851 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_signed_exp( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-1].tok) );
    }
#line 7255 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 397: /* unary_expression: vUNSIGN_FUNC '(' expression ')'  */
#line 2855 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_unsigned_exp( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-1].tok) );
    }
#line 7263 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 398: /* pow_expression: unary_expression  */
#line 2862 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7271 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 399: /* pow_expression: pow_expression vPOW unary_expression  */
#line 2866 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBPOW, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7280 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 400: /* pow_expression: pow_expression vNAND unary_expression  */
#line 2871 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBNAND, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7289 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 401: /* pow_expression: pow_expression vNOR unary_expression  */
#line 2876 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBNOR, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7298 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 402: /* pow_expression: pow_expression vXNOR unary_expression  */
#line 2881 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBXNOR, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7307 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 403: /* multiplicative_expression: pow_expression  */
#line 2889 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7315 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 404: /* multiplicative_expression: multiplicative_expression '%' pow_expression  */
#line 2893 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBMOD, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7324 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 405: /* multiplicative_expression: multiplicative_expression '*' pow_expression  */
#line 2898 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBMUL, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7333 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 406: /* multiplicative_expression: multiplicative_expression '/' pow_expression  */
#line 2903 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBDIV, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7342 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 407: /* additive_expression: multiplicative_expression  */
#line 2911 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7350 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 408: /* additive_expression: additive_expression '+' multiplicative_expression  */
#line 2915 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBADD, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7359 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 409: /* additive_expression: additive_expression '-' multiplicative_expression  */
#line 2920 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBSUB, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7368 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 410: /* shift_expression: additive_expression  */
#line 2928 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7376 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 411: /* shift_expression: shift_expression vLOGIC_RS additive_expression  */
#line 2932 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBLRS, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7385 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 412: /* shift_expression: shift_expression vLOGIC_LS additive_expression  */
#line 2937 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBLLS, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7394 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 413: /* shift_expression: shift_expression vARITH_RS additive_expression  */
#line 2942 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBARS, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7403 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 414: /* shift_expression: shift_expression vARITH_LS additive_expression  */
#line 2947 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBALS, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7412 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 415: /* relational_expression: shift_expression  */
#line 2955 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7420 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 416: /* relational_expression: relational_expression '<' shift_expression  */
#line 2959 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBLT, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7429 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 417: /* relational_expression: relational_expression '>' shift_expression  */
#line 2964 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBGT, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7438 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 418: /* relational_expression: relational_expression vLE shift_expression  */
#line 2969 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBLE, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7447 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 419: /* relational_expression: relational_expression vGE shift_expression  */
#line 2974 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBGE, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7456 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 420: /* equality_expression: relational_expression  */
#line 2982 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7464 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 421: /* equality_expression: equality_expression vLOGIC_EQ relational_expression  */
#line 2986 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBLEQ, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7473 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 422: /* equality_expression: equality_expression vLOGIC_INEQ relational_expression  */
#line 2991 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBLIEQ, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7482 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 423: /* equality_expression: equality_expression vCASE_EQ relational_expression  */
#line 2996 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBCEQ, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7491 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 424: /* equality_expression: equality_expression vCASE_INEQ relational_expression  */
#line 3001 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBCIEQ, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7500 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 425: /* and_expression: equality_expression  */
#line 3009 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7508 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 426: /* and_expression: and_expression '&' equality_expression  */
#line 3013 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBSAND, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7517 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 427: /* xor_expression: and_expression  */
#line 3021 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7525 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 428: /* xor_expression: xor_expression '^' and_expression  */
#line 3025 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBSXOR, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7534 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 429: /* bit_or_expression: xor_expression  */
#line 3033 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7542 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 430: /* bit_or_expression: bit_or_expression '|' xor_expression  */
#line 3037 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBSOR, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7551 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 431: /* logical_and_expression: bit_or_expression  */
#line 3045 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7559 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 432: /* logical_and_expression: logical_and_expression vANDAND bit_or_expression  */
#line 3049 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBDAND, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7568 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 433: /* logical_or_expression: logical_and_expression  */
#line 3057 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7576 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 434: /* logical_or_expression: logical_or_expression vOROR logical_and_expression  */
#line 3061 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtBDOR, (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].tok));
    }
#line 7584 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 435: /* conditional_expression: logical_or_expression  */
#line 3068 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7592 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 436: /* conditional_expression: logical_or_expression '?' expression ':' conditional_expression  */
#line 3072 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_ques_exp( (yyvsp[-4].tok), (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 7600 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 437: /* assignment_expression: conditional_expression  */
#line 3079 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7608 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 438: /* assignment_expression: unary_expression '=' assignment_expression  */
#line 3083 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* first expression should be id */
      (yyval.tok) = veri_parser->gen_binary( (yyvsp[-2].tok), vtASSIGN, (yyvsp[-1].symbol).line,
                                         (yyvsp[-1].symbol).col, (yyvsp[0].tok) );
    }
#line 7618 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 439: /* mintypmax_expression: expression ':' expression ':' expression  */
#line 3092 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_mintypmax( (yyvsp[-4].tok), (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-2].tok), (yyvsp[0].tok) );
    }
#line 7626 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 440: /* primary: vNUMBER  */
#line 3102 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* could be const */
      (yyval.tok) = veri_parser->gen_primary( (yyvsp[0].symbol).content, (yyvsp[0].symbol).line, (yyvsp[0].symbol).col, veNUM );
      free( (yyvsp[0].symbol).content );
    }
#line 7636 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 441: /* primary: vSTR  */
#line 3108 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* could be const */
      (yyval.tok) = veri_parser->gen_primary( (yyvsp[0].symbol).content, (yyvsp[0].symbol).line, (yyvsp[0].symbol).col, veSTR );
      free( (yyvsp[0].symbol).content );
    }
#line 7646 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 442: /* primary: vIDENT  */
#line 3114 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* could be const */
      (yyval.tok) = veri_parser->gen_primary( (yyvsp[0].symbol).content, (yyvsp[0].symbol).line, (yyvsp[0].symbol).col, veVAR );
      free((yyvsp[0].symbol).content);
    }
#line 7656 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 443: /* primary: vSYS_IDENT  */
#line 3120 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* system function identifier (e.g. $clog2) */
      (yyval.tok) = veri_parser->gen_primary( (yyvsp[0].symbol).content, (yyvsp[0].symbol).line, (yyvsp[0].symbol).col, veVAR );
      free((yyvsp[0].symbol).content);
    }
#line 7666 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 444: /* primary: vSYS_IDENT '(' expression ')'  */
#line 3126 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* system function call (e.g. $clog2(expr)) */
      VeriNode * name = veri_parser->gen_primary( (yyvsp[-3].symbol).content, (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, veVAR );
      free((yyvsp[-3].symbol).content);
      (yyval.tok) = veri_parser->gen_caller( name, (yyvsp[-1].tok) );
    }
#line 7677 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 445: /* primary: '.' vIDENT  */
#line 3133 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = veri_parser->gen_port_ref( (yyvsp[-1].symbol).line, (yyvsp[-1].symbol).col, (yyvsp[0].symbol).content );
      free( (yyvsp[0].symbol).content );
    }
#line 7686 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 446: /* primary: '.' vIDENT '(' expression ')'  */
#line 3138 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* named port connection with signal: .port_name(signal) */
      VeriNode * port = veri_parser->gen_port_ref( (yyvsp[-4].symbol).line, (yyvsp[-4].symbol).col, (yyvsp[-3].symbol).content );
      free( (yyvsp[-3].symbol).content );
      (yyval.tok) = veri_parser->gen_caller( port, (yyvsp[-1].tok) );
    }
#line 7697 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 447: /* primary: '.' vIDENT '(' ')'  */
#line 3145 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* named port connection with no signal (open): .port_name() */
      VeriNode * port = veri_parser->gen_port_ref( (yyvsp[-3].symbol).line, (yyvsp[-3].symbol).col, (yyvsp[-2].symbol).content );
      free( (yyvsp[-2].symbol).content );
      (yyval.tok) = veri_parser->gen_caller( port, NULL );
    }
#line 7708 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 448: /* primary: concat  */
#line 3152 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* could be const */
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7717 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 449: /* primary: multi_concat  */
#line 3157 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* could be const */
      (yyval.tok) = (yyvsp[0].tok);
    }
#line 7726 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 450: /* primary: '(' expression ')'  */
#line 3162 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 7734 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 451: /* primary: '(' mintypmax_expression ')'  */
#line 3166 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
      /* could be const */
      (yyval.tok) = (yyvsp[-1].tok);
    }
#line 7743 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 452: /* attr_inst_list: attr_instance  */
#line 3181 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 7750 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 453: /* attr_inst_list: attr_inst_list attr_instance  */
#line 3184 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 7757 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;

  case 454: /* attr_instance: vATTR_L expression vATTR_R  */
#line 3190 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"
    {
    }
#line 7764 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"
    break;


#line 7768 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.cpp"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 3197 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"

