/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_VERILOG_G_VIBE_CODEING_EDACRAFT_DEV_VERILOG_PARSER_SRC_PARSER_VERILOG_VERILOG_YACC_HPP_INCLUDED
# define YY_VERILOG_G_VIBE_CODEING_EDACRAFT_DEV_VERILOG_PARSER_SRC_PARSER_VERILOG_VERILOG_YACC_HPP_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int verilogdebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    MY_EOF = 258,                  /* MY_EOF  */
    vPORT_DELIM = 259,             /* vPORT_DELIM  */
    vPARAM_DELIM = 260,            /* vPARAM_DELIM  */
    vEVENT_ALL = 261,              /* vEVENT_ALL  */
    vDUMMY_PORT = 262,             /* vDUMMY_PORT  */
    vSIGN_FUNC = 263,              /* vSIGN_FUNC  */
    vUNSIGN_FUNC = 264,            /* vUNSIGN_FUNC  */
    vNOT_SUPPORTED = 265,          /* vNOT_SUPPORTED  */
    vALWAYS = 266,                 /* vALWAYS  */
    vALWAYS_COMB = 267,            /* vALWAYS_COMB  */
    vALWAYS_FF = 268,              /* vALWAYS_FF  */
    vALWAYS_LATCH = 269,           /* vALWAYS_LATCH  */
    vAND_ASCII = 270,              /* vAND_ASCII  */
    vASSIGN = 271,                 /* vASSIGN  */
    vAUTO = 272,                   /* vAUTO  */
    vBEGIN = 273,                  /* vBEGIN  */
    vBIT = 274,                    /* vBIT  */
    vBUF_ASCII = 275,              /* vBUF_ASCII  */
    vBUFIF_A = 276,                /* vBUFIF_A  */
    vBYTE = 277,                   /* vBYTE  */
    vBUFIF_B = 278,                /* vBUFIF_B  */
    vCASE = 279,                   /* vCASE  */
    vCASEX = 280,                  /* vCASEX  */
    vCASEZ = 281,                  /* vCASEZ  */
    vCELL = 282,                   /* vCELL  */
    vCONFIG = 283,                 /* vCONFIG  */
    vDEFAULT = 284,                /* vDEFAULT  */
    vDESIGN = 285,                 /* vDESIGN  */
    vDISABLE = 286,                /* vDISABLE  */
    vDO = 287,                     /* vDO  */
    vELSE = 288,                   /* vELSE  */
    vEND = 289,                    /* vEND  */
    vENDCASE = 290,                /* vENDCASE  */
    vENDCONFIG = 291,              /* vENDCONFIG  */
    vENDFUNC = 292,                /* vENDFUNC  */
    vENDGEN = 293,                 /* vENDGEN  */
    vENDMODULE = 294,              /* vENDMODULE  */
    vENDSPEC = 295,                /* vENDSPEC  */
    vENDTASK = 296,                /* vENDTASK  */
    vFOR = 297,                    /* vFOR  */
    vFUNC = 298,                   /* vFUNC  */
    vGEN = 299,                    /* vGEN  */
    vGENVAR = 300,                 /* vGENVAR  */
    vHIGHZ_A = 301,                /* vHIGHZ_A  */
    vHIGHZ_B = 302,                /* vHIGHZ_B  */
    vIF = 303,                     /* vIF  */
    vINC_DIR = 304,                /* vINC_DIR  */
    vINIT = 305,                   /* vINIT  */
    vINOUT = 306,                  /* vINOUT  */
    vINPUT = 307,                  /* vINPUT  */
    vINSTANCE = 308,               /* vINSTANCE  */
    vINT = 309,                    /* vINT  */
    vLIBLIST = 310,                /* vLIBLIST  */
    vLIB = 311,                    /* vLIB  */
    vLOCAL_PARAM = 312,            /* vLOCAL_PARAM  */
    vMODULE = 313,                 /* vMODULE  */
    vNAND_ASCII = 314,             /* vNAND_ASCII  */
    vNEGEDGE = 315,                /* vNEGEDGE  */
    vNOR_ASCII = 316,              /* vNOR_ASCII  */
    vNOT_ASCII = 317,              /* vNOT_ASCII  */
    vNOTIF_A = 318,                /* vNOTIF_A  */
    vNOTIF_B = 319,                /* vNOTIF_B  */
    vOR_ASCII = 320,               /* vOR_ASCII  */
    vOUTPUT = 321,                 /* vOUTPUT  */
    vPARAMETER = 322,              /* vPARAMETER  */
    vPOSEDGE = 323,                /* vPOSEDGE  */
    vPULL_A = 324,                 /* vPULL_A  */
    vPULL_B = 325,                 /* vPULL_B  */
    vREG = 326,                    /* vREG  */
    vSHORTINT = 327,               /* vSHORTINT  */
    vTRIAND = 328,                 /* vTRIAND  */
    vTRIOR = 329,                  /* vTRIOR  */
    vSCALARED = 330,               /* vSCALARED  */
    vSIGNED = 331,                 /* vSIGNED  */
    vSPECIFY = 332,                /* vSPECIFY  */
    vSPEC_PARAM = 333,             /* vSPEC_PARAM  */
    vSTRONG_A = 334,               /* vSTRONG_A  */
    vSTRONG_B = 335,               /* vSTRONG_B  */
    vSUPPLY_A = 336,               /* vSUPPLY_A  */
    vSUPPLY_B = 337,               /* vSUPPLY_B  */
    vTASK = 338,                   /* vTASK  */
    vTIME = 339,                   /* vTIME  */
    vTRI = 340,                    /* vTRI  */
    vUSE = 341,                    /* vUSE  */
    vUNSIGNED = 342,               /* vUNSIGNED  */
    vVECTORED = 343,               /* vVECTORED  */
    vWAND = 344,                   /* vWAND  */
    vWEAK_A = 345,                 /* vWEAK_A  */
    vWEAK_B = 346,                 /* vWEAK_B  */
    vWHILE = 347,                  /* vWHILE  */
    vWIRE = 348,                   /* vWIRE  */
    vWOR = 349,                    /* vWOR  */
    vLONGINT = 350,                /* vLONGINT  */
    vXNOR_ASCII = 351,             /* vXNOR_ASCII  */
    vXOR_ASCII = 352,              /* vXOR_ASCII  */
    vIDENT = 353,                  /* vIDENT  */
    vLOGIC = 354,                  /* vLOGIC  */
    vNUMBER = 355,                 /* vNUMBER  */
    vSYS_IDENT = 356,              /* vSYS_IDENT  */
    vCONCAT_IDENT = 357,           /* vCONCAT_IDENT  */
    vUNSIGNED_NUM = 358,           /* vUNSIGNED_NUM  */
    vARITH_LS = 359,               /* vARITH_LS  */
    vARITH_RS = 360,               /* vARITH_RS  */
    vANDAND = 361,                 /* vANDAND  */
    vXNOR = 362,                   /* vXNOR  */
    vNAND = 363,                   /* vNAND  */
    vNOR = 364,                    /* vNOR  */
    vPOW = 365,                    /* vPOW  */
    vOROR = 366,                   /* vOROR  */
    vLE = 367,                     /* vLE  */
    vGE = 368,                     /* vGE  */
    vLOGIC_LS = 369,               /* vLOGIC_LS  */
    vLOGIC_RS = 370,               /* vLOGIC_RS  */
    vLOGIC_EQ = 371,               /* vLOGIC_EQ  */
    vLOGIC_INEQ = 372,             /* vLOGIC_INEQ  */
    vCASE_EQ = 373,                /* vCASE_EQ  */
    vCASE_INEQ = 374,              /* vCASE_INEQ  */
    vATTR_L = 375,                 /* vATTR_L  */
    vATTR_R = 376,                 /* vATTR_R  */
    vPRIMITIVE = 377,              /* vPRIMITIVE  */
    vENDPRI = 378,                 /* vENDPRI  */
    vSTR = 379,                    /* vSTR  */
    vFILE = 380,                   /* vFILE  */
    vRANGE_ADD = 381,              /* vRANGE_ADD  */
    vRANGE_SUB = 382,              /* vRANGE_SUB  */
    vPATHPULSE = 383,              /* vPATHPULSE  */
    LOWER_THAN_ELSE = 384,         /* LOWER_THAN_ELSE  */
    LOWER_THAN_A = 385,            /* LOWER_THAN_A  */
    LOWER_THAN_B = 386,            /* LOWER_THAN_B  */
    LOWER_THAN_C = 387,            /* LOWER_THAN_C  */
    UOR = 388,                     /* UOR  */
    UAND = 389,                    /* UAND  */
    UNEG = 390,                    /* UNEG  */
    UNAND = 391,                   /* UNAND  */
    UNOR = 392,                    /* UNOR  */
    UXNOR = 393,                   /* UXNOR  */
    UXOR = 394,                    /* UXOR  */
    ULNOT = 395,                   /* ULNOT  */
    UADD = 396,                    /* UADD  */
    UMINUS = 397                   /* UMINUS  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 56 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog.y"

  class VeriNode *tok;

  struct
  {
    int   col;
    int   line;
    char *content;
  }symbol;

  struct
  {
    int  col;
    int  line;
    int  extra[3];
    class VeriNode *node[3];
  }extra_tok;

#line 225 "G:/vibe-codeing/EDACraft_dev/verilog_parser/src/parser/verilog/verilog_yacc.hpp"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE veriloglval;


int verilogparse (void);


#endif /* !YY_VERILOG_G_VIBE_CODEING_EDACRAFT_DEV_VERILOG_PARSER_SRC_PARSER_VERILOG_VERILOG_YACC_HPP_INCLUDED  */
