# DSIMCraft 0.13.0 / M238 — Linux x86_64 二进制版

解压后使用 `bin/dsim`，无需编译 dsim 本身。验收环境为 CentOS Stream 9
x86_64、glibc 2.34、GCC 11.5；其他 Linux 发行版尚未验证。运行需要兼容的
glibc/libstdc++，以及 PATH 中的 C++17 编译器。包内不含 C++ 工具链、UVM 库或商业 EDA 软件。

```sh
./bin/dsim --version
./bin/dsim examples/counter.sv -o /tmp/dsim-counter
/tmp/dsim-counter
```

预期 `DSIMCRAFT COUNTER PASS 4`。可将本包的 bin 加入 PATH，或为 bin/dsim
建立符号链接。安装目录可以包含空格；启动器保留调用者的工作目录与每个参数。
filelist 的相对路径仍遵循 `-f` / `-F` 原有规则。

生成模型默认使用 `c++`，也可通过 `DSIM_CXX=/path/to/clang++` 或 `--cxx /path/to/icpx`
选择编译器，显式 --cxx 优先。Intel 编译器会使用严格浮点设置。

```sh
./bin/dsim examples/counter.sv --wave-support -o /tmp/dsim-wave
/tmp/dsim-wave --waveform /tmp/counter.vcd --wave-format vcd
/tmp/dsim-wave --waveform /tmp/counter.dwf --wave-codec zstd --wave-async
./bin/dsim examples/random.sv -o /tmp/dsim-random
/tmp/dsim-random
```

波形目标已存在时需先移走或选择新文件名。包内有 Z3/Zstd 静态库、相关开发头文件、
Tcl/zlib 运行库和 dsim runtime 头文件。使用 bin/dsim 启动器来设置这些路径；
libexec/dsim 是内部入口。高级用户可以覆盖 DSIM_RUNTIME_DIR、DSIM_Z3_INCLUDE/LIBRARY、
DSIM_ZSTD_INCLUDE/LIBRARY。它们不会执行 shell 命令。

源码与功能开发仓库：https://github.com/ephonic/dsim 。精确源码提交、二进制及各文件
SHA256 在 release.json / SHA256SUMS；本包包含 M237 参数化 virtual interface。
精确源码可按提交从源码仓库取得，包内 runtime 与该提交逐字一致。

当前仍是工程版本，完整 UVM/VIP/RAL、virtual clocking、interface 实例数组及
完整对象图随机化/DPI/VPI/SVA/覆盖率仍有缺口。发布说明中的测试属于列明的子集。

LICENSE 适用于本项目发行部分；第三方组件保留各自条款，见 licenses/，没有重新授权。
