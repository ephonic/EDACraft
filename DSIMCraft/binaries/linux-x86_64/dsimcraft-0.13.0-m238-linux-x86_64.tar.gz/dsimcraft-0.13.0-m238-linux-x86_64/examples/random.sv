class transaction;
 rand int value;
 constraint fixed_value { value inside {[7:7]}; }
endclass
module top;
 transaction item;
 initial begin
  item=new();
  if(!item.randomize()||item.value!=7)$fatal(1,"constraint randomization");
  $display("DSIMCRAFT RANDOM PASS %0d",item.value);
 end
endmodule
