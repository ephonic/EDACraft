`timescale 1ns/1ps
interface bus_if #(parameter int W=8,SEED=1);
 logic[W-1:0] data;
 function automatic logic[W-1:0] sample();return data+SEED;endfunction
 task automatic drive(input logic[W-1:0] value);#1;data=value;endtask
 modport client(import sample,drive,input data);
endinterface
class driver #(parameter int W=8,S=1);
 virtual bus_if#(.W(W),.SEED(S)).client vif;
 function new(virtual bus_if#(W,S).client value);vif=value;endfunction
 task run(input logic[W-1:0] value);vif.drive(value);endtask
endclass
module top;
 bus_if#(8,3) a();bus_if#(65,7) b();bus_if#(8,19) c();
 driver#(8,3) narrow_driver;driver#(65,7) wide_driver;
 virtual bus_if#(8,19).client third;
 initial begin
  narrow_driver=new(a);wide_driver=new(b);third=c;
  fork narrow_driver.run(8'hf0);wide_driver.run(65'h1_23456789_abcdef00);third.drive(8'h20);join
  if(narrow_driver.vif.sample()!==8'hf3||wide_driver.vif.sample()!==65'h1_23456789_abcdef07||third.sample()!==8'h33)$fatal(1,"parameter dispatch");
  $display("TRACE parameter methods %h %h %h",narrow_driver.vif.sample(),wide_driver.vif.sample(),third.sample());
 end
endmodule
